@echo off
python "%~dp0bili.py" %*
