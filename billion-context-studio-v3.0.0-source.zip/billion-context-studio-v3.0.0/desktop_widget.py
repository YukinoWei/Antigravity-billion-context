"""Entry point re-exporting the Chat-Bar Docked Context Estimator widget."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent
PLUGIN_DIR = ROOT_DIR / "plugin"
if str(PLUGIN_DIR) not in sys.path:
    sys.path.insert(0, str(PLUGIN_DIR))

from scripts.chatbar_widget import (  # noqa: E402,F401
    ContextEstimatorApp,
    compute_docked_position,
    enable_windows_dpi_awareness,
    fetch_snapshot,
    find_antigravity_window_rect,
    main,
)

if __name__ == "__main__":
    main()
