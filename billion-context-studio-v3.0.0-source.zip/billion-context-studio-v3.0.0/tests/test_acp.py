"""Comprehensive unit & end-to-end integration tests for Billion-Context Studio v3.0."""

from __future__ import annotations

import hashlib
import io
import json
import subprocess
import sys
import tempfile
import time
import unittest
from contextlib import redirect_stdout
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent
PLUGIN_DIR = ROOT_DIR / "plugin"
for p in (str(PLUGIN_DIR), str(ROOT_DIR)):
    if p not in sys.path:
        sys.path.insert(0, p)

from core.acp_store import ACPStore  # noqa: E402
from core.guard_engine import (  # noqa: E402
    MAX_INLINE_UTF8_BYTES,
    compress_cli_output,
    is_sensitive_file,
    redact_secrets,
    smart_crush_json,
    truncate_utf8_safe,
)
from scripts.hook_runner import process_hook  # noqa: E402
import bili  # noqa: E402


def _write_sample_transcript(
    folder: Path,
    num_turns: int = 12,
    input_tokens: int = 40000,
    model: str = "gemini-4-carbon-high",
) -> tuple[Path, Path]:
    logs_dir = folder / ".system_generated" / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)
    compact_path = logs_dir / "transcript.jsonl"
    full_path = logs_dir / "transcript_full.jsonl"

    compact_lines = []
    full_lines = []
    step = 0
    for t in range(num_turns):
        t_sec = (t * 12) % 60
        t_min = (t * 12) // 60
        u_content = f"<USER_REQUEST>\nTurn {t}: implement src/module_{t}.py and validate auth_token_{t}.\n</USER_REQUEST>"
        if t == 0:
            u_content += "\n<available_skills>acp-context-management</available_skills>"
        u = {
            "step_index": step,
            "source": "USER_EXPLICIT",
            "type": "USER_INPUT",
            "status": "DONE",
            "created_at": f"2026-11-26T10:{t_min:02d}:{t_sec:02d}Z",
            "content": u_content,
        }
        compact_lines.append(json.dumps(u))
        full_lines.append(json.dumps(u))
        step += 1

        total_in = input_tokens + t * 3000
        cached_in = int(total_in * 0.92)
        uncached_in = total_in - cached_in
        next_sec = (t * 12 + 5) % 60
        next_min = (t * 12 + 5) // 60
        p_full = {
            "step_index": step,
            "source": "MODEL",
            "type": "PLANNER_RESPONSE",
            "status": "DONE",
            "created_at": f"2026-11-26T10:{next_min:02d}:{next_sec:02d}Z",
            "model": model,
            "input_tokens": uncached_in,
            "cache_read_tokens": cached_in,
            "output_tokens": 420,
            "thinking": f"Internal chain of thought for turn {t} checking SECRET_TOKEN_{t}.",
            "content": f"Implemented src/module_{t}.py with helper fn_{t}() and verified tests." + (" padding " * 220),
            "tool_calls": [
                {"name": "write_file", "args": {"Path": f"d:/antigra/src/module_{t}.py"}},
                {"name": "run_command", "args": {"CommandLine": f"pytest tests/test_mod_{t}.py"}},
            ],
        }
        p_compact = dict(p_full)
        p_compact["truncated_fields"] = ["thinking"]
        p_compact["thinking"] = p_full["thinking"][:20]
        compact_lines.append(json.dumps(p_compact))
        full_lines.append(json.dumps(p_full))
        step += 1

    compact_path.write_text("\n".join(compact_lines) + "\n", encoding="utf-8")
    full_path.write_text("\n".join(full_lines) + "\n", encoding="utf-8")
    return compact_path, full_path


class TestACPKernelAndFusedGuards(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.tmp_path = Path(self.tmp.name)
        self.data_dir = self.tmp_path / "acp_data"
        self.store = ACPStore(data_dir=self.data_dir)
        self.tx_path, self.tx_full_path = _write_sample_transcript(
            self.tmp_path / "conv1", num_turns=12, input_tokens=45000
        )
        self.cid = "conv-test-001"
        self.store.register_session(
            conversation_id=self.cid,
            transcript_path=str(self.tx_path),
            artifact_dir=str(self.tmp_path / "conv1"),
            workspace_paths=[str(self.tmp_path)],
            cwd=str(self.tmp_path),
            model_name="gemini-4-carbon-high",
            context_window=100000,
        )

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_dual_window_512k_and_lsm_pipeline(self) -> None:
        st_before = self.store.get_status(self.cid, detail="full")
        self.assertEqual(st_before["telemetry"]["physical_window_tokens"], 512_000)

        cap = self.store.compress_steps(
            conversation_id=self.cid,
            range_ref="s00000..s00007",
            title="Bootstrap modules 0..3",
            summary="Built src/module_0.py..module_3.py.",
        )
        cap2 = self.store.compress_steps(
            conversation_id=self.cid,
            range_ref="s00008..s00015",
            title="Bootstrap modules 4..7",
            summary="Built src/module_4.py..module_7.py.",
        )
        m1 = self.store.compress_blocks(
            conversation_id=self.cid,
            block_ids=[cap["block_id"], cap2["block_id"]],
            title="Milestone 1",
            summary="Modules 0..7 complete.",
            operation="distill",
        )
        self.assertEqual(m1["tier"], "T2")
        st_after = self.store.get_status(self.cid, detail="compact")
        self.assertLess(st_after["telemetry"]["logical_working_tokens"], st_before["telemetry"]["logical_working_tokens"])

    def test_read_quota_guard_secret_block_dedup_and_edit_invalidation(self) -> None:
        guard = self.store.get_guard()

        # 1. Sensitive .env file is blocked; .env.example is allowed
        self.assertTrue(is_sensitive_file("d:/repo/.env"))
        self.assertFalse(is_sensitive_file("d:/repo/.env.example"))
        env_file = self.tmp_path / ".env"
        env_file.write_text("API_KEY=sk-1234567890abcdefghijklmnop\n", encoding="utf-8")
        res_env = guard.evaluate_pre_read(self.cid, {"Path": str(env_file)})
        self.assertEqual(res_env["decision"], "deny")

        # 2. Oversized unranged read (>45KB) blocks on 1st strike with symbol outline, allows on 2nd strike!
        big_py = self.tmp_path / "big_service.py"
        big_py.write_text(
            "class AuthEngine:\n    pass\n\ndef verify_jwt(token: str) -> bool:\n    return True\n" + ("# pad line\n" * 4800),
            encoding="utf-8",
        )
        r_strike1 = guard.evaluate_pre_read(self.cid, {"Path": str(big_py)})
        self.assertEqual(r_strike1["decision"], "deny")
        self.assertIn("verify_jwt", r_strike1["reason"])
        r_strike2 = guard.evaluate_pre_read(self.cid, {"Path": str(big_py)})
        self.assertEqual(r_strike2["decision"], "allow")

        # 3. Unchanged duplicate read dedup (>=6KB, <=45KB) & edit invalidation
        med_py = self.tmp_path / "medium_mod.py"
        med_py.write_text("def compute_delta():\n    return 42\n" + ("# comment\n" * 800), encoding="utf-8")
        self.assertEqual(guard.evaluate_pre_read(self.cid, {"Path": str(med_py)})["decision"], "allow")
        dedup_hit = guard.evaluate_pre_read(self.cid, {"Path": str(med_py)})
        self.assertEqual(dedup_hit["decision"], "deny")
        self.assertIn("Duplicate-Read Guard", dedup_hit["reason"])

        # Editing the file invalidates read cache -> immediate allow!
        guard.invalidate_file_read(self.cid, str(med_py))
        self.assertEqual(guard.evaluate_pre_read(self.cid, {"Path": str(med_py)})["decision"], "allow")

    def test_cli_noise_trimmer_json_crusher_and_utf8_cap(self) -> None:
        # Multi-byte CJK safe truncation <= 8.8 KB
        cjk_heavy = "中文上下文压缩测试🚀" * 1200
        capped = truncate_utf8_safe(cjk_heavy, max_bytes=MAX_INLINE_UTF8_BYTES)
        self.assertLessEqual(len(capped.encode("utf-8")), MAX_INLINE_UTF8_BYTES)
        self.assertNotIn("\ufffd", capped)

        # Secret redaction + error anchor preservation in long test log
        noisy_log = "\n".join(
            [f"Downloading pkg_{i}... 50% █████" for i in range(100)]
            + [" token=sk-abcdefghijklmnopqrstuvwxyz123456 "]
            + [f"test_case_{i} PASSED" for i in range(400)]
            + ["FAILED tests/test_auth.py::test_login - AssertionError: invalid signature"]
            + [f"test_tail_{i} PASSED" for i in range(200)]
        )
        trimmed, saved = compress_cli_output(noisy_log, exit_code=1)
        self.assertGreater(saved, 0)
        self.assertIn("AssertionError: invalid signature", trimmed)
        self.assertIn("sk-[REDACTED]", trimmed)
        self.assertLessEqual(len(trimmed.encode("utf-8")), MAX_INLINE_UTF8_BYTES)

        # Smart JSON crusher preserves error items
        huge_json = json.dumps(
            [{"id": i, "ok": True, "payload": "x" * 120} for i in range(150)]
            + [{"id": 999, "error": "DB_DEADLOCK_DETECTED"}]
        )
        crushed, was_json = smart_crush_json(huge_json)
        self.assertTrue(was_json)
        self.assertIn("DB_DEADLOCK_DETECTED", crushed)

    def test_watchdog_stall_rescue_and_auto_keepalive(self) -> None:
        guard = self.store.get_guard()
        guard.update_lease(
            self.cid,
            phase="LLM_INFLIGHT",
            detail="thinking",
            modified_file="src/auth.py",
            last_test_status="FAIL (exit 1)",
        )
        # Simulate stall (240s elapsed in LLM_INFLIGHT)
        w_sessions = guard.list_watchdog_sessions(now_ts=time.time() + 240)
        self.assertTrue(w_sessions[0]["stalled"])
        self.assertEqual(w_sessions[0]["phase"], "STALLED")

        # Build 1-click rescue brief
        rb = guard.build_rescue_brief(self.cid)
        self.assertIn("src/auth.py", rb["rescue_markdown"])
        self.assertIn("FAIL (exit 1)", rb["rescue_markdown"])

        # Auto-Keepalive test (with warm transcript timestamps & 1-ping cap)
        now_dt = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - 255))
        tx_warm = self.tmp_path / "warm_conv" / ".system_generated" / "logs" / "transcript.jsonl"
        tx_warm.parent.mkdir(parents=True, exist_ok=True)
        tx_warm.write_text(
            json.dumps(
                {
                    "step_index": 1,
                    "source": "MODEL",
                    "type": "PLANNER_RESPONSE",
                    "created_at": now_dt,
                    "model": "gemini-4-carbon-high",
                    "input_tokens": 1000,
                    "cache_read_tokens": 25000,
                    "output_tokens": 100,
                }
            ) + "\n",
            encoding="utf-8",
        )
        self.store.register_session("conv-warm", transcript_path=str(tx_warm))
        guard.update_lease("conv-warm", phase="IDLE")
        guard.set_session_keepalive_mode("conv-warm", "auto")

        sent_to: list[str] = []
        r1 = guard.tick_auto_keepalive("conv-warm", send_fn=lambda c, _m: (sent_to.append(c) or True))
        self.assertEqual(r1["pinged"], ["conv-warm"])
        # Second tick hits max_pings=1 cap -> does NOT spam!
        r2 = guard.tick_auto_keepalive("conv-warm", send_fn=lambda c, _m: (sent_to.append(c) or True))
        self.assertEqual(r2["pinged"], [])

    def test_fast_batch_and_fts5_vault_tools(self) -> None:
        guard = self.store.get_guard()
        sample_py = self.tmp_path / "sample_api.py"
        sample_py.write_text("class Router:\n    def dispatch(self, req):\n        return 'ok'\n", encoding="utf-8")

        bs = guard.batch_search([{"pattern": "dispatch", "type": "text"}], cwd=str(self.tmp_path), conversation_id=self.cid)
        self.assertIn("sample_api.py", bs["formatted"])

        rs = guard.read_slices(
            outlines=[str(sample_py)],
            slices=[{"path": str(sample_py), "ranges": [[1, 3]]}],
            cwd=str(self.tmp_path),
            conversation_id=self.cid,
        )
        self.assertIn("OUTLINE", rs)
        self.assertIn("Router", rs)

        rc = guard.run_checks(
            [{"name": "py-ver", "command": f'"{sys.executable}" -c "print(123)"'}],
            cwd=str(self.tmp_path),
            conversation_id=self.cid,
        )
        self.assertIn("[PASS] py-ver", rc)

        idx = guard.ctx_index(
            text="# Architecture\nUse WAL mode.\n## Caching\nKeep prefix deterministic.\n",
            label="arch-doc",
            conversation_id=self.cid,
        )
        self.assertEqual(idx["status"], "INDEXED")
        vhits = guard.ctx_vault_search("deterministic")
        self.assertGreater(len(vhits), 0)

        ex = guard.ctx_execute("print(sum(range(10)))", language="python", conversation_id=self.cid)
        self.assertEqual(ex["exit_code"], 0)
        self.assertIn("45", ex["output"])


class TestHooksMCPCLIAndHUD(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.tmp_path = Path(self.tmp.name)
        self.data_dir = self.tmp_path / "data"
        self.tx_path, _ = _write_sample_transcript(self.tmp_path / "conv_h", num_turns=10, input_tokens=280000)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_zero_prefix_pollution_hooks_and_stop_contract(self) -> None:
        common = {
            "conversationId": "conv-hook-v3",
            "workspacePaths": [str(self.tmp_path)],
            "transcriptPath": str(self.tx_path),
            "artifactDirectoryPath": str(self.tmp_path / "conv_h"),
            "modelName": "gemini-4-carbon-high",
            "cwd": str(self.tmp_path),
        }
        res_start = process_hook({**common, "hookEventName": "SessionStart"}, data_dir=self.data_dir)
        self.assertIn("v3.0 active", res_start["injectSteps"][0]["systemMessage"]["systemMessage"])

        # 280000 + 9*3000 = 307000 / 512000 = 60.0% -> SOFT -> UI-only zero-prefix alert (systemMessage == "")!
        res_pre = process_hook({**common, "hookEventName": "PreInvocation", "invocationNum": 1}, data_dir=self.data_dir)
        sys_obj = res_pre["injectSteps"][0]["systemMessage"]
        self.assertEqual(sys_obj["systemMessage"], "")
        self.assertIn("user_markdown", sys_obj["metadata"])

        # PreToolUse rewrites safe pytest command through cli_filter.py
        res_ptu = process_hook(
            {
                **common,
                "hookEventName": "PreToolUse",
                "toolCall": {"id": "t1", "name": "run_command", "args": {"CommandLine": "pytest tests/"}},
            },
            data_dir=self.data_dir,
        )
        self.assertEqual(res_ptu["decision"], "allow")
        self.assertIn("cli_filter.py", res_ptu["overwrite"]["CommandLine"])

        # Stop returns {"decision": "allow"} with 0 reason injection
        res_stop = process_hook({**common, "hookEventName": "Stop"}, data_dir=self.data_dir)
        self.assertEqual(res_stop, {"decision": "allow"})

    def test_mcp_deterministic_tools_zero_stderr_and_studio_ui(self) -> None:
        process_hook(
            {
                "hookEventName": "SessionStart",
                "conversationId": "conv-mcp-v3",
                "workspacePaths": [str(self.tmp_path)],
                "transcriptPath": str(self.tx_path),
                "artifactDirectoryPath": str(self.tmp_path / "conv_h"),
                "modelName": "gemini-4-carbon-high",
                "cwd": str(self.tmp_path),
            },
            data_dir=self.data_dir,
        )

        server_script = str(PLUGIN_DIR / "server" / "mcp_server.py")
        proc = subprocess.Popen(
            [sys.executable, server_script, "--data-dir", str(self.data_dir)],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        try:
            assert proc.stdin and proc.stdout and proc.stderr

            def send(obj: dict) -> dict | None:
                proc.stdin.write((json.dumps(obj) + "\n").encode("utf-8"))
                proc.stdin.flush()
                if "id" not in obj:
                    return None
                return json.loads(proc.stdout.readline().decode("utf-8"))

            init_resp = send({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2025-06-18"}})
            self.assertEqual(init_resp["result"]["serverInfo"]["version"], "3.0.0")

            l1 = send({"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}})
            l2 = send({"jsonrpc": "2.0", "id": 3, "method": "tools/list", "params": {}})
            # Turn-0 SHA-256 prefix determinism check
            h1 = hashlib.sha256(json.dumps(l1["result"]["tools"], sort_keys=True).encode()).hexdigest()
            h2 = hashlib.sha256(json.dumps(l2["result"]["tools"], sort_keys=True).encode()).hexdigest()
            self.assertEqual(h1, h2)
            tool_names = [t["name"] for t in l1["result"]["tools"]]
            self.assertEqual(tool_names, sorted(tool_names))
            for expected in ("batch_search", "read_slices", "run_checks", "ctx_index", "ctx_execute", "ctx_rescue"):
                self.assertIn(expected, tool_names)

            res_read = send(
                {"jsonrpc": "2.0", "id": 4, "method": "resources/read", "params": {"uri": "ui://billion-context/dashboard.html"}}
            )
            self.assertIn("Billion Context Studio", res_read["result"]["contents"][0]["text"])

            ui_call = send(
                {"jsonrpc": "2.0", "id": 5, "method": "tools/call", "params": {"name": "context_estimator_ui", "arguments": {"conversation_id": "conv-mcp-v3"}}}
            )
            self.assertEqual(ui_call["result"]["structuredContent"]["estimator"]["sample_model_display"], "Gemini 4 Carbon 高")

            audit_call = send(
                {"jsonrpc": "2.0", "id": 6, "method": "tools/call", "params": {"name": "app_audit_prefix", "arguments": {}}}
            )
            self.assertGreater(audit_call["result"]["structuredContent"]["mcp_turn0_tokens"], 0)
            self.assertGreaterEqual(audit_call["result"]["structuredContent"]["skills_scanned"], 1)
        finally:
            if proc.stdin:
                proc.stdin.close()
            proc.wait(timeout=5)
            stderr_bytes = proc.stderr.read() if proc.stderr else b""
            if proc.stdout:
                proc.stdout.close()
            if proc.stderr:
                proc.stderr.close()
            # Exact 0-byte stderr invariant
            self.assertEqual(stderr_bytes, b"")

    def test_dwm_sdf_anti_aliased_hud_and_cli(self) -> None:
        from desktop_widget import ContextEstimatorApp
        from scripts.chatbar_widget import render_aa_button_ppm

        ppm = render_aa_button_ppm(32, 42.0, True, (16, 185, 129), (56, 189, 248), False, False)
        self.assertTrue(ppm.startswith(b"P6\n32 32\n255\n"))

        store = ACPStore(data_dir=self.data_dir)
        store.register_session(
            conversation_id="conv-hud-1",
            transcript_path=str(self.tx_path),
            artifact_dir=str(self.tmp_path / "conv_h"),
            workspace_paths=[str(self.tmp_path)],
            model_name="gemini-4-carbon-high",
        )
        app = ContextEstimatorApp(data_dir=self.data_dir, poll_ms=60000, auto_dock=False)
        try:
            app.open_popover()
            self.assertTrue(app.popover_open)
            self.assertEqual(app.val_labels["sample_model"].cget("text"), "Gemini 4 Carbon 高")
            app.cycle_keepalive_mode()
            self.assertIn("自适应", app.btn_keepalive.cget("text"))
            app.copy_rescue_brief_now()
            app.close_popover()
            self.assertFalse(app.popover_open)
        finally:
            app.quit()

        buf = io.StringIO()
        with redirect_stdout(buf):
            rc = bili.main(["--data-dir", str(self.data_dir), "mode", "fast-32k"])
        self.assertEqual(rc, 0)
        self.assertIn("fast-32k", buf.getvalue())

        buf_audit = io.StringIO()
        with redirect_stdout(buf_audit):
            rc_audit = bili.main(["--data-dir", str(self.data_dir), "audit", "--workspace", str(PLUGIN_DIR)])
        self.assertEqual(rc_audit, 0)
        self.assertIn("MCP Turn-0 Budget", buf_audit.getvalue())

    def test_diff_read_guard_watchdog_sidecar_and_agentapi_audit(self) -> None:
        import os
        from sidecars.watchdog.watchdog_sidecar import run_once as sidecar_run_once

        store = ACPStore(data_dir=self.data_dir)
        store.register_session(
            conversation_id="conv-v3-diff",
            transcript_path=str(self.tx_path),
            artifact_dir=str(self.tmp_path / "conv_h"),
            workspace_paths=[str(self.tmp_path)],
            model_name="gemini-4-carbon-high",
        )
        guard = store.get_guard()
        guard.update_settings({"diff_read": True, "dedup_reads": True})

        src = self.tmp_path / "sample_mod.py"
        src.write_text("\n".join(f"line_{i} = {i}  # padding_for_diff_read_test" for i in range(220)) + "\n", encoding="utf-8")

        # 1st whole-file read allowed & recorded in file_snapshots
        d1 = guard.evaluate_pre_read("conv-v3-diff", {"Path": str(src)})
        self.assertEqual(d1["decision"], "allow")

        # Modify file with distinct mtime -> 2nd whole-file read triggers Diff-Read Guard with unified diff hunk
        src.write_text(
            "\n".join(f"line_{i} = {i if i != 10 else 999}  # padding_for_diff_read_test" for i in range(220)) + "\n",
            encoding="utf-8",
        )
        st_now = src.stat()
        os.utime(src, ns=(st_now.st_atime_ns, st_now.st_mtime_ns + 1_000_000_000))
        d2 = guard.evaluate_pre_read("conv-v3-diff", {"Path": str(src)})
        self.assertEqual(d2["decision"], "deny")
        self.assertIn("Diff-Read Guard", d2["reason"])
        self.assertIn("+line_10 = 999", d2["reason"])

        # 2nd strike passes through immediately
        d3 = guard.evaluate_pre_read("conv-v3-diff", {"Path": str(src)})
        self.assertEqual(d3["decision"], "allow")

        # Watchdog sidecar tick writes acp_rescue.md when stalled and updates heartbeat
        guard.update_lease("conv-v3-diff", phase="LLM_INFLIGHT")
        with store._connect() as conn:
            conn.execute(
                "UPDATE watchdog_leases SET updated_wall_ts = ? WHERE conversation_id = ?",
                (time.time() - 400.0, "conv-v3-diff"),
            )
        res_tick = sidecar_run_once(store, worker_id="sidecar:watchdog-test")
        self.assertGreaterEqual(res_tick["stalled"], 1)
        self.assertTrue((self.tmp_path / "conv_h" / "acp_rescue.md").exists())
        health = guard.get_watchdog_health()
        self.assertTrue(health["watchdog_active"])
        self.assertEqual(health["worker_id"], "sidecar:watchdog-test")

        # Turn-0 audit & agentapi probe
        audit = guard.audit_prefix_and_skills(str(PLUGIN_DIR))
        self.assertGreater(audit["mcp_turn0_tokens"], 0)
        self.assertGreaterEqual(audit["skills_scanned"], 1)
        cmd_probe = guard.resolve_agentapi_executable()
        if cmd_probe is not None:
            self.assertIsInstance(cmd_probe, list)
            self.assertGreater(len(cmd_probe), 0)

        # Recent-tail hard protection (acp-kernel parity)
        with self.assertRaises(ValueError) as ctx_err:
            store.compress_steps(
                conversation_id="conv-v3-diff",
                range_ref="s00000..s00028",
                title="Intrude tail",
                summary="Should be blocked by recent working tail protection.",
            )
        self.assertIn("protected recent working tail", str(ctx_err.exception))

        # Valid historical capture + Pin + Post-/compact automatic LSM rehydration
        cap = store.compress_steps(
            conversation_id="conv-v3-diff",
            range_ref="s00000..s00010",
            title="Initial setup",
            summary="Initialized WAL schema and verified 512K window.",
        )
        self.assertEqual(cap["status"], "COMPRESSED")
        store.pin(
            title="Zero-dep invariant",
            content="Use Python 3.12 stdlib only.",
            conversation_id="conv-v3-diff",
            scope="workspace",
            category="architecture",
        )
        res_rehyd = process_hook(
            {
                "hookEventName": "PreInvocation",
                "conversationId": "conv-v3-diff",
                "workspacePaths": [str(self.tmp_path)],
                "transcriptPath": str(self.tx_path),
                "artifactDirectoryPath": str(self.tmp_path / "conv_h"),
                "modelName": "gemini-4-carbon-high",
                "cwd": str(self.tmp_path),
                "lastUserInput": "/compact",
            },
            data_dir=self.data_dir,
        )
        rehyd_texts = [
            s["systemMessage"]["systemMessage"]
            for s in res_rehyd.get("injectSteps", [])
            if s.get("systemMessage", {}).get("systemMessage")
        ]
        self.assertTrue(any("<acp-memory-rehydration" in t and "Zero-dep invariant" in t for t in rehyd_texts))

        # Dashboard UI uses dropdown menu + live auto-refresh + dynamic window label
        html_ui = (PLUGIN_DIR / "ui" / "dashboard.html").read_text(encoding="utf-8")
        self.assertIn('id="navDropdown"', html_ui)
        self.assertIn('id="lblWindowCap"', html_ui)
        self.assertIn("setInterval", html_ui)
        self.assertNotIn("overflow-x: auto", html_ui)

        # Dynamic model context window detection (256K / 512K / 200K / 1M) & mid-session switch
        from core.acp_store import detect_physical_window, format_window_label

        self.assertEqual(format_window_label(detect_physical_window("gpt-5.4")), "256K")
        self.assertEqual(format_window_label(detect_physical_window("qwen3-coder-256k")), "256K")
        self.assertEqual(format_window_label(detect_physical_window("gemini-4-neon-medium")), "512K")
        self.assertEqual(format_window_label(detect_physical_window("claude-sonnet-4")), "200K")
        self.assertEqual(format_window_label(detect_physical_window("gemini-2.5-pro")), "1M")

        tx_256, _ = _write_sample_transcript(self.tmp_path / "conv_256", num_turns=4, input_tokens=64000)
        raw_lines = tx_256.read_text(encoding="utf-8").replace("gemini-4-carbon-high", "gpt-5.4")
        tx_256.write_text(raw_lines, encoding="utf-8")
        store.register_session("conv-256k", transcript_path=str(tx_256), model_name="gpt-5.4")
        snap_256 = store.get_estimator_snapshot("conv-256k")
        self.assertEqual(snap_256["estimator"]["window_label"], "256K")
        self.assertIn("/ 256K", snap_256["estimator"]["usage_display"])

        # Per-conversation isolation: new/empty session resets completely without leaking prior session data
        snap_empty = store.get_estimator_snapshot("__empty__")
        self.assertIsNone(snap_empty["conversation_id"])
        self.assertTrue(snap_empty.get("is_empty_session"))
        self.assertEqual(snap_empty["estimator"]["usage_display"], "新会话待开始")
        self.assertEqual(snap_empty["blocks"], [])
        self.assertEqual(snap_empty["guard"]["combined_saved_display"], "0")

        snap_unseen = store.get_estimator_snapshot("conv-brand-new-unseen-999")
        self.assertIsNone(snap_unseen["conversation_id"])
        self.assertEqual(snap_unseen["blocks"], [])


if __name__ == "__main__":
    unittest.main()
