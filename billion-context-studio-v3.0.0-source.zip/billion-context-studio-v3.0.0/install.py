"""Install or uninstall the billion-context plugin into Antigravity's global plugins directory."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

SOURCE_DIR = Path(__file__).resolve().parent / "plugin"
TARGET_DIR = Path.home() / ".gemini" / "config" / "plugins" / "billion-context"

IGNORE_NAMES = {"__pycache__", ".pytest_cache", "data"}


def _should_ignore(rel_parts: tuple[str, ...]) -> bool:
    return any(part in IGNORE_NAMES or part.endswith(".pyc") for part in rel_parts)


def install() -> None:
    if not SOURCE_DIR.exists():
        raise FileNotFoundError(f"Plugin source directory not found: {SOURCE_DIR}")

    TARGET_DIR.mkdir(parents=True, exist_ok=True)
    copied = 0
    for src in SOURCE_DIR.rglob("*"):
        rel = src.relative_to(SOURCE_DIR)
        if _should_ignore(rel.parts):
            continue
        dst = TARGET_DIR / rel
        if src.is_dir():
            dst.mkdir(parents=True, exist_ok=True)
        else:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            copied += 1

    print(f"Synced {copied} files for billion-context plugin to: {TARGET_DIR}")


def uninstall() -> None:
    if TARGET_DIR.exists():
        shutil.rmtree(TARGET_DIR)
        print(f"Removed plugin directory: {TARGET_DIR}")
    else:
        print(f"Plugin directory not present: {TARGET_DIR}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Manage billion-context Antigravity plugin installation")
    parser.add_argument("--uninstall", action="store_true", help="Remove the plugin from ~/.gemini/config/plugins/")
    args = parser.parse_args()
    if args.uninstall:
        uninstall()
    else:
        install()


if __name__ == "__main__":
    main()
