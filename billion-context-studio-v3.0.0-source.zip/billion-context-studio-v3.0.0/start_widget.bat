@echo off
start "" pythonw "%~dp0launch_widget.pyw" --singleton
