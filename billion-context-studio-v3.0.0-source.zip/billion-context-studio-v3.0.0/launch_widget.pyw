"""Windowless launcher for desktop_widget.py (pythonw.exe compatible)."""

from desktop_widget import main

if __name__ == "__main__":
    main()
