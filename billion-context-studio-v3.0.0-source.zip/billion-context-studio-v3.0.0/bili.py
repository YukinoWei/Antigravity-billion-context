"""bili — CLI for Billion-Context Studio v3.0 (ACP + KV-Cache Guard + Fast Batch + Rescue)."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import urllib.request
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent
PLUGIN_DIR = ROOT_DIR / "plugin"
if str(PLUGIN_DIR) not in sys.path:
    sys.path.insert(0, str(PLUGIN_DIR))

from core.acp_store import ACPStore, default_data_dir  # noqa: E402
from core.guard_engine import extract_code_outline  # noqa: E402
import install as installer  # noqa: E402


def _refresh_mcp_server() -> bool:
    addr = os.environ.get("ANTIGRAVITY_LS_ADDRESS")
    token = os.environ.get("ANTIGRAVITY_CSRF_TOKEN")
    if not addr or not token:
        return False
    url = f"http://{addr}/exa.language_server_pb.LanguageServerService/RefreshMcpServers"
    req = urllib.request.Request(
        url,
        data=json.dumps({"serverName": "billion-context_acp"}).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "x-codeium-csrf-token": token,
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=4) as resp:
            return 200 <= resp.status < 300
    except Exception:
        return False


def cmd_status(store: ACPStore, args: argparse.Namespace) -> int:
    snap = store.get_estimator_snapshot(conversation_id=args.cid)
    st = store.get_status(conversation_id=args.cid, detail="full" if args.full else "compact")
    if args.json:
        st["kv_cache"] = snap["kv_cache"]
        st["guard"] = snap["guard"]
        print(json.dumps(st, indent=2, ensure_ascii=False))
        return 0
    if st.get("status") == "NO_SESSION":
        print("[bili] No active Antigravity session recorded yet.")
        return 0

    tel = st["telemetry"]
    lsm = st["lsm_memory"]
    kv = snap["kv_cache"]
    guard = snap["guard"]
    cfg = snap["settings"]
    win_lbl = tel.get("window_label", "512K")
    print(f"=== Billion-Context Studio v3.0 ({st['conversation_id']}) ===")
    print(f"  Model             : {snap['estimator']['sample_model_display']} ({st.get('model_name')})")
    print(
        f"  Context ({win_lbl:<4})    : {tel['logical_working_tokens']:,} / {tel['effective_budget_tokens']:,} "
        f"({tel['pressure_percent']} -> {tel['pressure_level']}) | Physical: {tel['physical_prompt_tokens']:,}"
    )
    print(
        f"  KV-Cache & Speed  : {tel['cache_hit_percent']} hit | {kv['warmth']} ({kv['ttl_display']}) | "
        f"Saved ~${kv['estimated_cache_usd_saved']:.4f} | {snap['estimator']['request_speed_display']}"
    )
    print(
        f"  Quota Guards      : preset={cfg['read_preset']} | keepalive={cfg['keepalive_mode']} | "
        f"Combined Saved={guard['combined_saved_display']} tokens"
    )
    print(
        f"  Workspace Ledger  : {tel['workspace_cumulative_tokens']:,} cumulative tokens across "
        f"{tel['workspace_sessions_count']} session(s)"
    )
    tc = lsm["tier_counts"]
    print(f"  LSM Memory Tree   : T1={tc['T1']}  T2={tc['T2']}  T3={tc['T3']} | Pins={lsm['pins_count']}")
    return 0


def cmd_doctor(store: ACPStore) -> int:
    installed_dir = installer.TARGET_DIR
    ui_html = PLUGIN_DIR / "ui" / "dashboard.html"
    checks = {
        "version": "3.0.0",
        "plugin_source_dir": str(PLUGIN_DIR),
        "plugin_installed": installed_dir.exists(),
        "installed_path": str(installed_dir),
        "data_dir": str(store.data_dir),
        "db_exists": store.db_path.exists(),
        "fts5_enabled": store._fts_available,
        "ui_bundle_exists": ui_html.exists(),
        "watchdog_health": store.get_guard().get_watchdog_health(),
        "settings": store.get_guard().get_settings(),
    }
    print(json.dumps(checks, indent=2, ensure_ascii=False))
    return 0


def cmd_audit(store: ACPStore, args: argparse.Namespace) -> int:
    report = store.get_guard().audit_prefix_and_skills(workspace_dir=args.workspace or os.getcwd())
    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
        return 0
    print("=== Billion-Context Turn-0 Prefix & Skills Audit ===")
    print(f"  MCP Server       : {report['mcp_server']} ({report['tool_count']} tools, sha256={report['mcp_sha256']})")
    print(f"  MCP Turn-0 Budget: ~{report['mcp_turn0_tokens']:,} tokens")
    print(f"  Skills Scanned   : {report['skills_scanned']} skills (~{report['skills_frontmatter_tokens']:,} frontmatter tokens)")
    print(f"  Combined Turn-0  : ~{report['total_turn0_overhead_tokens']:,} tokens")
    for sk in report["skills"][:8]:
        flag = " [BLOATED >120]" if sk["bloated_frontmatter"] else ""
        print(f"    - {sk['name']}: {sk['frontmatter_tokens']} tok / {sk['total_lines']} lines{flag}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="bili", description="Billion-Context Studio v3.0 CLI")
    p.add_argument("--data-dir", default=None, help="Override ACP SQLite data directory")
    sub = p.add_subparsers(dest="cmd", required=True)

    sp_st = sub.add_parser("status", help="Show 512K context, KV-cache warmth, guard savings, & LSM status")
    sp_st.add_argument("--cid", default=None)
    sp_st.add_argument("--full", action="store_true")
    sp_st.add_argument("--json", action="store_true")

    sp_bl = sub.add_parser("blocks", help="List active T1/T2/T3 LSM memory blocks")
    sp_bl.add_argument("--cid", default=None)

    sp_se = sub.add_parser("search", help="Unified search across pins, LSM blocks, FTS5 vault, & transcripts")
    sp_se.add_argument("query")
    sp_se.add_argument("--cid", default=None)
    sp_se.add_argument("--scope", choices=["all", "blocks", "transcript", "pins", "vault"], default="all")
    sp_se.add_argument("--limit", type=int, default=10)

    sp_de = sub.add_parser("decompress", help="Decompress a block_id or range_ref")
    sp_de.add_argument("target")
    sp_de.add_argument("--cid", default=None)
    sp_de.add_argument("--depth", choices=["raw", "children"], default="raw")

    sp_re = sub.add_parser("rescue", help="Generate a 1-click Crash/Stall Session Rescue Brief")
    sp_re.add_argument("--cid", default=None)

    sp_mo = sub.add_parser("mode", help="Set Read Quota Guard preset")
    sp_mo.add_argument("preset", choices=["host-45k", "fast-32k", "balanced-16k", "strict-8k", "off"])

    sp_ka = sub.add_parser("keepalive", help="Set global KV-Cache Auto-Keepalive schedule")
    sp_ka.add_argument("schedule", choices=["off", "auto", "4m", "9m", "15m"])

    sp_ou = sub.add_parser("outline", help="Print compact symbol outline of a file")
    sp_ou.add_argument("file")

    sp_cp = sub.add_parser("checkpoint", help="Create or view continuation checkpoint")
    sp_cp.add_argument("--cid", default=None)
    sp_cp.add_argument("--latest", action="store_true")
    sp_cp.add_argument("--goal", default="")

    sub.add_parser("install", help="Install/sync billion-context into ~/.gemini/config/plugins/")
    sub.add_parser("uninstall", help="Uninstall billion-context from ~/.gemini/config/plugins/")
    sub.add_parser("doctor", help="Run health & settings diagnostics")
    sp_au = sub.add_parser("audit", help="Audit Turn-0 MCP prefix budget & Skills frontmatter tax")
    sp_au.add_argument("--workspace", default=None)
    sp_au.add_argument("--json", action="store_true")
    sub.add_parser("widget", help="Launch the DWM anti-aliased chat-bar HUD")
    return p


def main(argv: list[str] | None = None) -> int:
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8")
        except Exception:
            pass

    parser = build_parser()
    args = parser.parse_args(argv)

    if args.cmd == "install":
        installer.install()
        if _refresh_mcp_server():
            print("[bili] Hot-reloaded running MCP server: billion-context_acp")
        return 0
    if args.cmd == "uninstall":
        installer.uninstall()
        return 0
    if args.cmd == "widget":
        py_exe = Path(sys.executable)
        pyw_exe = py_exe.with_name("pythonw.exe")
        runner = str(pyw_exe if pyw_exe.exists() else py_exe)
        subprocess.Popen([runner, str(PLUGIN_DIR / "scripts" / "chatbar_widget.py"), "--singleton"])
        print("[bili] Launched DWM anti-aliased chat-bar HUD.")
        return 0
    if args.cmd == "outline":
        info = extract_code_outline(args.file, max_lines=80)
        print(f"=== {info['path']} ({info.get('total_lines', 0)} lines) ===")
        print("\n".join(info["outline"]))
        return 0

    store = ACPStore(data_dir=args.data_dir or default_data_dir())
    guard = store.get_guard()

    if args.cmd == "status":
        return cmd_status(store, args)
    if args.cmd == "doctor":
        return cmd_doctor(store)
    if args.cmd == "audit":
        return cmd_audit(store, args)
    if args.cmd == "mode":
        updated = guard.update_settings({"read_preset": args.preset})
        print(f"[bili] Read Quota Guard preset -> {updated['read_preset']}")
        return 0
    if args.cmd == "keepalive":
        updated = guard.update_settings({"keepalive_mode": args.schedule})
        print(f"[bili] Global Auto-Keepalive -> {updated['keepalive_mode']}")
        return 0
    if args.cmd == "rescue":
        rb = guard.build_rescue_brief(conversation_id=args.cid)
        print(rb["rescue_markdown"])
        return 0
    if args.cmd == "blocks":
        sess = store.resolve_session(args.cid)
        if not sess:
            print("[bili] No session found.")
            return 1
        for b in store.get_active_blocks(sess["conversation_id"], include_workspace_milestones=True):
            print(f"[{b['block_id']} | T{b['tier']} | {b['range_ref']}] {b['title']}: {b['summary'][:200]}")
        return 0
    if args.cmd == "search":
        if args.scope == "vault":
            for h in guard.ctx_vault_search(args.query, limit=args.limit):
                print(f"[vault | {h['source_id']}] {h['label']} · {h['heading']}\n  {h['snippet'][:200]}")
            return 0
        res = store.search_context(args.query, conversation_id=args.cid, scope=args.scope, limit=args.limit)
        for h in res["hits"]:
            print(f"[{h['source']} | {h['ref']}] {h.get('title') or ''}\n  {h['snippet'][:200]}")
        return 0
    if args.cmd == "decompress":
        t = args.target.strip()
        res = (
            store.decompress(conversation_id=args.cid, block_id=t, depth=args.depth)
            if (t.startswith("b") and t[1:].isdigit())
            else store.decompress(conversation_id=args.cid, range_ref=t, depth=args.depth)
        )
        print(res["transcript_excerpt"])
        return 0
    if args.cmd == "checkpoint":
        if args.latest:
            cp = store.get_latest_checkpoint(conversation_id=args.cid)
            print(cp["packet_markdown"] if cp else "[bili] No checkpoint found.")
            return 0
        cp = store.create_checkpoint(conversation_id=args.cid, current_goal=args.goal, reason="bili_cli")
        print(f"[bili] Created checkpoint {cp['checkpoint_id']} -> {cp.get('artifact_path')}")
        return 0
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
