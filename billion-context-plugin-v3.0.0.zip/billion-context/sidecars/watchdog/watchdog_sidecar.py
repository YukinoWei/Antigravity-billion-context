"""Native Antigravity Sidecar daemon for Billion-Context Watchdog & Auto-Keepalive.

Runs continuously under Antigravity's Sidecar lifecycle manager (where `agentapi` is on PATH)
with zero polling impact on the main chat context:
  - Evaluates idle sessions for KV-Cache Auto-Keepalive (`agentapi send-message`)
  - Detects stalled sessions (`LLM_INFLIGHT > 180s` or `TOOL_RUNNING > 300s`) and writes
    automatic `acp_rescue.md` recovery packets to their artifact directories
  - Records live heartbeats in `watchdog_heartbeats` for Studio UI & `bili doctor`
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

SIDECAR_DIR = Path(__file__).resolve().parent
PLUGIN_ROOT = SIDECAR_DIR.parent.parent
if str(PLUGIN_ROOT) not in sys.path:
    sys.path.insert(0, str(PLUGIN_ROOT))

from core.acp_store import ACPStore  # noqa: E402


def run_once(store: ACPStore, worker_id: str = "sidecar:watchdog") -> dict[str, int]:
    guard = store.get_guard()
    ka_res = guard.tick_auto_keepalive()
    sessions = guard.list_watchdog_sessions()
    stalled = [s for s in sessions if s.get("stalled")]
    for st in stalled:
        cid = st["conversation_id"]
        sess = store.resolve_session(cid)
        if sess and sess.get("artifact_dir"):
            try:
                rb = guard.build_rescue_brief(cid)
                out_path = Path(sess["artifact_dir"]) / "acp_rescue.md"
                out_path.parent.mkdir(parents=True, exist_ok=True)
                out_path.write_text(rb["rescue_markdown"], encoding="utf-8")
            except Exception:
                pass
    guard.record_watchdog_heartbeat(
        worker_id=worker_id,
        stalled_count=len(stalled),
        detail=f"pinged={len(ka_res.get('pinged', []))}, sessions={len(sessions)}",
    )
    return {
        "evaluated": len(sessions),
        "pinged": len(ka_res.get("pinged", [])),
        "stalled": len(stalled),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Billion-Context Native Watchdog Sidecar")
    parser.add_argument("--data-dir", default=None, help="ACP plugin_data directory")
    parser.add_argument("--interval", type=float, default=20.0, help="Poll interval in seconds")
    parser.add_argument("--once", action="store_true", help="Run a single tick and exit")
    args = parser.parse_args()

    store = ACPStore(data_dir=args.data_dir)
    if args.once:
        run_once(store)
        return

    while True:
        try:
            run_once(store)
        except Exception:
            pass
        time.sleep(max(5.0, args.interval))


if __name__ == "__main__":
    main()
