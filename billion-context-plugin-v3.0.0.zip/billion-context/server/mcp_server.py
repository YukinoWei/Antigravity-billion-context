"""Pure-stdlib MCP (Model Context Protocol) Stdio Server for Billion-Context v3.0.

Fuses `ranxianglei/billion-context` (ACP LSM Tree) + `zou172866/Antigravity-agy-dart`
(KV-Cache Warmth & Auto-Keepalive, Quota Guards, Fast Batch Tools, FTS5 Vault, & Crash Rescue).

Invariants:
  - 0 external dependencies (Python 3.12 stdlib only)
  - 0-byte stderr pollution
  - Canonical sorted `tools/list` for 100% deterministic Turn-0 prefix fingerprint
  - All model-facing tool text responses strictly `<= 8.8 KB` UTF-8 safe
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
if str(PLUGIN_ROOT) not in sys.path:
    sys.path.insert(0, str(PLUGIN_ROOT))

from core.acp_store import ACPStore  # noqa: E402
from core.guard_engine import MAX_INLINE_UTF8_BYTES, truncate_utf8_safe  # noqa: E402

SUPPORTED_PROTOCOL_VERSIONS = ("2025-06-18", "2025-03-26", "2024-11-05")
APP_URI = "ui://billion-context/dashboard.html"
UI_FILE = PLUGIN_ROOT / "ui" / "dashboard.html"
LEGACY_UI_FILE = PLUGIN_ROOT / "ui" / "context_estimator.html"
UI_MIME_TYPE = "text/html;profile=mcp-app"

_RAW_TOOLS_SPEC: list[dict[str, Any]] = [
    {
        "name": "acp_status",
        "description": (
            "Inspect current Antigravity session 512K context telemetry, KV-cache warmth & TTL countdown, "
            "prompt cache hit rate, guard token savings, LSM memory blocks (T1/T2/T3), pinned invariants, "
            "and semantic episode ranges ready to compress."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "conversation_id": {"type": "string", "description": "Optional conversation ID."},
                "detail": {"type": "string", "enum": ["compact", "full"], "default": "compact"},
            },
        },
    },
    {
        "name": "compress",
        "description": (
            "Active Context Pruning (acp-kernel pipeline): fold older steps into a T1 Capture block "
            "(operation='capture', auto-harvesting touched files, commands, and skill boundaries), or merge "
            "2+ blocks into T2 Milestone / T3 Epoch blocks (operation='distill'|'condense')."
        ),
        "inputSchema": {
            "type": "object",
            "required": ["title", "summary"],
            "properties": {
                "conversation_id": {"type": "string"},
                "operation": {"type": "string", "enum": ["capture", "distill", "condense"]},
                "mode": {"type": "string", "enum": ["steps", "blocks"], "default": "steps"},
                "range_ref": {"type": "string", "description": "e.g. 's00000..s00025'"},
                "start_step": {"type": "integer"},
                "end_step": {"type": "integer"},
                "block_ids": {"type": "array", "items": {"type": "string"}},
                "title": {"type": "string"},
                "summary": {"type": "string"},
                "entities": {"type": "array", "items": {"type": "string"}},
                "decisions": {"type": "array", "items": {"type": "string"}},
                "open_questions": {"type": "array", "items": {"type": "string"}},
            },
        },
    },
    {
        "name": "decompress",
        "description": (
            "Reversibly restore child block summaries (depth='children') or verbatim steps from "
            "transcript_full.jsonl (depth='raw') for any compressed block_id across the workspace."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "conversation_id": {"type": "string"},
                "block_id": {"type": "string"},
                "range_ref": {"type": "string"},
                "start_step": {"type": "integer"},
                "end_step": {"type": "integer"},
                "depth": {"type": "string", "enum": ["raw", "children"], "default": "raw"},
                "offset_step": {"type": "integer"},
                "include_thinking": {"type": "boolean", "default": False},
                "max_chars": {"type": "integer", "default": 8000},
            },
        },
    },
    {
        "name": "search_context",
        "description": (
            "Search across compressed LSM blocks (T1/T2/T3), pinned invariants, indexed FTS5 vault docs/logs, "
            "and full transcripts across the workspace by keywords or regex."
        ),
        "inputSchema": {
            "type": "object",
            "required": ["query"],
            "properties": {
                "query": {"type": "string"},
                "conversation_id": {"type": "string"},
                "scope": {"type": "string", "enum": ["all", "blocks", "transcript", "pins", "vault"], "default": "all"},
                "workspace_wide": {"type": "boolean", "default": True},
                "limit": {"type": "integer", "default": 10},
            },
        },
    },
    {
        "name": "pin_context",
        "description": "Pin, update (deduplicated by title), unpin, or list protected invariants across compression and handoffs.",
        "inputSchema": {
            "type": "object",
            "required": ["action"],
            "properties": {
                "action": {"type": "string", "enum": ["pin", "unpin", "list"]},
                "conversation_id": {"type": "string"},
                "scope": {"type": "string", "enum": ["conversation", "workspace"], "default": "conversation"},
                "category": {"type": "string", "enum": ["invariant", "decision", "architecture", "file", "todo", "note"], "default": "invariant"},
                "title": {"type": "string"},
                "content": {"type": "string"},
                "pin_id": {"type": "string"},
                "step_ref": {"type": "integer"},
            },
        },
    },
    {
        "name": "handoff_checkpoint",
        "description": "Create or retrieve a lossless Session Continuation Packet for /compact or fresh session resumption.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {"type": "string", "enum": ["create", "latest", "list"], "default": "create"},
                "conversation_id": {"type": "string"},
                "current_goal": {"type": "string"},
                "next_steps": {"type": "array", "items": {"type": "string"}},
                "write_artifact": {"type": "boolean", "default": True},
            },
        },
    },
    {
        "name": "batch_search",
        "description": "Run up to 12 literal, regex, or file-glob searches across the workspace in a single turn (<=8.8KB).",
        "inputSchema": {
            "type": "object",
            "required": ["queries"],
            "properties": {
                "queries": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "required": ["pattern"],
                        "properties": {
                            "pattern": {"type": "string"},
                            "type": {"type": "string", "enum": ["text", "regex", "glob"], "default": "text"},
                            "glob": {"type": "string", "default": "*"},
                            "max_results": {"type": "integer", "default": 20},
                        },
                    },
                },
                "cwd": {"type": "string"},
                "conversation_id": {"type": "string"},
            },
        },
    },
    {
        "name": "read_slices",
        "description": "Batch-extract compact code symbol outlines (`outlines`) and/or targeted line-range slices (`slices`) across multiple files in one turn.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "outlines": {"type": "array", "items": {"type": "string"}, "description": "File paths to outline."},
                "slices": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "required": ["path", "ranges"],
                        "properties": {
                            "path": {"type": "string"},
                            "ranges": {"type": "array", "items": {"type": "array", "items": {"type": "integer"}}},
                        },
                    },
                },
                "cwd": {"type": "string"},
                "conversation_id": {"type": "string"},
            },
        },
    },
    {
        "name": "run_checks",
        "description": "Run up to 6 short test/lint/typecheck commands concurrently, preserving failing stack traces within an 8.8KB budget.",
        "inputSchema": {
            "type": "object",
            "required": ["commands"],
            "properties": {
                "commands": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "required": ["command"],
                        "properties": {
                            "name": {"type": "string"},
                            "command": {"type": "string"},
                            "cwd": {"type": "string"},
                            "timeoutSec": {"type": "integer", "default": 30},
                        },
                    },
                },
                "cwd": {"type": "string"},
                "conversation_id": {"type": "string"},
            },
        },
    },
    {
        "name": "ctx_index",
        "description": "Index long Markdown/docs/logs (`path` or `text`) or SSRF-guarded public `url` by section into local FTS5 vault.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "url": {"type": "string"},
                "text": {"type": "string"},
                "label": {"type": "string", "default": "doc"},
                "conversation_id": {"type": "string"},
            },
        },
    },
    {
        "name": "ctx_execute",
        "description": "Execute a short local Python or PowerShell filter script on huge logs/JSON/CSVs, returning only <=8.8KB summary.",
        "inputSchema": {
            "type": "object",
            "required": ["code"],
            "properties": {
                "intent": {"type": "string"},
                "language": {"type": "string", "enum": ["python", "powershell"], "default": "python"},
                "code": {"type": "string"},
                "cwd": {"type": "string"},
                "timeoutSec": {"type": "integer", "default": 30},
                "conversation_id": {"type": "string"},
            },
        },
    },
    {
        "name": "ctx_rescue",
        "description": "Generate a redacted Crash/Stall Session Rescue Brief (modified files, git status, last test status, pins, LSM blocks) to resume after a hang or /compact.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "conversation_id": {"type": "string"},
            },
        },
    },
    {
        "name": "ctx_purge",
        "description": "Purge indexed FTS5 vault chunks and duplicate-read caches ('stale', 'session', or 'all').",
        "inputSchema": {
            "type": "object",
            "properties": {
                "scope": {"type": "string", "enum": ["stale", "session", "all"], "default": "stale"},
                "conversation_id": {"type": "string"},
            },
        },
    },
    {
        "name": "context_estimator_ui",
        "title": "Billion Context 控制台",
        "description": (
            "Open the Billion-Context Studio plugin control center (上下文估算 · 缓存续温 · 崩溃抢救 · 记忆树 · 护栏配置) "
            "inline in chat, in the side panel, or full-page from the global sidebar."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "conversation_id": {"type": "string"},
            },
        },
        "_meta": {
            "ui": {"resourceUri": APP_URI},
            "com.google.antigravity/ui": {
                "entrypoints": [
                    {"type": "aux_pane", "title": "Billion Context 控制台"},
                    {"type": "global", "title": "Billion Context Studio"},
                ]
            },
        },
    },
    # App-only interactive UI tools
    {
        "name": "app_refresh_estimator",
        "description": "App-only: refresh full plugin dashboard & estimator state.",
        "inputSchema": {"type": "object", "properties": {"conversation_id": {"type": "string"}}},
        "_meta": {"ui": {"visibility": ["app"]}},
    },
    {
        "name": "app_update_settings",
        "description": "App-only: update persistent quota guard & keepalive settings.",
        "inputSchema": {"type": "object", "properties": {"settings": {"type": "object"}, "conversation_id": {"type": "string"}}},
        "_meta": {"ui": {"visibility": ["app"]}},
    },
    {
        "name": "app_set_keepalive",
        "description": "App-only: set per-session or global cache keepalive schedule.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "conversation_id": {"type": "string"},
                "mode": {"type": "string"},
                "max_pings": {"type": "integer"},
            },
        },
        "_meta": {"ui": {"visibility": ["app"]}},
    },
    {
        "name": "app_create_checkpoint",
        "description": "App-only: create a lossless ACP handoff checkpoint.",
        "inputSchema": {"type": "object", "properties": {"conversation_id": {"type": "string"}}},
        "_meta": {"ui": {"visibility": ["app"]}},
    },
    {
        "name": "app_build_rescue",
        "description": "App-only: build a 1-click Crash/Stall Rescue Brief.",
        "inputSchema": {"type": "object", "properties": {"conversation_id": {"type": "string"}}},
        "_meta": {"ui": {"visibility": ["app"]}},
    },
    {
        "name": "app_search_context",
        "description": "App-only: unified search across blocks, pins, vault, and transcripts.",
        "inputSchema": {"type": "object", "required": ["query"], "properties": {"query": {"type": "string"}, "conversation_id": {"type": "string"}}},
        "_meta": {"ui": {"visibility": ["app"]}},
    },
    {
        "name": "app_purge_vault",
        "description": "App-only: purge stale/session/all vault caches.",
        "inputSchema": {"type": "object", "properties": {"scope": {"type": "string"}, "conversation_id": {"type": "string"}}},
        "_meta": {"ui": {"visibility": ["app"]}},
    },
    {
        "name": "app_audit_prefix",
        "description": "App-only: audit Turn-0 MCP tool prefix budget & Skills frontmatter tax.",
        "inputSchema": {"type": "object", "properties": {"conversation_id": {"type": "string"}}},
        "_meta": {"ui": {"visibility": ["app"]}},
    },
]

# Canonical alphabetical sort by tool name for 100% deterministic Turn-0 prefix hash
TOOLS_SPEC: list[dict[str, Any]] = sorted(_RAW_TOOLS_SPEC, key=lambda t: t["name"])


def _write_message(msg: dict[str, Any]) -> None:
    payload = (json.dumps(msg, ensure_ascii=False) + "\n").encode("utf-8")
    sys.stdout.buffer.write(payload)
    sys.stdout.buffer.flush()


def _success(req_id: Any, result: dict[str, Any]) -> dict[str, Any]:
    return {"jsonrpc": "2.0", "id": req_id, "result": result}


def _error(req_id: Any, code: int, message: str) -> dict[str, Any]:
    return {"jsonrpc": "2.0", "id": req_id, "error": {"code": code, "message": message}}


def _text_result(text: str) -> dict[str, Any]:
    return {
        "content": [{"type": "text", "text": truncate_utf8_safe(text, max_bytes=MAX_INLINE_UTF8_BYTES)}],
        "isError": False,
    }


def _handle_tool_call(store: ACPStore, name: str, args: dict[str, Any]) -> dict[str, Any]:
    guard = store.get_guard()

    if name == "acp_status":
        snap = store.get_estimator_snapshot(conversation_id=args.get("conversation_id"))
        st = store.get_status(conversation_id=args.get("conversation_id"), detail=args.get("detail", "compact"))
        st["kv_cache"] = {
            "warmth": snap["kv_cache"]["warmth"],
            "ttl_display": snap["kv_cache"]["ttl_display"],
            "estimated_cache_usd_saved": snap["kv_cache"]["estimated_cache_usd_saved"],
        }
        st["guard_savings"] = snap["guard"]["savings"]
        return _text_result(json.dumps(st, indent=2, ensure_ascii=False))

    if name == "compress":
        op = (args.get("operation") or "").strip().lower()
        mode = args.get("mode", "steps")
        if op in ("distill", "condense") or mode == "blocks" or args.get("block_ids"):
            res = store.compress_blocks(
                conversation_id=args.get("conversation_id"),
                block_ids=args.get("block_ids") or [],
                title=args.get("title", ""),
                summary=args.get("summary", ""),
                entities=args.get("entities"),
                decisions=args.get("decisions"),
                open_questions=args.get("open_questions"),
                operation=op if op in ("distill", "condense") else None,
            )
        else:
            res = store.compress_steps(
                conversation_id=args.get("conversation_id"),
                start_step=int(args["start_step"]) if args.get("start_step") is not None else None,
                end_step=int(args["end_step"]) if args.get("end_step") is not None else None,
                range_ref=args.get("range_ref"),
                title=args.get("title", ""),
                summary=args.get("summary", ""),
                entities=args.get("entities"),
                decisions=args.get("decisions"),
                open_questions=args.get("open_questions"),
            )
        return _text_result(json.dumps(res, indent=2, ensure_ascii=False))

    if name == "decompress":
        res = store.decompress(
            conversation_id=args.get("conversation_id"),
            block_id=args.get("block_id"),
            range_ref=args.get("range_ref"),
            start_step=int(args["start_step"]) if args.get("start_step") is not None else None,
            end_step=int(args["end_step"]) if args.get("end_step") is not None else None,
            depth=str(args.get("depth", "raw")),
            offset_step=int(args["offset_step"]) if args.get("offset_step") is not None else None,
            include_thinking=bool(args.get("include_thinking", False)),
            max_chars=min(8000, int(args.get("max_chars", 8000))),
        )
        return _text_result(json.dumps(res, indent=2, ensure_ascii=False))

    if name == "search_context":
        scope = str(args.get("scope", "all"))
        q = str(args.get("query") or "")
        limit = int(args.get("limit", 10))
        if scope == "vault":
            vhits = guard.ctx_vault_search(q, limit=limit)
            return _text_result(json.dumps({"query": q, "total_hits": len(vhits), "hits": vhits}, indent=2, ensure_ascii=False))
        res = store.search_context(
            query=q,
            conversation_id=args.get("conversation_id"),
            scope=scope,
            workspace_wide=bool(args.get("workspace_wide", True)),
            limit=limit,
        )
        if scope == "all":
            vhits = guard.ctx_vault_search(q, limit=4)
            for vh in vhits:
                res["hits"].append(
                    {
                        "source": "vault",
                        "ref": vh["source_id"],
                        "title": f"{vh['label']} · {vh['heading']}",
                        "snippet": vh["snippet"][:380],
                        "score": 70,
                    }
                )
            res["total_hits"] = len(res["hits"])
        return _text_result(json.dumps(res, indent=2, ensure_ascii=False))

    if name == "pin_context":
        action = args.get("action", "list")
        if action == "pin":
            if not args.get("title") or not args.get("content"):
                raise ValueError("title and content are required when action='pin'")
            res = store.pin(
                title=str(args["title"]),
                content=str(args["content"]),
                conversation_id=args.get("conversation_id"),
                scope=args.get("scope", "conversation"),
                category=args.get("category", "invariant"),
                step_ref=int(args["step_ref"]) if args.get("step_ref") is not None else None,
            )
        elif action == "unpin":
            if not args.get("pin_id"):
                raise ValueError("pin_id is required when action='unpin'")
            res = store.unpin(str(args["pin_id"]))
        else:
            cid = args.get("conversation_id")
            sess = store.resolve_session(cid)
            res = {
                "conversation_id": sess["conversation_id"] if sess else cid,
                "pins": store.list_pins(
                    conversation_id=sess["conversation_id"] if sess else cid,
                    workspace_key=sess.get("workspace_key") if sess else None,
                ),
            }
        return _text_result(json.dumps(res, indent=2, ensure_ascii=False))

    if name == "handoff_checkpoint":
        action = args.get("action", "create")
        sess = store.resolve_session(args.get("conversation_id"))
        cid = sess["conversation_id"] if sess else args.get("conversation_id")
        ws_key = sess.get("workspace_key") if sess else None
        if action == "create":
            res = store.create_checkpoint(
                conversation_id=cid,
                current_goal=str(args.get("current_goal") or ""),
                next_steps=args.get("next_steps") or [],
                reason="manual",
                write_artifact=bool(args.get("write_artifact", True)),
            )
        elif action == "latest":
            cp = store.get_latest_checkpoint(conversation_id=cid, workspace_key=ws_key)
            res = cp if cp else {"status": "NONE", "message": "No checkpoints recorded yet."}
        else:
            res = {"checkpoints": store.list_checkpoints(workspace_key=ws_key)}
        return _text_result(json.dumps(res, indent=2, ensure_ascii=False))

    if name == "batch_search":
        sess = store.resolve_session(args.get("conversation_id"))
        out = guard.batch_search(
            queries=args.get("queries") or [],
            cwd=args.get("cwd") or (sess.get("cwd") if sess else None),
            conversation_id=sess["conversation_id"] if sess else args.get("conversation_id"),
        )
        return _text_result(out["formatted"])

    if name == "read_slices":
        sess = store.resolve_session(args.get("conversation_id"))
        text = guard.read_slices(
            outlines=args.get("outlines"),
            slices=args.get("slices"),
            cwd=args.get("cwd") or (sess.get("cwd") if sess else None),
            conversation_id=sess["conversation_id"] if sess else args.get("conversation_id"),
        )
        return _text_result(text)

    if name == "run_checks":
        sess = store.resolve_session(args.get("conversation_id"))
        text = guard.run_checks(
            commands=args.get("commands") or [],
            cwd=args.get("cwd") or (sess.get("cwd") if sess else None),
            conversation_id=sess["conversation_id"] if sess else args.get("conversation_id"),
        )
        return _text_result(text)

    if name == "ctx_index":
        sess = store.resolve_session(args.get("conversation_id"))
        res = guard.ctx_index(
            path=args.get("path"),
            url=args.get("url"),
            text=args.get("text"),
            label=str(args.get("label") or "doc"),
            conversation_id=sess["conversation_id"] if sess else args.get("conversation_id"),
            workspace_key=(sess.get("workspace_key") or "") if sess else "",
        )
        return _text_result(json.dumps(res, indent=2, ensure_ascii=False))

    if name == "ctx_execute":
        sess = store.resolve_session(args.get("conversation_id"))
        res = guard.ctx_execute(
            code=str(args.get("code") or ""),
            language=str(args.get("language") or "python"),
            cwd=args.get("cwd") or (sess.get("cwd") if sess else None),
            timeout_sec=int(args.get("timeoutSec", 30)),
            intent=str(args.get("intent") or ""),
            conversation_id=sess["conversation_id"] if sess else args.get("conversation_id"),
        )
        return _text_result(json.dumps(res, indent=2, ensure_ascii=False))

    if name == "ctx_rescue":
        res = guard.build_rescue_brief(conversation_id=args.get("conversation_id"))
        return _text_result(res["rescue_markdown"])

    if name == "ctx_purge":
        res = guard.ctx_purge(
            scope=str(args.get("scope") or "stale"),
            conversation_id=args.get("conversation_id"),
        )
        return _text_result(json.dumps(res, indent=2, ensure_ascii=False))

    if name in ("context_estimator_ui", "app_refresh_estimator"):
        snap = store.get_estimator_snapshot(conversation_id=args.get("conversation_id"))
        est = snap["estimator"]
        kv = snap["kv_cache"]
        summary_text = (
            f"Billion Context 控制台 | 占用/容量: {est['usage_display']} | 模型: {est['sample_model_display']} | "
            f"缓存: {est['cache_hit_percent']} ({kv['warmth']} · {kv['ttl_display']}) | 已省: {snap['guard']['combined_saved_display']}"
        )
        return {
            "content": [{"type": "text", "text": summary_text}],
            "structuredContent": snap,
            "isError": False,
        }

    if name == "app_update_settings":
        updated = guard.update_settings(args.get("settings") or {})
        snap = store.get_estimator_snapshot(conversation_id=args.get("conversation_id"))
        return {
            "content": [{"type": "text", "text": json.dumps({"settings": updated}, ensure_ascii=False)}],
            "structuredContent": snap,
            "isError": False,
        }

    if name == "app_set_keepalive":
        cid = args.get("conversation_id")
        mode = str(args.get("mode") or "off")
        if args.get("max_pings") is not None:
            guard.update_settings({"keepalive_max_pings": int(args["max_pings"])})
        if cid:
            guard.set_session_keepalive_mode(cid, mode)
        else:
            guard.update_settings({"keepalive_mode": mode})
        snap = store.get_estimator_snapshot(conversation_id=cid)
        return {
            "content": [{"type": "text", "text": json.dumps({"keepalive_mode": mode}, ensure_ascii=False)}],
            "structuredContent": snap,
            "isError": False,
        }

    if name == "app_create_checkpoint":
        cp = store.create_checkpoint(
            conversation_id=args.get("conversation_id"),
            reason="plugin_dashboard",
            write_artifact=True,
        )
        return {
            "content": [{"type": "text", "text": json.dumps({"checkpoint_id": cp["checkpoint_id"]}, ensure_ascii=False)}],
            "structuredContent": {"checkpoint_id": cp["checkpoint_id"], "artifact_path": cp.get("artifact_path")},
            "isError": False,
        }

    if name == "app_build_rescue":
        rb = guard.build_rescue_brief(conversation_id=args.get("conversation_id"))
        return {
            "content": [{"type": "text", "text": "Rescue brief generated"}],
            "structuredContent": rb,
            "isError": False,
        }

    if name == "app_search_context":
        q = str(args.get("query") or "")
        hits = store.search_context(
            query=q,
            conversation_id=args.get("conversation_id"),
            scope="all",
            workspace_wide=True,
            limit=10,
        )
        for vh in guard.ctx_vault_search(q, limit=5):
            hits["hits"].append(
                {
                    "source": "vault",
                    "ref": vh["source_id"],
                    "title": f"{vh['label']} · {vh['heading']}",
                    "snippet": vh["snippet"][:360],
                }
            )
        hits["total_hits"] = len(hits["hits"])
        return {
            "content": [{"type": "text", "text": json.dumps({"total_hits": hits["total_hits"]}, ensure_ascii=False)}],
            "structuredContent": hits,
            "isError": False,
        }

    if name == "app_purge_vault":
        res = guard.ctx_purge(scope=str(args.get("scope") or "stale"), conversation_id=args.get("conversation_id"))
        snap = store.get_estimator_snapshot(conversation_id=args.get("conversation_id"))
        return {
            "content": [{"type": "text", "text": json.dumps(res, ensure_ascii=False)}],
            "structuredContent": snap,
            "isError": False,
        }

    if name == "app_audit_prefix":
        sess = store.resolve_session(args.get("conversation_id"))
        ws_dir = sess.get("cwd") if sess else None
        audit = guard.audit_prefix_and_skills(workspace_dir=ws_dir)
        return {
            "content": [{"type": "text", "text": json.dumps(audit, ensure_ascii=False)}],
            "structuredContent": audit,
            "isError": False,
        }

    raise ValueError(f"Unknown tool: {name}")


def _read_ui_html() -> str:
    if UI_FILE.exists():
        return UI_FILE.read_text(encoding="utf-8")
    if LEGACY_UI_FILE.exists():
        return LEGACY_UI_FILE.read_text(encoding="utf-8")
    raise FileNotFoundError(f"UI resource file not found: {UI_FILE}")


def dispatch_request(store: ACPStore, msg: dict[str, Any]) -> dict[str, Any] | None:
    req_id = msg.get("id")
    method = msg.get("method", "")
    params = msg.get("params") or {}

    if method == "initialize":
        client_ver = params.get("protocolVersion")
        ver = client_ver if client_ver in SUPPORTED_PROTOCOL_VERSIONS else SUPPORTED_PROTOCOL_VERSIONS[-1]
        return _success(
            req_id,
            {
                "protocolVersion": ver,
                "capabilities": {
                    "tools": {"listChanged": False},
                    "resources": {"subscribe": False, "listChanged": False},
                },
                "serverInfo": {"name": "billion-context-acp", "version": "3.0.0"},
            },
        )
    if method.startswith("notifications/"):
        return None
    if method == "ping":
        return _success(req_id, {})
    if method == "resources/list":
        return _success(
            req_id,
            {
                "resources": [
                    {
                        "uri": APP_URI,
                        "name": "Billion Context Studio",
                        "description": "Original Billion-Context v3.0 Plugin Dashboard (上下文估算 · 缓存续温 · 崩溃抢救 · 记忆树 · 护栏配置).",
                        "mimeType": UI_MIME_TYPE,
                        "_meta": {"ui": {"prefersBorder": False}},
                    }
                ]
            },
        )
    if method == "resources/read":
        uri = params.get("uri", "")
        if uri not in (APP_URI, "ui://billion-context/context-estimator.html"):
            return _error(req_id, -32602, f"Unknown resource URI: {uri}")
        try:
            html = _read_ui_html()
        except Exception as exc:
            return _error(req_id, -32603, str(exc))
        return _success(
            req_id,
            {
                "contents": [
                    {
                        "uri": uri,
                        "mimeType": UI_MIME_TYPE,
                        "text": html,
                        "_meta": {"ui": {"prefersBorder": False}},
                    }
                ]
            },
        )
    if method == "tools/list":
        return _success(req_id, {"tools": TOOLS_SPEC})
    if method == "tools/call":
        tool_name = params.get("name", "")
        tool_args = dict(params.get("arguments") or {})
        # Extract host-injected conversation ID from _meta if caller didn't pass one
        if not tool_args.get("conversation_id"):
            meta = params.get("_meta")
            if isinstance(meta, dict):
                for key in ("conversationId", "conversation_id", "cascadeId", "sessionId"):
                    val = meta.get(key)
                    if isinstance(val, str) and val.strip():
                        tool_args["conversation_id"] = val.strip()
                        break
                if not tool_args.get("conversation_id"):
                    for mk, mv in meta.items():
                        if isinstance(mv, dict):
                            for key in ("conversationId", "conversation_id", "cascadeId"):
                                val = mv.get(key)
                                if isinstance(val, str) and val.strip():
                                    tool_args["conversation_id"] = val.strip()
                                    break
                            if tool_args.get("conversation_id"):
                                break
        try:
            return _success(req_id, _handle_tool_call(store, tool_name, tool_args))
        except Exception as exc:
            return _success(
                req_id,
                {
                    "content": [{"type": "text", "text": f"ACP tool error ({tool_name}): {exc}"}],
                    "isError": True,
                },
            )
    if req_id is not None:
        return _error(req_id, -32601, f"Method not found: {method}")
    return None


def main() -> None:
    parser = argparse.ArgumentParser(description="Billion-Context v3.0 MCP Stdio Server")
    parser.add_argument("--data-dir", default=None, help="Persistent ACP data directory")
    args, _ = parser.parse_known_args()

    store = ACPStore(data_dir=args.data_dir)
    stdin_stream = sys.stdin.buffer

    while True:
        raw_line = stdin_stream.readline()
        if not raw_line:
            break
        line = raw_line.decode("utf-8", errors="replace").strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError as exc:
            _write_message(_error(None, -32700, f"Parse error: {exc}"))
            continue
        resp = dispatch_request(store, msg)
        if resp is not None:
            _write_message(resp)


if __name__ == "__main__":
    main()
