---
name: acp-context-management
description: >-
  Runbook for Billion-Context Studio v3.0: 3-tier LSM context folding (capture/distill/condense),
  KV-Cache warmth & auto-keepalive, 4-tier read/CLI quota guards, batched search/slices/checks,
  FTS5 vault indexing, and 1-click crashed/stalled session rescue.
---

# Billion-Context Studio v3.0 Runbook

## 1. Fast Batch Discovery & Verification (`batch_search`, `read_slices`, `run_checks`)

- **`batch_search`**: Pass up to 12 `queries` (`type`: `"text"`, `"regex"`, or `"glob"`) in one call instead of sequential search turns.
- **`read_slices`**: Pass `outlines: ["path/a.py", "path/b.ts"]` to get compact symbol maps first, then pass `slices: [{"path": "path/a.py", "ranges": [[40, 110]]}]` for exact lines.
- **`run_checks`**: Run up to 6 short lint/typecheck/unit-test commands concurrently (`<= 8.8 KB` total, automatically shifting unused passing quota to failing stack traces).

## 2. Large Log & Document Vault (`ctx_index`, `ctx_execute`, `ctx_purge`)

- **`ctx_index`**: Chunk long Markdown/log files (`path`) or public docs (`url`, SSRF-guarded) by heading into SQLite FTS5, then query via `search_context(query=..., scope="vault")`.
- **`ctx_execute`**: Run a short `python` or `powershell` filter script over multi-MB JSON/CSVs/logs and return only `<= 8.8 KB` computed results.

## 3. 3-Tier LSM Memory Folding (`acp_status`, `compress`, `decompress`, `pin_context`)

- Check `acp_status` for 512K logical/physical usage, KV-Cache warmth & TTL countdown, and `unfolded_compressible_ranges`.
- Fold completed episodes via `compress(operation="capture", range_ref="s00000..s00025", title=..., summary=...)`, promote T1s via `operation="distill"`, and T2s via `operation="condense"`.
- Pin invariants via `pin_context(action="pin", scope="workspace", ...)` and recall via `search_context` -> `decompress`.

## 4. Session Rescue & Studio Dashboard (`ctx_rescue`, `handoff_checkpoint`, `context_estimator_ui`)

- Call `ctx_rescue` to generate a redacted **Crash/Stall Session Rescue Brief** (modified files, git status, last test status, pins, LSM blocks).
- Call `context_estimator_ui` to open the **Billion Context Studio** control panel (also accessible from the Antigravity right side panel `+` menu and left global sidebar).
