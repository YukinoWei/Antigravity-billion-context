"""Antigravity 5-Stage Lifecycle Hook Runner for Billion-Context v3.0.

Fuses `billion-context` ACP with `Antigravity-agy-dart` Quota & KV-Cache Guards:
  - SessionStart  : Workspace layout digest, continuity ledger, pins, milestones, HUD auto-start.
  - PreToolUse    : 4-tier file read quota guard + compact symbol outline, duplicate-read dedup,
                    sensitive file blocking, transparent CLI noise trimming (`cli_filter.py`),
                    and Watchdog `TOOL_RUNNING` lease.
  - PostToolUse   : Edit invalidation of `file_reads`, `modified_files` & `last_test_status`
                    tracking for crash rescue, heavy tool telemetry, Watchdog refresh.
  - PreInvocation : Zero-prefix-pollution UI-only alerts (`systemMessage=""` + `user_markdown`)
                    for Loop Watch & Cache Cooling, plus hysteresis-gated ACP fold nudges.
  - Stop          : Watchdog `IDLE` transition & background checkpoint snapshot (`decision="allow"`).

Guaranteed Fail-Open & 0-byte stderr.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
if str(PLUGIN_ROOT) not in sys.path:
    sys.path.insert(0, str(PLUGIN_ROOT))

from core.acp_store import ACPStore, default_data_dir, estimate_tokens, normalize_workspace_key  # noqa: E402
from core.guard_engine import analyze_kv_cache_and_loops, is_safe_filterable_command  # noqa: E402


def _make_system_step(text: str) -> dict[str, Any]:
    return {"systemMessage": {"systemMessage": text}}


def _make_ui_only_step(markdown_text: str) -> dict[str, Any]:
    """Zero-prefix-pollution alert: visible to user in UI, 0 tokens sent to LLM!"""
    return {
        "systemMessage": {
            "systemMessage": "",
            "metadata": {"user_markdown": markdown_text},
        }
    }


def _scan_workspace_layout(ws_paths: list[str], cwd: str | None) -> str:
    target = ws_paths[0] if ws_paths else (cwd or "")
    if not target:
        return ""
    root = Path(target)
    if not root.exists() or not root.is_dir():
        return ""
    ignore = {".git", "node_modules", "__pycache__", ".venv", "venv", ".gemini", ".pytest_cache"}
    top_dirs: list[str] = []
    manifests: list[str] = []
    key_manifests = {
        "package.json", "pyproject.toml", "Cargo.toml", "go.mod",
        "pubspec.yaml", "plugin.json", "README.md", "requirements.txt",
    }
    try:
        for entry in sorted(root.iterdir(), key=lambda p: p.name.lower()):
            if entry.name in ignore:
                continue
            if entry.is_dir() and len(top_dirs) < 10:
                top_dirs.append(entry.name + "/")
            elif entry.is_file() and entry.name in key_manifests:
                manifests.append(entry.name)
    except Exception:
        return ""
    parts: list[str] = []
    if top_dirs:
        parts.append("dirs=" + ", ".join(top_dirs))
    if manifests:
        parts.append("manifests=" + ", ".join(manifests))
    return " | ".join(parts)


def _ensure_chatbar_widget_running(store: ACPStore, settings: dict[str, Any]) -> None:
    if not settings.get("auto_launch_widget", True):
        return
    if os.environ.get("BILLION_CONTEXT_NO_WIDGET") == "1":
        return
    try:
        if store.data_dir.resolve() != default_data_dir().resolve():
            return
        widget_script = PLUGIN_ROOT / "scripts" / "chatbar_widget.py"
        if not widget_script.exists():
            return
        py_exe = Path(sys.executable)
        pyw_exe = py_exe.with_name("pythonw.exe")
        runner = str(pyw_exe if pyw_exe.exists() else py_exe)
        creationflags = 0
        if sys.platform == "win32":
            creationflags = subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS
        subprocess.Popen(
            [runner, str(widget_script), "--singleton"],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
            creationflags=creationflags,
        )
    except Exception:
        pass


def handle_session_start(store: ACPStore, payload: dict[str, Any]) -> dict[str, Any]:
    cid = payload.get("conversationId") or ""
    ws_paths = payload.get("workspacePaths") or []
    cwd = payload.get("cwd")
    if not cid:
        return {}

    guard = store.get_guard()
    settings = guard.get_settings()
    _ensure_chatbar_widget_running(store, settings)

    sess = store.register_session(
        conversation_id=cid,
        transcript_path=payload.get("transcriptPath"),
        artifact_dir=payload.get("artifactDirectoryPath"),
        workspace_paths=ws_paths,
        cwd=cwd,
        model_name=payload.get("modelName"),
    )

    ws_key = normalize_workspace_key(ws_paths, cwd)
    guard.update_lease(cid, phase="IDLE", workspace_key=ws_key, reset_keepalive_count=True)

    pins = store.list_pins(conversation_id=cid, workspace_key=ws_key)
    milestones = [
        b for b in store.get_active_blocks(cid, include_workspace_milestones=True)
        if int(b.get("tier", 1)) >= 2
    ]
    latest_cp = store.get_latest_checkpoint(workspace_key=ws_key) if ws_key else None
    ws_ledger = store.get_workspace_ledger(ws_key, cid)
    layout_str = _scan_workspace_layout(ws_paths, cwd)

    lines = [
        f"<acp-session conversation_id=\"{cid}\" parent=\"{sess.get('parent_conversation_id') or 'root'}\">",
        "Billion-Context v3.0 active (ACP Memory + KV-Cache Guard + Fast Batch + Crash Rescue). "
        "Core tools: `acp_status`, `compress`, `decompress`, `search_context`, `batch_search`, `read_slices`, "
        "`run_checks`, `ctx_index`, `ctx_execute`, `ctx_rescue`, `context_estimator_ui`.",
    ]
    if layout_str:
        lines.append(f"Workspace Layout: {layout_str}")
    if ws_ledger["workspace_sessions_count"] > 1 or ws_ledger["workspace_cumulative_tokens"] > 0:
        lines.append(
            f"Workspace Continuity Ledger: {ws_ledger['workspace_sessions_count']} session(s), "
            f"{ws_ledger['workspace_cumulative_tokens']:,} cumulative tokens, "
            f"{ws_ledger['workspace_active_blocks']} active LSM block(s)."
        )
    if pins:
        pin_list = "; ".join(
            f"[{p['pin_id']}:{p['category']}] {p['title']}: {p['content'][:150]}"
            for p in pins[:8]
        )
        lines.append(f"Active Workspace Pins ({len(pins)}): {pin_list}")
    if milestones:
        ms_list = "; ".join(f"[{m['block_id']}|T{m['tier']}] {m['title']}" for m in milestones[:5])
        lines.append(f"Workspace Milestone/Epoch Blocks: {ms_list}.")
    if latest_cp and latest_cp.get("conversation_id") != cid:
        goal_hint = f" (goal: {latest_cp['current_goal'][:100]})" if latest_cp.get("current_goal") else ""
        lines.append(
            f"Prior workspace continuation checkpoint available: `{latest_cp['checkpoint_id']}` "
            f"from `{latest_cp['conversation_id']}`{goal_hint}. "
            "Call `handoff_checkpoint(action='latest')` or `ctx_rescue` if resuming earlier work."
        )
    lines.append("</acp-session>")
    return {"injectSteps": [_make_system_step("\n".join(lines))]}


def handle_pre_tool_use(store: ACPStore, payload: dict[str, Any]) -> dict[str, Any]:
    cid = payload.get("conversationId") or ""
    tc = payload.get("toolCall") or {}
    tname = str(tc.get("name") or "")
    targs = tc.get("args") or {}
    if not isinstance(targs, dict):
        return {"decision": "allow"}

    guard = store.get_guard()
    ws_key = normalize_workspace_key(payload.get("workspacePaths") or [], payload.get("cwd"))
    if cid:
        guard.update_lease(cid, phase="TOOL_RUNNING", detail=tname, workspace_key=ws_key)

    if tname in ("read_file", "view_file") and cid:
        return guard.evaluate_pre_read(cid, targs)

    if tname == "run_command":
        settings = guard.get_settings()
        cmd_line = str(targs.get("CommandLine") or "")
        is_daemon = bool(targs.get("IsDaemon", False))
        if settings.get("cli_noise_filter", True) and not is_daemon and is_safe_filterable_command(cmd_line):
            filter_script = PLUGIN_ROOT / "scripts" / "cli_filter.py"
            if filter_script.exists():
                py = sys.executable
                safe_cmd_arg = json.dumps(cmd_line)
                safe_data_arg = json.dumps(str(store.data_dir))
                rewritten = (
                    f"\"{py}\" \"{filter_script}\" --cid \"{cid}\" "
                    f"--data-dir {safe_data_arg} --cmd {safe_cmd_arg}"
                )
                return {
                    "decision": "allow",
                    "overwrite": {"CommandLine": rewritten},
                }

    return {"decision": "allow"}


def handle_post_tool_use(store: ACPStore, payload: dict[str, Any]) -> dict[str, Any]:
    cid = payload.get("conversationId") or ""
    if not cid:
        return {}

    store.register_session(
        conversation_id=cid,
        transcript_path=payload.get("transcriptPath"),
        artifact_dir=payload.get("artifactDirectoryPath"),
        workspace_paths=payload.get("workspacePaths") or [],
        cwd=payload.get("cwd"),
        model_name=payload.get("modelName"),
    )
    guard = store.get_guard()
    tc = payload.get("toolCall") or {}
    tool_name = str(tc.get("name") or "unknown")
    targs = tc.get("args") or {}
    err_str = str(payload.get("error") or "")

    mod_file: str | None = None
    test_status: str | None = None
    if isinstance(targs, dict) and tool_name in (
        "edit_file", "write_file", "replace_file_content", "multi_replace_file_content", "write_to_file"
    ):
        mod_file = str(targs.get("Path") or targs.get("TargetFile") or "") or None
        if mod_file:
            guard.invalidate_file_read(cid, mod_file)

    if tool_name == "run_command" and isinstance(targs, dict):
        cmd_s = str(targs.get("CommandLine") or "")
        if any(k in cmd_s for k in ("pytest", "unittest", "npm test", "cargo test", "go test")):
            test_status = f"FAIL ({err_str[:60]})" if err_str else "PASS"

    guard.update_lease(
        cid,
        phase="LLM_INFLIGHT",
        detail=f"done:{tool_name}",
        modified_file=mod_file,
        last_test_status=test_status,
    )

    step_idx = payload.get("stepIdx")
    args_json = json.dumps(targs if isinstance(targs, dict) else {}, ensure_ascii=False)
    approx = estimate_tokens(args_json)
    if step_idx is not None:
        steps = store.read_transcript_steps(
            payload.get("transcriptPath"),
            start_step=int(step_idx),
            end_step=int(step_idx),
            prefer_full=False,
        )
        if steps:
            approx = max(approx, estimate_tokens(json.dumps(steps[0], ensure_ascii=False)))
    if approx >= 180:
        store.record_tool_telemetry(
            conversation_id=cid,
            step_index=int(step_idx) if step_idx is not None else None,
            tool_name=tool_name,
            approx_tokens=approx,
            summary=args_json[:200],
        )
    return {}


def handle_pre_invocation(store: ACPStore, payload: dict[str, Any]) -> dict[str, Any]:
    cid = payload.get("conversationId") or ""
    if not cid:
        return {}

    ws_paths = payload.get("workspacePaths") or []
    cwd = payload.get("cwd")
    store.register_session(
        conversation_id=cid,
        transcript_path=payload.get("transcriptPath"),
        artifact_dir=payload.get("artifactDirectoryPath"),
        workspace_paths=ws_paths,
        cwd=cwd,
        model_name=payload.get("modelName"),
    )
    guard = store.get_guard()
    settings = guard.get_settings()
    has_new_user_input = bool(payload.get("lastUserInput"))
    guard.update_lease(
        cid,
        phase="LLM_INFLIGHT",
        detail="thinking",
        workspace_key=normalize_workspace_key(ws_paths, cwd),
        reset_keepalive_count=has_new_user_input,
    )

    is_manual_compact = "/compact" in str(payload.get("lastUserInput") or "")
    if is_manual_compact:
        guard.ctx_purge(scope="session", conversation_id=cid)

    status = store.get_status(conversation_id=cid, detail="compact")
    tel = status.get("telemetry", {})
    lsm = status.get("lsm_memory", {})
    level = tel.get("pressure_level", "OK")
    unfolded_tokens = int(lsm.get("unfolded_compressible_tokens") or 0)
    phys_compact = bool(tel.get("physical_compact_needed", False))

    injected: list[dict[str, Any]] = []

    # Post-compaction automatic LSM Memory & Pins rehydration (preserves lossless continuity across /compact)
    rehydration_xml = store.check_and_record_compaction_rehydration(
        cid,
        int(tel.get("physical_prompt_tokens") or 0),
        force_compact=is_manual_compact,
    )
    if rehydration_xml:
        guard.ctx_purge(scope="session", conversation_id=cid)
        injected.append(_make_system_step(rehydration_xml))

    # Check Loop Watch via UI-only zero-prefix-pollution alert
    if settings.get("zero_prefix_alerts", True) and int(payload.get("invocationNum") or 1) == 1:
        raw_steps = store.read_transcript_steps(payload.get("transcriptPath"), prefer_full=False)
        kv = analyze_kv_cache_and_loops(raw_steps, payload.get("modelName"))
        lw = kv.get("loop_watch", {})
        if lw.get("oscillation_detected"):
            files_str = ", ".join(Path(f).name for f in lw.get("repeated_edit_files", []))
            injected.append(
                _make_ui_only_step(
                    f"> ⚠️ **Billion-Context 振荡检测**：检测到连续命令失败并反复修改 `{files_str}`（此提示仅用户可见，零上下文污染）。"
                )
            )

    should_nudge, urgent_count = store.check_and_update_nudge(
        cid,
        level,
        unfolded_tokens=unfolded_tokens,
        physical_compact_needed=phys_compact,
    )
    if not should_nudge:
        return {"injectSteps": injected} if injected else {}

    unfolded = status.get("unfolded_compressible_ranges", [])
    range_hint = ""
    if unfolded:
        r0 = unfolded[0]
        preview = f" — \"{r0['episode_preview'][:55]}\"" if r0.get("episode_preview") else ""
        range_hint = (
            f" Next episode candidate: `{r0['range_ref']}` "
            f"(steps {r0['start_step']}..{r0['end_step']}, ~{r0['estimated_tokens']} tokens{preview})."
        )
    tier_hints = [h for h in (status.get("hints") or []) if h.startswith(("[distill -> T2]", "[condense -> T3]"))]
    tier_note = (" " + " ".join(tier_hints)) if tier_hints else ""

    phys_note = ""
    if phys_compact:
        phys_note = (
            f" Physical trajectory window is at {tel.get('physical_pressure_percent')} "
            f"({tel.get('physical_prompt_tokens')}/{tel.get('physical_window_tokens')}); "
            "prepare `handoff_checkpoint(action='create')` and advise `/compact` or session rotation."
        )

    # For SOFT tier when zero_prefix_alerts is enabled, show a silent UI badge without mutating LLM prompt!
    if level == "SOFT" and settings.get("zero_prefix_alerts", True) and not phys_compact:
        win_lbl = tel.get("window_label", "512K")
        injected.append(
            _make_ui_only_step(
                f"> 💡 **Billion-Context 水位提示**：当前上下文 `{tel.get('pressure_percent')}`（`{tel.get('logical_working_tokens'):,}` / `{win_lbl}`），可在下个自然边界折叠历史步骤（此提示零前缀消耗）。"
            )
        )
        return {"injectSteps": injected}

    if not settings.get("model_compress_nudge", True):
        return {"injectSteps": injected} if injected else {}

    if level == "SOFT":
        msg = (
            f"[ACP Telemetry SOFT | Logical {tel.get('pressure_percent')} of {tel.get('effective_budget_tokens')} budget "
            f"({tel.get('logical_working_tokens')} active tokens)]{range_hint}{phys_note} "
            "At the next natural task boundary, fold completed episodes with `compress(operation='capture', ...)` "
            "and pin key invariants with `pin_context`."
        )
    elif level == "RECOMMEND":
        msg = (
            f"[ACP Pressure RECOMMEND | Logical {tel.get('pressure_percent')} ({tel.get('logical_working_tokens')} tokens)]{range_hint}{tier_note}{phys_note} "
            "Please fold completed episode ranges via `compress` and pin critical invariants via `pin_context`."
        )
    elif level == "URGENT" and unfolded_tokens > 0:
        msg = (
            f"[ACP Pressure URGENT #{urgent_count} | Logical {tel.get('pressure_percent')} ({tel.get('logical_working_tokens')} tokens)]{range_hint}{tier_note}{phys_note} "
            "Unfolded working context exceeds budget. Call `compress` on completed episodes now "
            "(and `handoff_checkpoint(action='create')` before `/compact` if reclaiming physical window)."
        )
    else:
        msg = f"[ACP Physical Window Notice]{phys_note}"

    injected.append(_make_system_step(msg.strip()))
    return {"injectSteps": injected}


def handle_stop(store: ACPStore, payload: dict[str, Any]) -> dict[str, Any]:
    cid = payload.get("conversationId") or ""
    if not cid:
        return {"decision": "allow"}
    store.register_session(
        conversation_id=cid,
        transcript_path=payload.get("transcriptPath"),
        artifact_dir=payload.get("artifactDirectoryPath"),
        workspace_paths=payload.get("workspacePaths") or [],
        cwd=payload.get("cwd"),
        model_name=payload.get("modelName"),
    )
    guard = store.get_guard()
    term_reason = str(payload.get("terminationReason") or "NO_TOOL_CALL")
    guard.update_lease(cid, phase="IDLE", detail=f"stopped:{term_reason}")

    status = store.get_status(conversation_id=cid, detail="compact")
    tel = status.get("telemetry", {})
    level = tel.get("pressure_level", "OK")
    phys_compact = bool(tel.get("physical_compact_needed", False))
    if (level in ("RECOMMEND", "URGENT") or phys_compact) and not payload.get("continuationActive"):
        try:
            store.create_checkpoint(
                conversation_id=cid,
                reason=f"auto_stop_{level.lower()}",
                write_artifact=True,
            )
        except Exception:
            pass
    return {"decision": "allow"}


def process_hook(payload: dict[str, Any], data_dir: str | Path | None = None) -> dict[str, Any]:
    store = ACPStore(data_dir=data_dir)
    event = payload.get("hookEventName", "")
    if event == "SessionStart":
        return handle_session_start(store, payload)
    if event == "PreToolUse":
        return handle_pre_tool_use(store, payload)
    if event == "PostToolUse":
        return handle_post_tool_use(store, payload)
    if event == "PreInvocation":
        return handle_pre_invocation(store, payload)
    if event == "Stop":
        return handle_stop(store, payload)
    return {}


def main() -> None:
    raw = sys.stdin.buffer.read().decode("utf-8", errors="replace").strip()
    if not raw:
        sys.stdout.write("{}")
        return
    try:
        payload = json.loads(raw)
        out = process_hook(payload)
    except Exception:
        # Strict 0-byte stderr & Fail-Open invariant
        event = ""
        try:
            event = json.loads(raw).get("hookEventName", "")
        except Exception:
            pass
        out = {"decision": "allow"} if event in ("PreToolUse", "Stop") else {}
    sys.stdout.buffer.write((json.dumps(out, ensure_ascii=False) + "\n").encode("utf-8"))
    sys.stdout.buffer.flush()


if __name__ == "__main__":
    main()
