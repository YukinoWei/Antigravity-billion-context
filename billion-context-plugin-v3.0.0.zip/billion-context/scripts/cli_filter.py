"""Transparent CLI Noise Filter & Vault Archiver (`PreToolUse.overwrite` target).

Executes a single safe foreground command, preserves its exact exit code, redacts secrets,
archives the full output into the local SQLite FTS5 vault if large, and prints only a
compact <=8.8KB error-anchor-preserving summary to stdout.
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
if str(PLUGIN_ROOT) not in sys.path:
    sys.path.insert(0, str(PLUGIN_ROOT))

from core.acp_store import ACPStore  # noqa: E402
from core.guard_engine import GuardEngine, compress_cli_output  # noqa: E402


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8")
        except Exception:
            pass

    parser = argparse.ArgumentParser(description="Billion-Context CLI Noise Filter")
    parser.add_argument("--cid", default="", help="Conversation ID")
    parser.add_argument("--data-dir", default=None, help="ACP plugin_data directory")
    parser.add_argument("--cmd", required=True, help="Original command string")
    args = parser.parse_args()

    proc = subprocess.run(
        args.cmd,
        shell=True,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )
    raw = (proc.stdout or "") + ("\n" + proc.stderr if proc.stderr else "")
    trimmed, saved = compress_cli_output(raw, exit_code=proc.returncode)

    if saved > 0:
        try:
            store = ACPStore(data_dir=args.data_dir)
            guard = GuardEngine(store)
            idx_res = guard.ctx_index(
                text=raw,
                label=f"cmd:{args.cmd[:50]}",
                conversation_id=args.cid,
            )
            guard.record_saving(args.cid or "global", "cli_noise_filter", saved, args.cmd[:120])
            trimmed += f"\n[Full log archived in FTS5 vault `{idx_res['source_id']}` — saved {saved:,}B]"
        except Exception:
            pass

    sys.stdout.write(trimmed + ("\n" if trimmed and not trimmed.endswith("\n") else ""))
    sys.stdout.flush()
    return proc.returncode


if __name__ == "__main__":
    raise SystemExit(main())
