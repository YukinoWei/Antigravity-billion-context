"""DWM-Composited, SDF Anti-Aliased Chat-Bar Button & Floating HUD for Billion-Context v3.0.

Eliminates traditional rough Tkinter rendering via:
  1. Win32 DWM Hardware Compositing (`DwmSetWindowAttribute` `DWMWCP_ROUND` / `DWMWCP_ROUNDSMALL`
     + custom `DWMWA_BORDER_COLOR` + native OS drop shadow — zero 1-bit jagged edges).
  2. Analytical Signed-Distance-Field (SDF) Subpixel Anti-Aliased `PhotoImage` rendering
     (pure Python math -> in-memory P6 PPM) for silky-smooth circular progress gauges,
     glowing KV-cache warmth dots, and crisp rounded progress bars.
  3. Built-in background KV-Cache Auto-Keepalive & Stall Watchdog daemon loop.
"""

from __future__ import annotations

import argparse
import ctypes
import json
import math
import os
import sys
import tkinter as tk
from pathlib import Path
from typing import Any

PLUGIN_DIR = Path(__file__).resolve().parent.parent
if str(PLUGIN_DIR) not in sys.path:
    sys.path.insert(0, str(PLUGIN_DIR))

os.environ.setdefault(
    "ANTIGRAVITY_APP_DATA_DIR",
    str(Path.home() / ".gemini" / "antigravity"),
)

from core.acp_store import ACPStore, default_data_dir  # noqa: E402

DEFAULT_PLUGIN_DATA = default_data_dir()
STATE_FILE = DEFAULT_PLUGIN_DATA / "widget_state.json"
PID_FILE = DEFAULT_PLUGIN_DATA / "chatbar_widget.pid"

# Refined Obsidian HUD Palette
BG_WINDOW_KEY = "#14161d"
BG_CARD = "#14161d"
BG_ELEVATED = "#1c1f29"
BG_CHIP = "#222633"
BG_CHIP_HOVER = "#2d3244"
BG_CHIP_ACTIVE = "#1e3a5f"
DIVIDER_HEX = "#212532"

TEXT_PRIMARY = "#f3f5f9"
TEXT_SECONDARY = "#9aa2b4"
TEXT_MUTED = "#727a8c"

LEVEL_HEX = {
    "OK": "#10b981",
    "SOFT": "#38bdf8",
    "RECOMMEND": "#f59e0b",
    "URGENT": "#f43f5e",
}

WARMTH_RGB = {
    "HOT": (16, 185, 129),
    "WARM": (56, 189, 248),
    "COOLING": (245, 158, 11),
    "COLD": (108, 115, 133),
}

LEVEL_RGB = {
    "OK": (16, 185, 129),
    "SOFT": (56, 189, 248),
    "RECOMMEND": (245, 158, 11),
    "URGENT": (244, 63, 94),
}

NOTE_LINE_1 = "速度来自请求完成后的元数据，不是瞬时速度。"
NOTE_LINE_2_IDLE = "当前统计不可用，将自动重试；不影响其他增强功能。"
NOTE_LINE_3 = "占用可能在压缩后下降；百分比不代表模型能记住多少内容。"

KEEPALIVE_CYCLE = ["off", "auto", "4m", "9m", "15m"]
KEEPALIVE_LABELS = {
    "off": "续温: 关",
    "auto": "续温: 自适应",
    "4m": "续温: 4m",
    "9m": "续温: 9m",
    "15m": "续温: 15m",
}


def enable_windows_dpi_awareness() -> None:
    if sys.platform != "win32":
        return
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def apply_dwm_window_styling(widget: tk.Wm, small_corners: bool = False, border_rgb: tuple[int, int, int] = (46, 51, 68)) -> bool:
    """Apply Windows 11 / Server 2022+ hardware-composited rounded corners, border color, & native shadow."""
    if sys.platform != "win32":
        return False
    try:
        widget.update_idletasks()
        hwnd = widget.winfo_id()
        parent = ctypes.windll.user32.GetParent(hwnd)
        target_hwnd = parent if parent else hwnd

        dwmapi = ctypes.windll.dwmapi
        # DWMWA_WINDOW_CORNER_PREFERENCE = 33; DWMWCP_ROUND = 2, DWMWCP_ROUNDSMALL = 3
        corner_pref = ctypes.c_int(3 if small_corners else 2)
        res = dwmapi.DwmSetWindowAttribute(
            target_hwnd, 33, ctypes.byref(corner_pref), ctypes.sizeof(corner_pref)
        )
        # DWMWA_BORDER_COLOR = 34 (COLORREF = 0x00BBGGRR)
        r, g, b = border_rgb
        colorref = ctypes.c_uint32((b << 16) | (g << 8) | r)
        dwmapi.DwmSetWindowAttribute(
            target_hwnd, 34, ctypes.byref(colorref), ctypes.sizeof(colorref)
        )
        # DWMWA_USE_IMMERSIVE_DARK_MODE = 20
        dark = ctypes.c_int(1)
        dwmapi.DwmSetWindowAttribute(
            target_hwnd, 20, ctypes.byref(dark), ctypes.sizeof(dark)
        )
        return res == 0
    except Exception:
        return False


# ------------------------------------------------------------------
# Analytical SDF Subpixel Anti-Aliased Rasterizer (Pure Stdlib P6 PPM)
# ------------------------------------------------------------------

def _clamp01(v: float) -> float:
    return 0.0 if v <= 0.0 else (1.0 if v >= 1.0 else v)


def _lerp_rgb(c1: tuple[int, int, int], c2: tuple[int, int, int], t: float) -> tuple[int, int, int]:
    a = _clamp01(t)
    return (
        int(c1[0] + (c2[0] - c1[0]) * a + 0.5),
        int(c1[1] + (c2[1] - c1[1]) * a + 0.5),
        int(c1[2] + (c2[2] - c1[2]) * a + 0.5),
    )


def _sd_rounded_box(px: float, py: float, cx: float, cy: float, hx: float, hy: float, r: float) -> float:
    qx = abs(px - cx) - hx + r
    qy = abs(py - cy) - hy + r
    out_d = math.hypot(max(qx, 0.0), max(qy, 0.0))
    in_d = min(max(qx, qy), 0.0)
    return out_d + in_d - r


def render_aa_button_ppm(
    size: int,
    pct: float,
    has_usage: bool,
    arc_rgb: tuple[int, int, int],
    warmth_rgb: tuple[int, int, int],
    hovered: bool,
    active: bool,
) -> bytes:
    """Render a subpixel-anti-aliased 32x32 HUD button with smooth ring, progress arc, & warmth dot."""
    w = h = size
    cx = cy = (size - 1) / 2.0
    bg_outer = (20, 22, 29)
    tile_top = (44, 48, 62) if (hovered or active) else (33, 36, 46)
    tile_bot = (34, 37, 49) if (hovered or active) else (25, 27, 36)
    border_col = (74, 82, 106) if (hovered or active) else (54, 59, 76)
    track_col = (78, 84, 102)
    dash_col = arc_rgb if (has_usage and pct >= 75.0) else (196, 203, 218)

    ring_r = 9.0
    ring_half_w = 1.05
    sweep_deg = max(16.0, min(359.9, (pct / 100.0) * 360.0)) if (has_usage and pct > 0) else 0.0

    # Warmth dot at bottom-right of button (cx + 9.2, cy + 9.2)
    dot_x, dot_y = cx + 8.8, cy + 8.8

    buf = bytearray(w * h * 3)
    idx = 0
    for y in range(h):
        grad_t = y / max(1, h - 1)
        tile_fill = _lerp_rgb(tile_top, tile_bot, grad_t)
        for x in range(w):
            # Rounded-square tile SDF
            d_box = _sd_rounded_box(x, y, cx, cy, cx - 0.8, cy - 0.8, 7.5)
            cov_box = _clamp01(0.5 - d_box)
            col = _lerp_rgb(bg_outer, tile_fill, cov_box)

            # 1px crisp anti-aliased inner border
            d_border = abs(d_box + 0.5) - 0.45
            cov_border = _clamp01(0.5 - d_border) * cov_box
            if cov_border > 0.0:
                col = _lerp_rgb(col, border_col, cov_border * 0.85)

            # Smooth circular ring track
            dx = x - cx
            dy = y - cy
            dist_c = math.hypot(dx, dy)
            d_ring = abs(dist_c - ring_r) - ring_half_w
            cov_ring = _clamp01(0.65 - d_ring)
            if cov_ring > 0.0:
                col = _lerp_rgb(col, track_col, cov_ring * 0.92)
                if sweep_deg > 0.0:
                    # Clockwise angle starting from top (12 o'clock = 0 deg)
                    ang = (math.degrees(math.atan2(dx, -dy)) + 360.0) % 360.0
                    # Soft angular AA at arc head
                    ang_cov = _clamp01((sweep_deg - ang) * 0.35 + 0.5) if sweep_deg < 358.0 else 1.0
                    if ang_cov > 0.0:
                        col = _lerp_rgb(col, arc_rgb, cov_ring * ang_cov)

            # Center horizontal capsule dash `—`
            d_dash = _sd_rounded_box(x, y, cx, cy, 3.4, 0.85, 0.85)
            cov_dash = _clamp01(0.6 - d_dash)
            if cov_dash > 0.0:
                col = _lerp_rgb(col, dash_col, cov_dash)

            # KV-Cache warmth status micro-dot (with dark halo for crisp contrast)
            dist_dot = math.hypot(x - dot_x, y - dot_y)
            cov_halo = _clamp01(3.3 - dist_dot)
            if cov_halo > 0.0:
                col = _lerp_rgb(col, tile_bot, cov_halo * 0.9)
            cov_dot = _clamp01(2.25 - dist_dot)
            if cov_dot > 0.0:
                col = _lerp_rgb(col, warmth_rgb, cov_dot)

            buf[idx] = col[0]
            buf[idx + 1] = col[1]
            buf[idx + 2] = col[2]
            idx += 3

    header = f"P6\n{w} {h}\n255\n".encode("ascii")
    return header + bytes(buf)


def render_aa_progress_bar_ppm(width: int, height: int, pct: float, fill_rgb: tuple[int, int, int]) -> bytes:
    """Render a silky-smooth anti-aliased rounded pill progress bar as P6 PPM."""
    w = max(40, width)
    h = max(4, height)
    bg = (20, 22, 29)
    track = (34, 38, 51)
    cx = (w - 1) / 2.0
    cy = (h - 1) / 2.0
    rad = h / 2.0
    fill_w = max(0.0, min(float(w), (pct / 100.0) * w))

    buf = bytearray(w * h * 3)
    idx = 0
    for y in range(h):
        for x in range(w):
            d_track = _sd_rounded_box(x, y, cx, cy, cx, cy, rad)
            cov_track = _clamp01(0.5 - d_track)
            col = _lerp_rgb(bg, track, cov_track)
            if fill_w >= 1.5 and cov_track > 0.0:
                fcx = (fill_w - 1) / 2.0
                fhx = max(rad, fill_w / 2.0)
                d_fill = _sd_rounded_box(x, y, fcx, cy, fhx, cy, rad)
                cov_fill = _clamp01(0.5 - d_fill) * cov_track
                if cov_fill > 0.0:
                    # Subtle top-to-bottom sheen on active bar
                    sheen = _lerp_rgb(
                        (min(255, fill_rgb[0] + 22), min(255, fill_rgb[1] + 22), min(255, fill_rgb[2] + 22)),
                        fill_rgb,
                        y / max(1, h - 1),
                    )
                    col = _lerp_rgb(col, sheen, cov_fill)
            buf[idx] = col[0]
            buf[idx + 1] = col[1]
            buf[idx + 2] = col[2]
            idx += 3

    return f"P6\n{w} {h}\n255\n".encode("ascii") + bytes(buf)


# ------------------------------------------------------------------
# Win32 Host Window Locator & Docking Math
# ------------------------------------------------------------------

def find_antigravity_window_rect() -> tuple[int, tuple[int, int, int, int], bool] | None:
    if sys.platform != "win32":
        return None
    try:
        from ctypes import wintypes

        u32 = ctypes.windll.user32
        fg_hwnd = u32.GetForegroundWindow()
        candidates: list[tuple[int, int, tuple[int, int, int, int]]] = []
        WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)

        def _cb(hwnd: int, _lparam: int) -> bool:
            if not u32.IsWindowVisible(hwnd) or u32.IsIconic(hwnd):
                return True
            length = u32.GetWindowTextLengthW(hwnd)
            if length <= 0:
                return True
            buf = ctypes.create_unicode_buffer(length + 1)
            u32.GetWindowTextW(hwnd, buf, length + 1)
            title = buf.value
            if title.startswith("Billion Context"):
                return True
            if "antigravity" not in title.lower():
                return True
            rect = wintypes.RECT()
            if not u32.GetWindowRect(hwnd, ctypes.byref(rect)):
                return True
            if (rect.right - rect.left) < 420 or (rect.bottom - rect.top) < 360:
                return True
            prio = 0 if hwnd == fg_hwnd else 1
            candidates.append((prio, hwnd, (rect.left, rect.top, rect.right, rect.bottom)))
            return True

        u32.EnumWindows(WNDENUMPROC(_cb), 0)
        if not candidates:
            return None
        candidates.sort(key=lambda item: item[0])
        _, best_hwnd, best_rect = candidates[0]

        fg_title = ""
        if fg_hwnd:
            flen = u32.GetWindowTextLengthW(fg_hwnd)
            if flen > 0:
                fbuf = ctypes.create_unicode_buffer(flen + 1)
                u32.GetWindowTextW(fg_hwnd, fbuf, flen + 1)
                fg_title = fbuf.value
        is_fg = (
            fg_hwnd == best_hwnd
            or "antigravity" in fg_title.lower()
            or fg_title.startswith("Billion Context")
        )
        return best_hwnd, best_rect, is_fg
    except Exception:
        return None


def compute_docked_position(
    host_rect: tuple[int, int, int, int],
    btn_size: int,
    rel_from_right: int,
    rel_from_bottom: int,
    screen_w: int,
    screen_h: int,
) -> tuple[int, int]:
    left, top, right, bottom = host_rect
    x = right - rel_from_right - btn_size
    y = bottom - rel_from_bottom - btn_size
    x = max(left + 12, min(right - btn_size - 12, x))
    y = max(top + 40, min(bottom - btn_size - 8, y))
    x = max(0, min(screen_w - btn_size, x))
    y = max(0, min(screen_h - btn_size, y))
    return x, y


def fetch_snapshot(store: ACPStore, conversation_id: str | None = None) -> dict[str, Any]:
    sess = store.resolve_session(conversation_id)
    is_live_default = store.data_dir.resolve() == DEFAULT_PLUGIN_DATA.resolve()
    app_data = Path(os.environ.get("ANTIGRAVITY_APP_DATA_DIR", ""))
    brain_dir = app_data / "brain" if app_data else None
    if not conversation_id and (is_live_default or sess is None) and brain_dir and brain_dir.exists():
        newest: tuple[float, str, Path] | None = None
        for sub in brain_dir.iterdir():
            if not sub.is_dir():
                continue
            tpath = sub / ".system_generated" / "logs" / "transcript.jsonl"
            if tpath.exists():
                mtime = tpath.stat().st_mtime
                if newest is None or mtime > newest[0]:
                    newest = (mtime, sub.name, tpath)
        if newest is not None:
            _, cid, tpath = newest
            if sess is None or sess.get("conversation_id") != cid:
                store.register_session(
                    conversation_id=cid,
                    transcript_path=str(tpath),
                    artifact_dir=str(brain_dir / cid),
                )
                conversation_id = cid
    return store.get_estimator_snapshot(conversation_id=conversation_id)


# ------------------------------------------------------------------
# Modernized HUD Application
# ------------------------------------------------------------------

class ContextEstimatorApp:
    """DWM-rounded, SDF anti-aliased 32x32 chat-bar button & upward floating HUD."""

    BTN_SIZE = 32
    ORB_SIZE = 32
    POLL_MS = 2200
    DOCK_MS = 140
    KEEPALIVE_TICK_MS = 12000

    DEFAULT_REL_RIGHT = 215
    DEFAULT_REL_BOTTOM = 26

    def __init__(
        self,
        data_dir: str | Path | None = None,
        poll_ms: int = POLL_MS,
        auto_dock: bool = True,
    ) -> None:
        self.data_dir = Path(data_dir) if data_dir else DEFAULT_PLUGIN_DATA
        self.store = ACPStore(data_dir=self.data_dir)
        self.poll_ms = poll_ms
        self.auto_dock = auto_dock
        self.snapshot: dict[str, Any] = fetch_snapshot(self.store)
        self._ttl_local_sec: int = int((self.snapshot.get("kv_cache") or {}).get("ttl_remaining_sec") or 0)

        self.root = tk.Tk()
        self.root.title("Billion Context ChatBarBtn")
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        self.root.configure(bg=BG_WINDOW_KEY)

        state = self._load_state()
        self.rel_right: int = state["rel_right"]
        self.rel_bottom: int = state["rel_bottom"]
        self.orb_x: int = state["x"]
        self.orb_y: int = state["y"]
        self._last_host_rect: tuple[int, int, int, int] | None = None
        self._hidden_by_focus = False
        self._hovered = False

        self.root.geometry(f"{self.BTN_SIZE}x{self.BTN_SIZE}+{self.orb_x}+{self.orb_y}")
        apply_dwm_window_styling(self.root, small_corners=True, border_rgb=(54, 59, 76))

        self._drag_origin: tuple[int, int] | None = None
        self._win_origin: tuple[int, int] | None = None
        self._did_drag = False
        self._btn_photo: tk.PhotoImage | None = None
        self._bar_photo: tk.PhotoImage | None = None

        self.popover: tk.Toplevel | None = None
        self.popover_open = False
        self.val_labels: dict[str, tk.Label] = {}

        self._build_button()
        self._build_context_menu()
        self._render_orb()
        if self.auto_dock:
            self._sync_dock_to_host()
            self._schedule_dock_tick()
        self._schedule_poll()
        self._schedule_second_ticker()
        self._schedule_keepalive_daemon()

    # ------------------------------------------------------------------
    # State Persistence
    # ------------------------------------------------------------------

    def _state_file_path(self) -> Path:
        return self.data_dir / "widget_state.json"

    def _load_state(self) -> dict[str, int]:
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        default_x = max(20, int(sw * 0.52))
        default_y = max(20, sh - 88)
        out = {
            "x": default_x,
            "y": default_y,
            "rel_right": self.DEFAULT_REL_RIGHT,
            "rel_bottom": self.DEFAULT_REL_BOTTOM,
        }
        try:
            sf = self._state_file_path()
            if sf.exists():
                data = json.loads(sf.read_text(encoding="utf-8"))
                out["x"] = max(0, min(sw - self.BTN_SIZE, int(data.get("x", default_x))))
                out["y"] = max(0, min(sh - self.BTN_SIZE, int(data.get("y", default_y))))
                out["rel_right"] = int(data.get("rel_right", self.DEFAULT_REL_RIGHT))
                out["rel_bottom"] = int(data.get("rel_bottom", self.DEFAULT_REL_BOTTOM))
        except Exception:
            pass
        return out

    def _save_state(self) -> None:
        try:
            sf = self._state_file_path()
            sf.parent.mkdir(parents=True, exist_ok=True)
            sf.write_text(
                json.dumps(
                    {
                        "x": self.orb_x,
                        "y": self.orb_y,
                        "rel_right": self.rel_right,
                        "rel_bottom": self.rel_bottom,
                    },
                    indent=2,
                ),
                encoding="utf-8",
            )
        except Exception:
            pass

    # ------------------------------------------------------------------
    # SDF Anti-Aliased Button
    # ------------------------------------------------------------------

    def _build_button(self) -> None:
        self.canvas = tk.Canvas(
            self.root,
            width=self.BTN_SIZE,
            height=self.BTN_SIZE,
            bg=BG_WINDOW_KEY,
            highlightthickness=0,
            bd=0,
            cursor="hand2",
        )
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<ButtonPress-1>", self._on_press)
        self.canvas.bind("<B1-Motion>", self._on_drag)
        self.canvas.bind("<ButtonRelease-1>", self._on_release)
        self.canvas.bind("<Button-3>", self._on_right_click)
        self.canvas.bind("<Enter>", self._on_enter)
        self.canvas.bind("<Leave>", self._on_leave)

    def _on_enter(self, _e: tk.Event) -> None:
        self._hovered = True
        self._render_orb()

    def _on_leave(self, _e: tk.Event) -> None:
        self._hovered = False
        self._render_orb()

    def _build_context_menu(self) -> None:
        self.menu = tk.Menu(
            self.root,
            tearoff=0,
            bg=BG_ELEVATED,
            fg=TEXT_PRIMARY,
            activebackground=BG_CHIP_HOVER,
            activeforeground=TEXT_PRIMARY,
            bd=0,
        )
        self.menu.add_command(label="上下文估算 HUD (显示/收起)", command=self.toggle_popover)
        self.menu.add_command(label="立即刷新实时状态", command=self.refresh_now)
        self.menu.add_command(label="切换自动缓存续温档位", command=self.cycle_keepalive_mode)
        self.menu.add_command(label="复制崩溃/卡死抢救简报", command=self.copy_rescue_brief_now)
        self.menu.add_command(label="生成 ACP 无损续接点", command=self.create_checkpoint_now)
        self.menu.add_separator()
        self.menu.add_command(label="重置到对话栏默认位置", command=self._reset_position)
        self.menu.add_command(label="退出对话栏按钮", command=self.quit)

    def _render_orb(self) -> None:
        est = self.snapshot.get("estimator", {})
        kv = self.snapshot.get("kv_cache", {})
        level = str(est.get("pressure_level") or "OK").upper()
        pct = min(100.0, max(0.0, float(est.get("pressure_percent_num") or 0.0)))
        has_usage = est.get("usage_display") not in (None, "", "暂不可用")
        warmth = str(kv.get("warmth") or "COLD").upper()
        if self._ttl_local_sec <= 0:
            warmth = "COLD"
        elif self._ttl_local_sec <= 75:
            warmth = "COOLING"

        ppm = render_aa_button_ppm(
            size=self.BTN_SIZE,
            pct=pct,
            has_usage=has_usage,
            arc_rgb=LEVEL_RGB.get(level, LEVEL_RGB["OK"]),
            warmth_rgb=WARMTH_RGB.get(warmth, WARMTH_RGB["COLD"]),
            hovered=self._hovered,
            active=self.popover_open,
        )
        self._btn_photo = tk.PhotoImage(data=ppm)
        self.canvas.delete("all")
        self.canvas.create_image(0, 0, image=self._btn_photo, anchor="nw")

    # ------------------------------------------------------------------
    # Docking & Dragging
    # ------------------------------------------------------------------

    def _sync_dock_to_host(self) -> None:
        if self._drag_origin is not None:
            return
        found = find_antigravity_window_rect()
        if found is None:
            return
        _hwnd, rect, is_fg = found
        self._last_host_rect = rect

        if not is_fg and not self.popover_open:
            if not self._hidden_by_focus:
                self.root.withdraw()
                self._hidden_by_focus = True
            return

        if self._hidden_by_focus:
            self.root.deiconify()
            self.root.attributes("-topmost", True)
            self._hidden_by_focus = False

        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        nx, ny = compute_docked_position(
            rect, self.BTN_SIZE, self.rel_right, self.rel_bottom, sw, sh
        )
        if nx != self.orb_x or ny != self.orb_y:
            self.orb_x, self.orb_y = nx, ny
            self.root.geometry(f"{self.BTN_SIZE}x{self.BTN_SIZE}+{self.orb_x}+{self.orb_y}")
            if self.popover_open and self.popover:
                self._position_popover()

    def _schedule_dock_tick(self) -> None:
        def _dock_loop() -> None:
            try:
                self._sync_dock_to_host()
            except Exception:
                pass
            self.root.after(self.DOCK_MS, _dock_loop)

        self.root.after(self.DOCK_MS, _dock_loop)

    def _on_press(self, event: tk.Event) -> None:
        self._drag_origin = (event.x_root, event.y_root)
        self._win_origin = (self.orb_x, self.orb_y)
        self._did_drag = False

    def _on_drag(self, event: tk.Event) -> None:
        if not self._drag_origin or not self._win_origin:
            return
        dx = event.x_root - self._drag_origin[0]
        dy = event.y_root - self._drag_origin[1]
        if abs(dx) >= 3 or abs(dy) >= 3:
            self._did_drag = True
        if self._did_drag:
            sw = self.root.winfo_screenwidth()
            sh = self.root.winfo_screenheight()
            self.orb_x = max(0, min(sw - self.BTN_SIZE, self._win_origin[0] + dx))
            self.orb_y = max(0, min(sh - self.BTN_SIZE, self._win_origin[1] + dy))
            self.root.geometry(f"{self.BTN_SIZE}x{self.BTN_SIZE}+{self.orb_x}+{self.orb_y}")
            if self._last_host_rect is not None:
                _l, _t, right, bottom = self._last_host_rect
                self.rel_right = right - self.orb_x - self.BTN_SIZE
                self.rel_bottom = bottom - self.orb_y - self.BTN_SIZE
            if self.popover_open and self.popover:
                self._position_popover()

    def _on_release(self, _event: tk.Event) -> None:
        if self._did_drag:
            self._save_state()
        else:
            self.toggle_popover()
        self._drag_origin = None
        self._win_origin = None

    def _on_right_click(self, event: tk.Event) -> None:
        try:
            self.menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.menu.grab_release()

    def _reset_position(self) -> None:
        self.rel_right = self.DEFAULT_REL_RIGHT
        self.rel_bottom = self.DEFAULT_REL_BOTTOM
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        if self._last_host_rect is not None:
            self.orb_x, self.orb_y = compute_docked_position(
                self._last_host_rect, self.BTN_SIZE, self.rel_right, self.rel_bottom, sw, sh
            )
        else:
            self.orb_x = max(20, int(sw * 0.52))
            self.orb_y = max(20, sh - 88)
        self.root.geometry(f"{self.BTN_SIZE}x{self.BTN_SIZE}+{self.orb_x}+{self.orb_y}")
        self._save_state()
        if self.popover_open and self.popover:
            self._position_popover()

    # ------------------------------------------------------------------
    # Refined Floating HUD Popover (DWM Rounded + Native Shadow + Live TTL)
    # ------------------------------------------------------------------

    def toggle_popover(self) -> None:
        if self.popover_open:
            self.close_popover()
        else:
            self.open_popover()
        self._render_orb()

    def open_popover(self) -> None:
        self.snapshot = fetch_snapshot(self.store)
        self._ttl_local_sec = int((self.snapshot.get("kv_cache") or {}).get("ttl_remaining_sec") or 0)
        self._render_orb()

        if self.popover is not None:
            self.popover.destroy()

        pop = tk.Toplevel(self.root)
        pop.title("Billion Context HUD")
        pop.overrideredirect(True)
        pop.attributes("-topmost", True)
        pop.configure(bg=BG_CARD)
        try:
            pop.attributes("-alpha", 0.985)
        except tk.TclError:
            pass

        self.popover = pop
        self.popover_open = True

        card = tk.Frame(pop, bg=BG_CARD, padx=18, pady=15)
        card.pack(fill="both", expand=True)

        # 1. Header Row: Title + Live Cache Warmth Pill + Refresh & Close Icons
        hdr = tk.Frame(card, bg=BG_CARD)
        hdr.pack(fill="x", pady=(0, 10))

        tk.Label(
            hdr,
            text="上下文估算",
            bg=BG_CARD,
            fg=TEXT_PRIMARY,
            font=("Microsoft YaHei UI", 10, "bold"),
        ).pack(side="left")

        self.lbl_cache_pill = tk.Label(
            hdr,
            text="缓存检测中",
            bg=BG_ELEVATED,
            fg=TEXT_SECONDARY,
            font=("Microsoft YaHei UI", 8, "bold"),
            padx=8,
            pady=2,
        )
        self.lbl_cache_pill.pack(side="left", padx=(9, 0))

        close_btn = tk.Label(
            hdr,
            text="✕",
            bg=BG_CARD,
            fg=TEXT_SECONDARY,
            font=("Segoe UI", 10),
            cursor="hand2",
            padx=5,
            pady=1,
        )
        close_btn.pack(side="right")
        close_btn.bind("<Button-1>", lambda _e: self.close_popover())
        close_btn.bind("<Enter>", lambda _e: close_btn.configure(fg=TEXT_PRIMARY, bg=BG_CHIP))
        close_btn.bind("<Leave>", lambda _e: close_btn.configure(fg=TEXT_SECONDARY, bg=BG_CARD))

        refresh_btn = tk.Label(
            hdr,
            text="↻",
            bg=BG_CARD,
            fg=TEXT_SECONDARY,
            font=("Segoe UI", 11),
            cursor="hand2",
            padx=5,
            pady=1,
        )
        refresh_btn.pack(side="right", padx=(0, 2))
        refresh_btn.bind("<Button-1>", lambda _e: self.refresh_now())
        refresh_btn.bind("<Enter>", lambda _e: refresh_btn.configure(fg=TEXT_PRIMARY, bg=BG_CHIP))
        refresh_btn.bind("<Leave>", lambda _e: refresh_btn.configure(fg=TEXT_SECONDARY, bg=BG_CARD))

        # 2. Smooth Anti-Aliased Quota Progress Bar + Savings Micro-line
        self.bar_width = 316
        self.bar_canvas = tk.Canvas(
            card,
            width=self.bar_width,
            height=6,
            bg=BG_CARD,
            highlightthickness=0,
            bd=0,
        )
        self.bar_canvas.pack(fill="x", pady=(0, 5))

        self.lbl_savings_bar = tk.Label(
            card,
            text="",
            bg=BG_CARD,
            fg=TEXT_MUTED,
            font=("Microsoft YaHei UI", 8),
            anchor="w",
        )
        self.lbl_savings_bar.pack(fill="x", pady=(0, 8))

        tk.Frame(card, height=1, bg=DIVIDER_HEX).pack(fill="x", pady=(0, 6))

        # 3. Five Crisp Key-Value Metric Rows
        self.val_labels = {}
        rows_spec = [
            ("usage", "占用 / 容量"),
            ("sample_model", "采样模型"),
            ("endpoint_model", "底层端点模型"),
            ("speed", "最近有效请求速度"),
            ("ttft", "该请求首 token 等待"),
        ]
        rows_frame = tk.Frame(card, bg=BG_CARD)
        rows_frame.pack(fill="x")

        for key, label_text in rows_spec:
            row = tk.Frame(rows_frame, bg=BG_CARD)
            row.pack(fill="x", pady=3)
            tk.Label(
                row,
                text=label_text,
                bg=BG_CARD,
                fg=TEXT_SECONDARY,
                font=("Microsoft YaHei UI", 9),
                anchor="w",
            ).pack(side="left")
            val_lbl = tk.Label(
                row,
                text="—",
                bg=BG_CARD,
                fg=TEXT_PRIMARY,
                font=("Segoe UI Semibold", 9),
                anchor="e",
            )
            val_lbl.pack(side="right", padx=(18, 0))
            self.val_labels[key] = val_lbl

        tk.Frame(card, height=1, bg=DIVIDER_HEX).pack(fill="x", pady=(8, 9))

        # 4. Sleek Interactive Control Chips (Keepalive Toggle + Rescue + Checkpoint)
        chip_row = tk.Frame(card, bg=BG_CARD)
        chip_row.pack(fill="x", pady=(0, 9))

        self.btn_keepalive = self._make_chip(chip_row, "续温: 关", self.cycle_keepalive_mode)
        self.btn_keepalive.pack(side="left", padx=(0, 6))

        self._make_chip(chip_row, "🛟 抢救简报", self.copy_rescue_brief_now).pack(side="left", padx=(0, 6))
        self._make_chip(chip_row, "⚡ 生成续接点", self.create_checkpoint_now).pack(side="left")

        # 5. Clean Explanatory Footer Notes
        notes_frame = tk.Frame(card, bg=BG_CARD)
        notes_frame.pack(fill="x")
        wrap_px = 316

        self.lbl_note1 = tk.Label(
            notes_frame,
            text=NOTE_LINE_1,
            bg=BG_CARD,
            fg=TEXT_MUTED,
            font=("Microsoft YaHei UI", 8),
            justify="left",
            anchor="w",
            wraplength=wrap_px,
        )
        self.lbl_note1.pack(fill="x", pady=(0, 3))

        self.lbl_note2 = tk.Label(
            notes_frame,
            text=NOTE_LINE_2_IDLE,
            bg=BG_CARD,
            fg=TEXT_MUTED,
            font=("Microsoft YaHei UI", 8),
            justify="left",
            anchor="w",
            wraplength=wrap_px,
        )
        self.lbl_note2.pack(fill="x", pady=(0, 3))

        self.lbl_note3 = tk.Label(
            notes_frame,
            text=NOTE_LINE_3,
            bg=BG_CARD,
            fg=TEXT_MUTED,
            font=("Microsoft YaHei UI", 8),
            justify="left",
            anchor="w",
            wraplength=wrap_px,
        )
        self.lbl_note3.pack(fill="x")

        self.lbl_toast = tk.Label(
            card,
            text="",
            bg=BG_CARD,
            fg=LEVEL_HEX["OK"],
            font=("Microsoft YaHei UI", 8, "bold"),
            anchor="w",
        )

        self._render_popover_values()
        pop.update_idletasks()
        apply_dwm_window_styling(pop, small_corners=False, border_rgb=(48, 54, 72))
        self._position_popover()

    def _make_chip(self, parent: tk.Widget, text: str, cmd: Any) -> tk.Label:
        chip = tk.Label(
            parent,
            text=text,
            bg=BG_CHIP,
            fg=TEXT_PRIMARY,
            font=("Microsoft YaHei UI", 8),
            padx=9,
            pady=4,
            cursor="hand2",
        )
        chip.bind("<Button-1>", lambda _e: cmd())
        chip.bind("<Enter>", lambda _e: chip.configure(bg=BG_CHIP_HOVER))
        chip.bind("<Leave>", lambda _e: chip.configure(bg=BG_CHIP_ACTIVE if getattr(chip, "_active_ka", False) else BG_CHIP))
        return chip

    def _position_popover(self) -> None:
        if not self.popover:
            return
        self.popover.update_idletasks()
        pw = max(352, self.popover.winfo_reqwidth())
        ph = self.popover.winfo_reqheight()
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()

        px = self.orb_x - 4
        py = self.orb_y - ph - 10
        if py < 12:
            py = self.orb_y + self.BTN_SIZE + 10
        px = max(12, min(sw - pw - 12, px))
        py = max(12, min(sh - ph - 12, py))
        self.popover.geometry(f"{pw}x{ph}+{px}+{py}")

    def _update_cache_pill_text(self) -> None:
        if not self.popover_open or not self.popover:
            return
        est = self.snapshot.get("estimator", {})
        hit = est.get("cache_hit_percent", "0.0%")
        if self._ttl_local_sec > 0:
            mm, ss = divmod(self._ttl_local_sec, 60)
            if self._ttl_local_sec <= 75:
                self.lbl_cache_pill.configure(text=f"⏳ {mm:02d}:{ss:02d} · {hit}", fg=LEVEL_HEX["RECOMMEND"])
            else:
                self.lbl_cache_pill.configure(text=f"🔥 缓存热 {mm:02d}:{ss:02d} · {hit}", fg=LEVEL_HEX["OK"])
        else:
            self.lbl_cache_pill.configure(text=f"缓存已冷却 · {hit}", fg=TEXT_MUTED)

    def _render_popover_values(self) -> None:
        if not self.popover_open or not self.popover:
            return
        est = self.snapshot.get("estimator", {})
        lsm = self.snapshot.get("lsm", {})
        guard = self.snapshot.get("guard", {})
        cfg = self.snapshot.get("settings", {})
        w_list = self.snapshot.get("watchdog_sessions") or []

        level = str(est.get("pressure_level") or "OK").upper()
        pct = min(100.0, max(0.0, float(est.get("pressure_percent_num") or 0.0)))

        # Anti-aliased progress bar
        bar_ppm = render_aa_progress_bar_ppm(
            self.bar_width, 6, pct, LEVEL_RGB.get(level, LEVEL_RGB["OK"])
        )
        self._bar_photo = tk.PhotoImage(data=bar_ppm)
        self.bar_canvas.delete("all")
        self.bar_canvas.create_image(0, 0, image=self._bar_photo, anchor="nw")

        tc = lsm.get("tier_counts", {})
        tot_blocks = int(tc.get("T1", 0)) + int(tc.get("T2", 0)) + int(tc.get("T3", 0))
        saved_disp = guard.get("combined_saved_display") or lsm.get("net_tokens_saved_display") or "0"
        self.lbl_savings_bar.configure(
            text=f"已净省 {saved_disp} tokens · LSM 记忆块 {tot_blocks} · 工作区累计 {est.get('workspace_cumulative_display', '0')}"
        )

        self._update_cache_pill_text()

        usage = est.get("usage_display", "暂不可用")
        self.val_labels["usage"].configure(text=usage, fg=TEXT_PRIMARY)
        self.val_labels["sample_model"].configure(
            text=est.get("sample_model_display", "—"),
            fg=TEXT_PRIMARY,
            font=("Microsoft YaHei UI", 9, "bold"),
        )
        ep = est.get("endpoint_model_display", "—")
        self.val_labels["endpoint_model"].configure(
            text=ep,
            fg=TEXT_SECONDARY if ep == "—" else TEXT_PRIMARY,
        )
        spd = est.get("request_speed_display", "等待有效请求")
        self.val_labels["speed"].configure(
            text=spd,
            fg=TEXT_SECONDARY if spd == "等待有效请求" else TEXT_PRIMARY,
        )
        self.val_labels["ttft"].configure(text=est.get("ttft_display", "—"), fg=TEXT_SECONDARY)

        # Keepalive chip state
        cid = self.snapshot.get("conversation_id")
        cur_lease = next((w for w in w_list if w.get("conversation_id") == cid), None)
        ka_mode = (
            cur_lease["keepalive_mode"]
            if (cur_lease and cur_lease.get("keepalive_mode") not in (None, "inherit"))
            else str(cfg.get("keepalive_mode") or "off")
        )
        is_ka_on = ka_mode != "off"
        self.btn_keepalive._active_ka = is_ka_on  # type: ignore[attr-defined]
        self.btn_keepalive.configure(
            text=("🔥 " if is_ka_on else "") + KEEPALIVE_LABELS.get(ka_mode, "续温: 关"),
            bg=BG_CHIP_ACTIVE if is_ka_on else BG_CHIP,
        )

        if usage == "暂不可用":
            self.lbl_note2.configure(text=NOTE_LINE_2_IDLE)
        else:
            self.lbl_note2.configure(
                text=f"物理轨迹窗口 {est.get('physical_usage_display', '—')} · 读取护栏 {cfg.get('read_preset', 'host-45k')}。"
            )

    def _show_toast(self, text: str, is_err: bool = False) -> None:
        if not self.popover_open or not self.popover:
            return
        self.lbl_toast.configure(
            text=text,
            fg=LEVEL_HEX["URGENT"] if is_err else LEVEL_HEX["OK"],
        )
        self.lbl_toast.pack(fill="x", pady=(6, 0))
        self._position_popover()
        self.root.after(3600, lambda: self._clear_toast())

    def _clear_toast(self) -> None:
        if self.popover_open and self.popover:
            try:
                self.lbl_toast.configure(text="")
                self.lbl_toast.pack_forget()
                self._position_popover()
            except tk.TclError:
                pass

    def close_popover(self) -> None:
        self.popover_open = False
        if self.popover is not None:
            self.popover.destroy()
            self.popover = None
        self._render_orb()

    # ------------------------------------------------------------------
    # Actions & Background Timers
    # ------------------------------------------------------------------

    def refresh_now(self) -> None:
        try:
            self.snapshot = fetch_snapshot(self.store)
            self._ttl_local_sec = int((self.snapshot.get("kv_cache") or {}).get("ttl_remaining_sec") or 0)
            self._render_orb()
            self._render_popover_values()
            if self.popover_open:
                self._position_popover()
                self._show_toast("✓ 已同步最新上下文与缓存状态")
        except Exception as exc:
            self._show_toast(f"刷新失败: {exc}", is_err=True)

    def cycle_keepalive_mode(self) -> None:
        try:
            guard = self.store.get_guard()
            cid = self.snapshot.get("conversation_id")
            cfg = self.snapshot.get("settings") or guard.get_settings()
            w_list = self.snapshot.get("watchdog_sessions") or []
            cur_lease = next((w for w in w_list if w.get("conversation_id") == cid), None)
            cur_mode = (
                cur_lease["keepalive_mode"]
                if (cur_lease and cur_lease.get("keepalive_mode") not in (None, "inherit"))
                else str(cfg.get("keepalive_mode") or "off")
            )
            next_idx = (KEEPALIVE_CYCLE.index(cur_mode) + 1) % len(KEEPALIVE_CYCLE) if cur_mode in KEEPALIVE_CYCLE else 1
            new_mode = KEEPALIVE_CYCLE[next_idx]
            if cid:
                guard.set_session_keepalive_mode(cid, new_mode)
            else:
                guard.update_settings({"keepalive_mode": new_mode})
            self.snapshot = fetch_snapshot(self.store, conversation_id=cid)
            self._render_popover_values()
            self._show_toast(f"✓ 自动缓存续温已切换为: {KEEPALIVE_LABELS[new_mode]}")
        except Exception as exc:
            self._show_toast(f"切换失败: {exc}", is_err=True)

    def copy_rescue_brief_now(self) -> None:
        try:
            cid = self.snapshot.get("conversation_id")
            rb = self.store.get_guard().build_rescue_brief(conversation_id=cid)
            self.root.clipboard_clear()
            self.root.clipboard_append(rb["rescue_markdown"])
            self.root.update()
            self._show_toast("✓ 已复制崩溃抢救简报，可直接粘贴至新对话")
        except Exception as exc:
            self._show_toast(f"生成抢救简报失败: {exc}", is_err=True)

    def create_checkpoint_now(self) -> None:
        try:
            cid = self.snapshot.get("conversation_id")
            if not cid:
                self._show_toast("暂无活动会话", is_err=True)
                return
            cp = self.store.create_checkpoint(
                conversation_id=cid,
                reason="chatbar_hud",
                write_artifact=True,
            )
            self._show_toast(f"✓ 已生成无损续接点 {cp['checkpoint_id']}")
        except Exception as exc:
            self._show_toast(f"生成失败: {exc}", is_err=True)

    def _schedule_poll(self) -> None:
        def _tick() -> None:
            try:
                self.snapshot = fetch_snapshot(self.store)
                self._ttl_local_sec = int((self.snapshot.get("kv_cache") or {}).get("ttl_remaining_sec") or 0)
                self._render_orb()
                if self.popover_open:
                    self._render_popover_values()
            except Exception:
                pass
            self.root.after(self.poll_ms, _tick)

        self.root.after(self.poll_ms, _tick)

    def _schedule_second_ticker(self) -> None:
        def _sec_tick() -> None:
            if self._ttl_local_sec > 0:
                self._ttl_local_sec -= 1
                if self.popover_open:
                    self._update_cache_pill_text()
                elif self._ttl_local_sec in (0, 75):
                    self._render_orb()
            self.root.after(1000, _sec_tick)

        self.root.after(1000, _sec_tick)

    def _schedule_keepalive_daemon(self) -> None:
        def _ka_tick() -> None:
            try:
                guard = self.store.get_guard()
                res = guard.tick_auto_keepalive()
                w_list = guard.list_watchdog_sessions()
                stalled = sum(1 for w in w_list if w.get("stalled"))
                guard.record_watchdog_heartbeat(
                    worker_id="hud:chatbar",
                    stalled_count=stalled,
                    detail=f"pinged={len(res.get('pinged', []))}, sessions={len(w_list)}",
                )
            except Exception:
                pass
            self.root.after(self.KEEPALIVE_TICK_MS, _ka_tick)

        self.root.after(1500, _ka_tick)

    def quit(self) -> None:
        try:
            if PID_FILE.exists():
                PID_FILE.unlink(missing_ok=True)
        except Exception:
            pass
        self.close_popover()
        self.root.destroy()

    def run(self) -> None:
        try:
            PID_FILE.parent.mkdir(parents=True, exist_ok=True)
            PID_FILE.write_text(str(os.getpid()), encoding="utf-8")
        except Exception:
            pass
        self.root.mainloop()


def is_pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    if sys.platform == "win32":
        try:
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            handle = ctypes.windll.kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if not handle:
                return False
            exit_code = ctypes.c_ulong()
            ok = ctypes.windll.kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code))
            ctypes.windll.kernel32.CloseHandle(handle)
            return bool(ok and exit_code.value == 259)
        except Exception:
            return False
    else:
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False


def main() -> None:
    parser = argparse.ArgumentParser(description="Billion-Context DWM Chat-Bar HUD")
    parser.add_argument("--data-dir", default=None, help="ACP plugin_data directory")
    parser.add_argument("--no-dock", action="store_true", help="Disable Win32 window auto-docking")
    parser.add_argument("--singleton", action="store_true", help="Exit immediately if an instance is already running")
    parser.add_argument("--once", action="store_true", help="Print live snapshot JSON and exit without GUI loop")
    args = parser.parse_args()

    if args.once:
        store = ACPStore(data_dir=args.data_dir or DEFAULT_PLUGIN_DATA)
        print(json.dumps(fetch_snapshot(store), indent=2, ensure_ascii=False))
        return

    if args.singleton and PID_FILE.exists():
        try:
            old_pid = int(PID_FILE.read_text(encoding="utf-8").strip())
            if is_pid_alive(old_pid):
                return
        except Exception:
            pass

    enable_windows_dpi_awareness()
    app = ContextEstimatorApp(data_dir=args.data_dir, auto_dock=not args.no_dock)
    app.run()


if __name__ == "__main__":
    main()
