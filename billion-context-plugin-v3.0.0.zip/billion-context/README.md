# Billion Context Studio (v3.0) for Google Antigravity

Native **Active Context Pruning (ACP) + KV-Cache Warmth + Quota Guard + Watchdog Sidecar** plugin for Google Antigravity, fusing [`ranxianglei/billion-context`](https://github.com/ranxianglei/billion-context) (`acp-kernel`) and [`zou172866/Antigravity-agy-dart`](https://github.com/zou172866/Antigravity-agy-dart) with a custom Bento Studio dashboard and Win32 DWM + SDF anti-aliased chat-bar HUD.

## Included Customizations

- **MCP Server (`billion-context_acp`)**:
  - `acp_status` — Dual-window telemetry (`512K` logical & physical capacity), prompt cache hit %, KV-Cache warmth & TTL countdown, generation speed (`tok/s`), savings ledger, and semantic episode candidates (`s00000..s00025`).
  - `compress` / `decompress` / `search_context` / `pin_context` / `handoff_checkpoint` — 3-stage LSM pipeline (`capture` → `distill` → `condense`), cross-session reversible expansion, hybrid SQLite FTS5 BM25 + regex search, invariants pinning, and lossless `acp_handoff.md` checkpoints.
  - `batch_search` / `read_slices` / `run_checks` / `ctx_index` / `ctx_execute` / `ctx_rescue` / `ctx_purge` — Fast parallel search/slice/checks, FTS5 vault indexing, local Python analysis sandbox (`<= 8.8 KB`), and 1-click crash rescue brief.
  - `context_estimator_ui` — Original **Billion Context Studio** MCP App (`inline`, `aux_pane`, and `global` sidebar).
- **Native Watchdog Sidecar (`sidecars/watchdog/`)**: Always-on background daemon evaluating auto-keepalive (`agentapi`), writing `acp_rescue.md` on stalled sessions, and reporting live heartbeats (`watchdog_heartbeats`).
- **Lifecycle Hooks (`hooks.json`)**: `SessionStart`, `PreToolUse` (4-tier read quota guard, `diff_read` unified-diff guard, CLI 8.8KB noise filter, secret guard), `PostToolUse`, `PreInvocation` (zero-prefix-pollution alerts), and `Stop`.
- **Always-On Rule, Skill & Subagent**: `rules/AGENTS.md`, `skills/acp-context-management/SKILL.md`, and `agents/context-curator.md`.
