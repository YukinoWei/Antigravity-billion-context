# Billion-Context v3.0 — Active Context Pruning, KV-Cache Hygiene & Fast Batch Discipline

This workspace runs **Billion Context Studio v3.0** (`billion-context_acp` MCP server + 5 lifecycle hooks), fusing `ranxianglei/billion-context` (`acp-kernel`) with `Antigravity-agy-dart` KV-Cache protection, quota guards, fast batching, and crash rescue on a **512K** context window.

## Core Discipline

1. **Combine actions in fewer turns (`batch_search` / `read_slices` / `run_checks`)**:
   - Batch multi-term searches via `batch_search`, inspect unfamiliar large files with `read_slices(outlines=[...])` before reading targeted line ranges, and batch short checks via `run_checks` (keeping `run_command` for long/async jobs).
2. **Filter noisy logs & huge docs (`ctx_index` / `ctx_execute`)**:
   - Index multi-thousand-line docs or URLs once with `ctx_index` and query sections via `search_context(scope="vault")`. Analyze multi-MB JSON/CSV/logs locally with `ctx_execute` so only `<= 8.8 KB` summaries enter the prompt.
3. **3-Stage LSM Context Folding (`compress` -> `decompress`)**:
   - Fold completed older episodes into T1 blocks with `compress(operation="capture", range_ref="s00000..s00025", ...)`; promote 4+ T1 blocks into T2 Milestones (`operation="distill"`) and T2s into T3 Epochs (`operation="condense"`).
   - Search across sessions with `search_context(workspace_wide=True)` before calling `decompress`.
4. **Protect invariants & rescue cleanly (`pin_context` / `ctx_rescue` / `handoff_checkpoint`)**:
   - Pin critical constraints via `pin_context(action="pin", scope="workspace", ...)`. Use `ctx_rescue` or `handoff_checkpoint` for lossless `/compact` or cross-session continuation, and call `context_estimator_ui` when asked to open the plugin dashboard.
