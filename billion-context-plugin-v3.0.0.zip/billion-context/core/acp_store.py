"""ACP (Active Context Pruning) storage, transcript telemetry, and LSM block kernel.

Modeled on ranxianglei/billion-context and ranxianglei/acp-kernel (dsh / Claude Code / OpenCode),
engineered natively for Google Antigravity's transcript.jsonl, lifecycle hooks, MCP Apps,
and multi-session workspace lineage.

Key architectural capabilities:
  1. 3-Stage LSM Memory Pipeline:
     - L0 (Active Tail): Protected recent raw steps (verbatim).
     - T1 (capture): Contiguous raw step ranges folded with hybrid deterministic metadata harvesting
       (files, commands, tools, errors, skill/system boundaries) + model-authored structured summary.
     - T2 (distill): 2+ T1 Episode blocks merged into Milestone blocks with child provenance.
     - T3 (condense): 2+ T2 Milestone blocks merged into Epoch blocks for million/billion-token continuity.
  2. Dual-Window Prefix-Cache-Friendly Accounting:
     - Logical ACP Working Set vs Soft Budget (default 100K — "a 100K context is enough"):
       Subtracts folded raw step tokens and adds compact summary tokens so folding immediately
       relieves logical pressure without infinite nudges.
     - Physical Trajectory Tokens vs Model Context Window (auto-detected per model: 1M Gemini,
       200K Claude, 128K DeepSeek/dsh, etc.): Advises /compact or session rotation only near
       actual physical window saturation.
  3. Cross-Session Workspace Lineage:
     - Searches and decompresses blocks seamlessly across all rotated/continued conversations
       sharing the same workspace, reading each block from its originating session's transcript_full.jsonl.
"""

from __future__ import annotations

import contextlib
import hashlib
import json
import os
import re
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

# Antigravity default context window capacity: 512K (512,000 tokens)
DEFAULT_ACP_SOFT_BUDGET = int(
    os.environ.get("BILLION_CONTEXT_SOFT_BUDGET")
    or os.environ.get("BILLION_CONTEXT_WINDOW")
    or "512000"
)
DEFAULT_PROTECT_RECENT_STEPS = int(os.environ.get("BILLION_CONTEXT_PROTECT_RECENT", "8"))
MIN_COMPRESSIBLE_TOKENS = int(os.environ.get("BILLION_CONTEXT_MIN_FOLD_TOKENS", "2500"))
TARGET_EPISODE_TOKENS = int(os.environ.get("BILLION_CONTEXT_EPISODE_TOKENS", "22000"))

# Logical ACP pressure thresholds relative to soft_budget
PRESSURE_SOFT = 0.55
PRESSURE_RECOMMEND = 0.75
PRESSURE_URGENT = 0.88

# Physical window threshold where /compact or session rotation is recommended
PHYSICAL_COMPACT_RATIO = 0.80


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _parse_iso_ts(raw: str | None) -> float | None:
    if not raw or not isinstance(raw, str):
        return None
    try:
        cleaned = raw.strip()
        if cleaned.endswith("Z"):
            cleaned = cleaned[:-1] + "+00:00"
        return datetime.fromisoformat(cleaned).timestamp()
    except ValueError:
        return None


def estimate_tokens(text: str) -> int:
    """Estimate token count for mixed English/code/CJK text without external tokenizers."""
    if not text:
        return 0
    cjk_chars = len(re.findall(r"[\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af]", text))
    other_chars = max(0, len(text) - cjk_chars)
    return max(1, int(round(cjk_chars / 1.5 + other_chars / 3.8)))


def default_app_data_dir() -> Path:
    env_app = os.environ.get("ANTIGRAVITY_APP_DATA_DIR")
    if env_app:
        return Path(env_app)
    home_gemini = Path.home() / ".gemini"
    for product_dir in ("antigravity", "antigravity-ide", "antigravity-cli"):
        cand = home_gemini / product_dir
        if cand.exists():
            return cand
    return home_gemini / "antigravity"


def default_data_dir() -> Path:
    """Resolve the persistent plugin_data directory consistently across MCP, Hooks, CLI, and Widget."""
    env_dir = os.environ.get("PLUGIN_DATA") or os.environ.get("BILLION_CONTEXT_DATA")
    if env_dir:
        return Path(env_dir)
    app_data = default_app_data_dir()
    return app_data / "plugin_data" / "billion-context"


def normalize_workspace_key(workspace_paths: list[str] | None, cwd: str | None = None) -> str:
    target = ""
    if workspace_paths:
        for p in workspace_paths:
            if p:
                target = str(p)
                break
    elif cwd:
        target = str(cwd)
    if not target:
        return ""
    if target.startswith("file:///"):
        target = target[len("file:///"):]
    return target.replace("\\", "/").rstrip("/").lower()


def resolve_full_transcript_path(transcript_path: str | None) -> str | None:
    if not transcript_path:
        return None
    p = Path(transcript_path)
    if p.name == "transcript.jsonl":
        full_p = p.with_name("transcript_full.jsonl")
        if full_p.exists():
            return str(full_p)
    return str(p)


def safe_json_loads(raw: str | None, fallback: Any) -> Any:
    if not raw:
        return fallback
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return fallback


def format_step_ref(step_index: int) -> str:
    return f"s{int(step_index):05d}"


def parse_step_range_ref(
    range_ref: str | None,
    start_step: int | None = None,
    end_step: int | None = None,
) -> tuple[int, int]:
    """Parse either ('s00000..s00025' / 'm00000..m00025' / '0..25' / '0-25') or explicit ints."""
    if range_ref and isinstance(range_ref, str):
        m = re.match(
            r"^\s*[smSM]?(\d+)\s*(?:\.\.+|-|:)\s*[smSM]?(\d+)\s*$",
            range_ref.strip(),
        )
        if not m:
            single = re.match(r"^\s*[smSM]?(\d+)\s*$", range_ref.strip())
            if single:
                idx = int(single.group(1))
                return idx, idx
            raise ValueError(
                f"Invalid range_ref '{range_ref}'. Expected format like 's00000..s00025' or '0..25'."
            )
        return int(m.group(1)), int(m.group(2))
    if start_step is None or end_step is None:
        raise ValueError("Provide either range_ref (e.g. 's00000..s00025') or both start_step and end_step.")
    return int(start_step), int(end_step)


def detect_physical_window(model_name: str | None) -> int:
    """Detect physical context window capacity dynamically from model name (256K/512K/200K/1M/128K)."""
    env_override = os.environ.get("BILLION_CONTEXT_PHYSICAL_WINDOW") or os.environ.get("BILLION_CONTEXT_WINDOW")
    if env_override:
        try:
            return max(16000, int(env_override))
        except ValueError:
            pass
    m = (model_name or "").lower()
    if not m or m == "auto":
        return 512_000
    # 1. Explicit window tags in model name (e.g. "-256k", "-512k", "-1m", "-128k", "-200k")
    if re.search(r"(?:^|[-_/\s])1m(?:\b|[-_])", m) or "1000k" in m:
        return 1_000_000
    m_k = re.search(r"(?:^|[-_/\s])(\d{2,4})k(?:\b|[-_])", m)
    if m_k:
        k_val = int(m_k.group(1))
        if 16 <= k_val <= 2048:
            return k_val * 1000
    # 2. Known model families
    if "gemini-1.5" in m or "gemini-2.5" in m:
        return 1_000_000
    if "gemini" in m or any(x in m for x in ("carbon", "hydrogen", "neon", "helium", "lithium")):
        return 512_000
    if any(x in m for x in ("gpt-5", "codex", "qwen3", "qwen-3", "kimi", "glm-4.5", "glm-5", "minimax")):
        return 256_000
    if "claude" in m or "sonnet" in m or "opus" in m or "haiku" in m:
        return 200_000
    if "o1" in m or "o3" in m or "o4" in m:
        return 200_000
    if "gpt-4" in m or "deepseek" in m or "dsh" in m or "llama-3" in m:
        return 128_000
    return 512_000


def format_window_label(tokens: int) -> str:
    """Format context window size cleanly as e.g. '256K', '512K', '200K', '1M'."""
    t = max(1, int(tokens))
    if t >= 1_000_000:
        return f"{t // 1_000_000}M" if t % 1_000_000 == 0 else f"{t / 1_000_000:.1f}M"
    if t >= 1_000:
        return f"{int(round(t / 1000))}K"
    return str(t)


def format_model_display(model_id: str | None) -> str:
    if not model_id or model_id == "auto":
        return "—"
    known = {
        "gemini-4-carbon-high": "Gemini 4 Carbon 高",
        "gemini-4-carbon-medium": "Gemini 4 Carbon 中",
        "gemini-4-carbon-low": "Gemini 4 Carbon 低",
        "gemini-4-carbon": "Gemini 4 Carbon",
        "gemini-4-hydrogen-high": "Gemini 4 Hydrogen 高",
        "gemini-4-hydrogen-medium": "Gemini 4 Hydrogen 中",
        "gemini-4-hydrogen-low": "Gemini 4 Hydrogen 低",
        "gemini-4-hydrogen": "Gemini 4 Hydrogen",
    }
    low = model_id.lower()
    if low in known:
        return known[low]
    # Generic humanizer matching screenshot style ("Gemini 4 Carbon 高")
    parts = model_id.replace("_", "-").split("-")
    tier_map = {"high": "高", "medium": "中", "low": "低", "pro": "Pro", "flash": "Flash", "lite": "Lite"}
    pretty: list[str] = []
    for p in parts:
        pl = p.lower()
        if pl in tier_map:
            pretty.append(tier_map[pl])
        elif pl in ("gpt", "o1", "o3", "o4", "dsh"):
            pretty.append(pl.upper())
        else:
            pretty.append(p.capitalize())
    return " ".join(pretty)


def _fts5_safe_query(query: str) -> str:
    tokens = re.findall(r"[\w\u4e00-\u9fff\-./:]+", query)
    if not tokens:
        return ""
    escaped = ['"' + t.replace('"', '""') + '"' for t in tokens[:12]]
    return " OR ".join(escaped)


def _clean_user_request_preview(text: str) -> str:
    if not text:
        return ""
    m = re.search(r"<USER_REQUEST>\s*(.*?)\s*</USER_REQUEST>", text, flags=re.DOTALL)
    body = m.group(1) if m else text
    body = re.sub(r"<[^>]+>", " ", body)
    body = re.sub(r"\s+", " ", body).strip()
    return body[:140]


@dataclass
class TranscriptStats:
    total_steps: int
    min_step: int
    max_step: int
    last_input_tokens: int
    last_cache_read_tokens: int
    last_output_tokens: int
    cumulative_tokens: int
    model_name: str
    approx_tok_per_sec: float | None = None
    step_weights: dict[int, int] = field(default_factory=dict)
    step_types: dict[int, str] = field(default_factory=dict)
    step_summaries: dict[int, str] = field(default_factory=dict)
    step_tools: dict[int, list[str]] = field(default_factory=dict)
    user_turn_steps: list[int] = field(default_factory=list)


class ACPStore:
    """SQLite + FTS5 backed Active Context Pruning (acp-kernel) store."""

    def __init__(self, data_dir: str | Path | None = None) -> None:
        self.data_dir = Path(data_dir) if data_dir else default_data_dir()
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = self.data_dir / "acp.db"
        self._fts_available = False
        self._init_db()

    @contextlib.contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(str(self.db_path), timeout=15.0)
        conn.row_factory = sqlite3.Row
        try:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute("PRAGMA busy_timeout=10000")
            with conn:
                yield conn
        finally:
            conn.close()

    def _ensure_column(self, conn: sqlite3.Connection, table: str, col: str, col_def: str) -> None:
        existing = {r["name"] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}
        if col not in existing:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} {col_def}")

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS sessions (
                    conversation_id TEXT PRIMARY KEY,
                    parent_conversation_id TEXT,
                    transcript_path TEXT,
                    transcript_full_path TEXT,
                    artifact_dir TEXT,
                    workspace_paths TEXT,
                    workspace_key TEXT,
                    cwd TEXT,
                    model_name TEXT,
                    context_window INTEGER DEFAULT 512000,
                    physical_window INTEGER DEFAULT 512000,
                    last_input_tokens INTEGER DEFAULT 0,
                    last_cache_read_tokens INTEGER DEFAULT 0,
                    last_output_tokens INTEGER DEFAULT 0,
                    cumulative_tokens INTEGER DEFAULT 0,
                    approx_tok_per_sec REAL DEFAULT 0,
                    total_steps INTEGER DEFAULT 0,
                    last_nudge_tier TEXT DEFAULT 'OK',
                    urgent_nudge_counter INTEGER DEFAULT 0,
                    physical_nudge_sent INTEGER DEFAULT 0,
                    updated_at TEXT
                );

                CREATE TABLE IF NOT EXISTS blocks (
                    block_id TEXT PRIMARY KEY,
                    conversation_id TEXT NOT NULL,
                    workspace_key TEXT DEFAULT '',
                    tier INTEGER NOT NULL,
                    operation TEXT DEFAULT 'capture',
                    start_step INTEGER NOT NULL,
                    end_step INTEGER NOT NULL,
                    range_ref TEXT,
                    parent_block_id TEXT,
                    child_block_ids TEXT DEFAULT '[]',
                    title TEXT NOT NULL,
                    summary TEXT NOT NULL,
                    entities TEXT DEFAULT '[]',
                    decisions TEXT DEFAULT '[]',
                    open_questions TEXT DEFAULT '[]',
                    preserved_boundaries TEXT DEFAULT '[]',
                    raw_token_estimate INTEGER DEFAULT 0,
                    summary_token_estimate INTEGER DEFAULT 0,
                    content_hash TEXT,
                    created_at TEXT NOT NULL,
                    archived INTEGER DEFAULT 0
                );

                CREATE TABLE IF NOT EXISTS pins (
                    pin_id TEXT PRIMARY KEY,
                    scope TEXT NOT NULL,
                    scope_id TEXT NOT NULL,
                    category TEXT NOT NULL,
                    title TEXT NOT NULL,
                    content TEXT NOT NULL,
                    step_ref INTEGER,
                    created_at TEXT NOT NULL,
                    updated_at TEXT,
                    active INTEGER DEFAULT 1
                );

                CREATE TABLE IF NOT EXISTS tool_telemetry (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    conversation_id TEXT NOT NULL,
                    step_index INTEGER,
                    tool_name TEXT NOT NULL,
                    approx_tokens INTEGER DEFAULT 0,
                    summary TEXT,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS checkpoints (
                    checkpoint_id TEXT PRIMARY KEY,
                    conversation_id TEXT NOT NULL,
                    workspace_key TEXT,
                    reason TEXT,
                    current_goal TEXT DEFAULT '',
                    next_steps TEXT DEFAULT '[]',
                    packet_markdown TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                """
            )
            # Schema migrations for existing v1 databases MUST run before indexes on new columns
            self._ensure_column(conn, "sessions", "parent_conversation_id", "TEXT")
            self._ensure_column(conn, "sessions", "context_window", "INTEGER DEFAULT 512000")
            self._ensure_column(conn, "sessions", "physical_window", "INTEGER DEFAULT 512000")
            self._ensure_column(conn, "sessions", "approx_tok_per_sec", "REAL DEFAULT 0")
            self._ensure_column(conn, "sessions", "last_nudge_tier", "TEXT DEFAULT 'OK'")
            self._ensure_column(conn, "sessions", "urgent_nudge_counter", "INTEGER DEFAULT 0")
            self._ensure_column(conn, "sessions", "physical_nudge_sent", "INTEGER DEFAULT 0")
            self._ensure_column(conn, "sessions", "last_seen_physical_tokens", "INTEGER DEFAULT 0")
            self._ensure_column(conn, "sessions", "last_rehydrated_at", "TEXT")
            if not (os.environ.get("BILLION_CONTEXT_SOFT_BUDGET") or os.environ.get("BILLION_CONTEXT_WINDOW")):
                conn.execute(
                    "UPDATE sessions SET context_window = 512000, last_nudge_tier = 'OK', urgent_nudge_counter = 0 WHERE context_window IN (100000, 128000)"
                )
            self._ensure_column(conn, "blocks", "workspace_key", "TEXT DEFAULT ''")
            self._ensure_column(conn, "blocks", "operation", "TEXT DEFAULT 'capture'")
            self._ensure_column(conn, "blocks", "range_ref", "TEXT")
            self._ensure_column(conn, "blocks", "preserved_boundaries", "TEXT DEFAULT '[]'")
            self._ensure_column(conn, "pins", "updated_at", "TEXT")
            self._ensure_column(conn, "checkpoints", "current_goal", "TEXT DEFAULT ''")
            self._ensure_column(conn, "checkpoints", "next_steps", "TEXT DEFAULT '[]'")

            conn.executescript(
                """
                CREATE INDEX IF NOT EXISTS idx_sessions_ws
                    ON sessions(workspace_key, updated_at);
                CREATE INDEX IF NOT EXISTS idx_blocks_conv_tier
                    ON blocks(conversation_id, archived, tier, start_step);
                CREATE INDEX IF NOT EXISTS idx_blocks_ws_tier
                    ON blocks(workspace_key, archived, tier, created_at);
                CREATE INDEX IF NOT EXISTS idx_pins_scope
                    ON pins(scope, scope_id, active);
                CREATE INDEX IF NOT EXISTS idx_tool_tel_conv
                    ON tool_telemetry(conversation_id, step_index);
                CREATE INDEX IF NOT EXISTS idx_checkpoints_ws
                    ON checkpoints(workspace_key, created_at);
                """
            )

            # Backfill workspace_key on older blocks if empty
            conn.execute(
                """
                UPDATE blocks
                SET workspace_key = COALESCE(
                    (SELECT s.workspace_key FROM sessions s WHERE s.conversation_id = blocks.conversation_id),
                    ''
                )
                WHERE workspace_key IS NULL OR workspace_key = ''
                """
            )

            try:
                conn.execute(
                    """
                    CREATE VIRTUAL TABLE IF NOT EXISTS blocks_fts USING fts5(
                        block_id UNINDEXED,
                        conversation_id UNINDEXED,
                        title,
                        summary,
                        entities,
                        decisions
                    )
                    """
                )
                self._fts_available = True
            except sqlite3.OperationalError:
                self._fts_available = False

    # ------------------------------------------------------------------
    # Session & Lineage Registration
    # ------------------------------------------------------------------

    def register_session(
        self,
        conversation_id: str,
        transcript_path: str | None = None,
        artifact_dir: str | None = None,
        workspace_paths: list[str] | None = None,
        cwd: str | None = None,
        model_name: str | None = None,
        context_window: int | None = None,
        physical_window: int | None = None,
        parent_conversation_id: str | None = None,
    ) -> dict[str, Any]:
        if not conversation_id:
            raise ValueError("conversation_id is required")
        ws_list = workspace_paths or []
        ws_key = normalize_workspace_key(ws_list, cwd)
        full_path = resolve_full_transcript_path(transcript_path)
        now = utc_now_iso()
        phys_win = physical_window or (detect_physical_window(model_name) if model_name and model_name != "auto" else None)

        with self._connect() as conn:
            existing = conn.execute(
                "SELECT * FROM sessions WHERE conversation_id = ?",
                (conversation_id,),
            ).fetchone()
            if existing:
                conn.execute(
                    """
                    UPDATE sessions SET
                        parent_conversation_id = COALESCE(?, parent_conversation_id),
                        transcript_path = COALESCE(?, transcript_path),
                        transcript_full_path = COALESCE(?, transcript_full_path),
                        artifact_dir = COALESCE(?, artifact_dir),
                        workspace_paths = COALESCE(?, workspace_paths),
                        workspace_key = CASE WHEN ? != '' THEN ? ELSE workspace_key END,
                        cwd = COALESCE(?, cwd),
                        model_name = CASE WHEN ? IS NOT NULL AND ? != '' AND ? != 'auto' THEN ? ELSE model_name END,
                        context_window = COALESCE(?, context_window),
                        physical_window = COALESCE(?, physical_window),
                        updated_at = ?
                    WHERE conversation_id = ?
                    """,
                    (
                        parent_conversation_id,
                        transcript_path,
                        full_path,
                        artifact_dir,
                        json.dumps(ws_list) if ws_list else None,
                        ws_key,
                        ws_key,
                        cwd,
                        model_name,
                        model_name,
                        model_name,
                        model_name,
                        context_window,
                        phys_win,
                        now,
                        conversation_id,
                    ),
                )
            else:
                # Auto-link parent_conversation_id from latest prior session in same workspace
                inferred_parent = parent_conversation_id
                if not inferred_parent and ws_key:
                    prev = conn.execute(
                        """
                        SELECT conversation_id FROM sessions
                        WHERE workspace_key = ? AND conversation_id != ?
                        ORDER BY updated_at DESC LIMIT 1
                        """,
                        (ws_key, conversation_id),
                    ).fetchone()
                    if prev:
                        inferred_parent = str(prev["conversation_id"])

                conn.execute(
                    """
                    INSERT INTO sessions (
                        conversation_id, parent_conversation_id, transcript_path, transcript_full_path,
                        artifact_dir, workspace_paths, workspace_key, cwd,
                        model_name, context_window, physical_window, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        conversation_id,
                        inferred_parent,
                        transcript_path,
                        full_path,
                        artifact_dir,
                        json.dumps(ws_list),
                        ws_key,
                        cwd,
                        model_name or "auto",
                        context_window or DEFAULT_ACP_SOFT_BUDGET,
                        phys_win or detect_physical_window(model_name),
                        now,
                    ),
                )
            row = conn.execute(
                "SELECT * FROM sessions WHERE conversation_id = ?",
                (conversation_id,),
            ).fetchone()
            return dict(row)

    def resolve_session(self, conversation_id: str | None = None) -> dict[str, Any] | None:
        if conversation_id in ("__empty__", "__none__", "__new__"):
            return None
        env_cid = os.environ.get("ANTIGRAVITY_CONVERSATION_ID")
        is_default_store = False
        try:
            is_default_store = self.data_dir.resolve() == default_data_dir().resolve()
        except Exception:
            is_default_store = False

        db_row: dict[str, Any] | None = None
        with self._connect() as conn:
            if conversation_id:
                row = conn.execute(
                    "SELECT * FROM sessions WHERE conversation_id = ?",
                    (conversation_id,),
                ).fetchone()
                if row:
                    return dict(row)
            else:
                if env_cid:
                    env_row = conn.execute(
                        "SELECT * FROM sessions WHERE conversation_id = ?",
                        (env_cid,),
                    ).fetchone()
                    if env_row:
                        return dict(env_row)
                row = conn.execute(
                    "SELECT * FROM sessions ORDER BY updated_at DESC LIMIT 1"
                ).fetchone()
                if row:
                    db_row = dict(row)

        if db_row and not is_default_store:
            return db_row

        target_cid = conversation_id or (env_cid if is_default_store else None)
        # Auto-discover newer conversation transcripts from Antigravity brain directory
        brain_dir = default_app_data_dir() / "brain"
        if brain_dir.exists() and (is_default_store or conversation_id):
            candidates: list[tuple[float, str, Path]] = []
            if target_cid:
                tpath = brain_dir / target_cid / ".system_generated" / "logs" / "transcript.jsonl"
                if tpath.exists():
                    candidates.append((tpath.stat().st_mtime, target_cid, tpath))
            elif is_default_store:
                for sub in brain_dir.iterdir():
                    if not sub.is_dir():
                        continue
                    tpath = sub / ".system_generated" / "logs" / "transcript.jsonl"
                    if tpath.exists():
                        candidates.append((tpath.stat().st_mtime, sub.name, tpath))
            if candidates:
                candidates.sort(key=lambda x: x[0], reverse=True)
                best_mtime, cid, tpath = candidates[0]
                if db_row and not target_cid:
                    db_ts = _parse_iso_ts(db_row.get("updated_at")) or 0.0
                    # Only switch away from DB latest if brain has a strictly newer different conversation
                    if cid == db_row.get("conversation_id") or best_mtime <= db_ts:
                        return db_row
                return self.register_session(
                    conversation_id=cid,
                    transcript_path=str(tpath),
                    artifact_dir=str(brain_dir / cid),
                )
        return db_row

    # ------------------------------------------------------------------
    # Transcript Parsing & Deterministic Metadata Harvesting
    # ------------------------------------------------------------------

    def read_transcript_steps(
        self,
        transcript_path: str | None,
        start_step: int | None = None,
        end_step: int | None = None,
        prefer_full: bool = True,
    ) -> list[dict[str, Any]]:
        if not transcript_path:
            return []
        target = resolve_full_transcript_path(transcript_path) if prefer_full else transcript_path
        if not target or not Path(target).exists():
            target = transcript_path
        if not target or not Path(target).exists():
            return []

        steps: list[dict[str, Any]] = []
        with open(target, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except json.JSONDecodeError:
                    continue
                idx = obj.get("step_index")
                if idx is None:
                    continue
                idx_int = int(idx)
                if start_step is not None and idx_int < start_step:
                    continue
                if end_step is not None and idx_int > end_step:
                    continue
                steps.append(obj)
        return steps

    def parse_transcript_stats(self, transcript_path: str | None) -> TranscriptStats:
        steps = self.read_transcript_steps(transcript_path, prefer_full=False)
        if not steps:
            return TranscriptStats(
                total_steps=0,
                min_step=0,
                max_step=0,
                last_input_tokens=0,
                last_cache_read_tokens=0,
                last_output_tokens=0,
                cumulative_tokens=0,
                model_name="auto",
            )

        min_step = min(int(s.get("step_index", 0)) for s in steps)
        max_step = max(int(s.get("step_index", 0)) for s in steps)
        last_in = 0
        last_cache = 0
        last_out = 0
        cumulative = 0
        model_name = "auto"
        approx_speed: float | None = None

        weights: dict[int, int] = {}
        types: dict[int, str] = {}
        summaries: dict[int, str] = {}
        step_tools: dict[int, list[str]] = {}
        user_turns: list[int] = []

        for i, s in enumerate(steps):
            idx = int(s.get("step_index", 0))
            stype = str(s.get("type") or "")
            types[idx] = stype
            if stype == "USER_INPUT":
                user_turns.append(idx)

            in_tok = int(s.get("input_tokens") or 0)
            cache_tok = int(s.get("cache_read_tokens") or 0)
            out_tok = int(s.get("output_tokens") or 0)
            if in_tok > 0 or cache_tok > 0:
                last_in = in_tok
                last_cache = cache_tok
                last_out = out_tok
                cumulative += in_tok + cache_tok + out_tok

            if s.get("model"):
                model_name = str(s["model"])

            # Estimate generation speed from consecutive timestamps when output_tokens >= 80
            if out_tok >= 80 and i + 1 < len(steps):
                t0 = _parse_iso_ts(s.get("created_at"))
                t1 = _parse_iso_ts(steps[i + 1].get("created_at"))
                if t0 is not None and t1 is not None:
                    dt = t1 - t0
                    if 0.8 <= dt <= 180.0:
                        cand_speed = round(out_tok / dt, 1)
                        if 2.0 <= cand_speed <= 500.0:
                            approx_speed = cand_speed

            parts: list[str] = []
            if s.get("content"):
                parts.append(str(s["content"]))
            if s.get("tool_calls"):
                parts.append(json.dumps(s["tool_calls"], ensure_ascii=False))
            if s.get("error"):
                parts.append(str(s["error"]))
            # Account for truncated_fields in compact transcript.jsonl
            trunc_bonus = 0
            if s.get("truncated_fields") and s.get("content"):
                m_tr = re.search(r"<truncated\s+(\d+)\s+bytes>", str(s["content"]))
                if m_tr:
                    trunc_bonus = max(0, int(int(m_tr.group(1)) / 3.8))
            weights[idx] = max(8, estimate_tokens("\n".join(parts)) + trunc_bonus)

            t_names: list[str] = []
            if s.get("tool_calls") and isinstance(s["tool_calls"], list):
                t_names = [str(tc.get("name") or "?") for tc in s["tool_calls"] if isinstance(tc, dict)]
            step_tools[idx] = t_names

            if stype == "USER_INPUT":
                snippet = _clean_user_request_preview(str(s.get("content") or ""))
            else:
                snippet = (str(s.get("content") or "")).strip().replace("\n", " ")[:120]
                if not snippet and t_names:
                    snippet = "tools: " + ", ".join(t_names)
            summaries[idx] = f"[{stype}] {snippet}".strip()

        return TranscriptStats(
            total_steps=len(steps),
            min_step=min_step,
            max_step=max_step,
            last_input_tokens=last_in,
            last_cache_read_tokens=last_cache,
            last_output_tokens=last_out,
            cumulative_tokens=cumulative,
            model_name=model_name,
            approx_tok_per_sec=approx_speed,
            step_weights=weights,
            step_types=types,
            step_summaries=summaries,
            step_tools=step_tools,
            user_turn_steps=user_turns,
        )

    @staticmethod
    def harvest_step_metadata(raw_steps: list[dict[str, Any]]) -> dict[str, list[str]]:
        """Deterministically extract file paths, commands, tools, errors, and skill/system boundaries.

        Mirrors billion-context's acp-kernel preservation guarantees so critical paths and
        skill/system boundaries are never lost even if the model omits them in prose.
        """
        entities: list[str] = []
        boundaries: list[str] = []
        errors: list[str] = []

        def _add_unique(target: list[str], val: str, cap: int = 40) -> None:
            v = val.strip().strip('"').strip("'")
            if v and v not in target and len(target) < cap:
                target.append(v)

        for s in raw_steps:
            content = str(s.get("content") or "")
            # Skill & system catalog boundary detection (billion-context dsh safeguard)
            if "<available_skills>" in content or "<skills>" in content or "SKILL.md" in content:
                _add_unique(boundaries, f"skill_reference@{format_step_ref(int(s.get('step_index', 0)))}")
            if "<acp-session" in content:
                _add_unique(boundaries, f"acp_session_header@{format_step_ref(int(s.get('step_index', 0)))}")

            if s.get("error"):
                _add_unique(errors, str(s["error"])[:160], cap=15)

            tcs = s.get("tool_calls")
            if isinstance(tcs, list):
                for tc in tcs:
                    if not isinstance(tc, dict):
                        continue
                    tname = str(tc.get("name") or "")
                    args = tc.get("args") or {}
                    if not isinstance(args, dict):
                        continue
                    for path_key in ("Path", "ScriptPath", "TargetFile", "DirectoryPath"):
                        if args.get(path_key):
                            raw_p = str(args[path_key]).strip('"').replace("\\\\", "\\")
                            _add_unique(entities, raw_p)
                    if tname == "run_command" and args.get("CommandLine"):
                        cmd_str = str(args["CommandLine"]).strip('"')
                        _add_unique(entities, f"cmd:{cmd_str[:80]}")
                    elif tname == "call_mcp_tool" and args.get("ToolName"):
                        _add_unique(entities, f"mcp:{args.get('ServerName', '')}/{args.get('ToolName')}")
                    elif tname == "invoke_subagent" and args.get("TypeName"):
                        _add_unique(entities, f"subagent:{args.get('TypeName')}")

        return {
            "entities": entities,
            "boundaries": boundaries,
            "errors": errors,
        }

    def sync_session_telemetry(self, conversation_id: str) -> dict[str, Any]:
        sess = self.resolve_session(conversation_id)
        if not sess:
            raise ValueError(f"Unknown conversation_id: {conversation_id}")

        stats = self.parse_transcript_stats(sess.get("transcript_path"))
        now = utc_now_iso()
        effective_model = stats.model_name if stats.model_name != "auto" else (sess.get("model_name") or "auto")
        phys_win = detect_physical_window(effective_model)
        cur_ctx_win = int(sess.get("context_window") or phys_win)
        has_env_soft = bool(os.environ.get("BILLION_CONTEXT_SOFT_BUDGET") or os.environ.get("BILLION_CONTEXT_WINDOW"))
        standard_windows = {128_000, 200_000, 256_000, 272_000, 512_000, 1_000_000}
        new_ctx_win = (
            phys_win
            if (not has_env_soft and (cur_ctx_win in standard_windows or cur_ctx_win > phys_win))
            else cur_ctx_win
        )

        with self._connect() as conn:
            conn.execute(
                """
                UPDATE sessions SET
                    last_input_tokens = ?,
                    last_cache_read_tokens = ?,
                    last_output_tokens = ?,
                    cumulative_tokens = ?,
                    approx_tok_per_sec = COALESCE(?, approx_tok_per_sec),
                    total_steps = ?,
                    model_name = CASE WHEN ? != 'auto' THEN ? ELSE model_name END,
                    context_window = ?,
                    physical_window = ?,
                    updated_at = ?
                WHERE conversation_id = ?
                """,
                (
                    stats.last_input_tokens,
                    stats.last_cache_read_tokens,
                    stats.last_output_tokens,
                    stats.cumulative_tokens,
                    stats.approx_tok_per_sec,
                    stats.total_steps,
                    stats.model_name,
                    stats.model_name,
                    new_ctx_win,
                    phys_win,
                    now,
                    conversation_id,
                ),
            )
            row = conn.execute(
                "SELECT * FROM sessions WHERE conversation_id = ?",
                (conversation_id,),
            ).fetchone()
            return dict(row)

    # ------------------------------------------------------------------
    # LSM Block Queries & Semantic Episode Range Computation
    # ------------------------------------------------------------------

    def _hydrate_block_row(self, r: sqlite3.Row) -> dict[str, Any]:
        d = dict(r)
        d["child_block_ids"] = safe_json_loads(d.get("child_block_ids"), [])
        d["entities"] = safe_json_loads(d.get("entities"), [])
        d["decisions"] = safe_json_loads(d.get("decisions"), [])
        d["open_questions"] = safe_json_loads(d.get("open_questions"), [])
        d["preserved_boundaries"] = safe_json_loads(d.get("preserved_boundaries"), [])
        if not d.get("range_ref"):
            d["range_ref"] = f"{format_step_ref(d['start_step'])}..{format_step_ref(d['end_step'])}"
        return d

    def get_active_blocks(self, conversation_id: str, include_workspace_milestones: bool = False) -> list[dict[str, Any]]:
        sess = self.resolve_session(conversation_id)
        ws_key = (sess.get("workspace_key") or "") if sess else ""
        with self._connect() as conn:
            if include_workspace_milestones and ws_key:
                rows = conn.execute(
                    """
                    SELECT * FROM blocks
                    WHERE archived = 0
                      AND (conversation_id = ? OR (workspace_key = ? AND tier >= 2))
                    ORDER BY CASE WHEN conversation_id = ? THEN 0 ELSE 1 END, tier DESC, start_step ASC
                    """,
                    (conversation_id, ws_key, conversation_id),
                ).fetchall()
            else:
                rows = conn.execute(
                    """
                    SELECT * FROM blocks
                    WHERE conversation_id = ? AND archived = 0
                    ORDER BY tier DESC, start_step ASC
                    """,
                    (conversation_id,),
                ).fetchall()
        return [self._hydrate_block_row(r) for r in rows]

    def get_workspace_ledger(self, workspace_key: str, fallback_cid: str) -> dict[str, Any]:
        with self._connect() as conn:
            if workspace_key:
                s_row = conn.execute(
                    """
                    SELECT COUNT(*) AS sessions_count,
                           COALESCE(SUM(cumulative_tokens), 0) AS total_cum_tokens
                    FROM sessions WHERE workspace_key = ?
                    """,
                    (workspace_key,),
                ).fetchone()
                b_row = conn.execute(
                    """
                    SELECT COUNT(*) AS active_blocks_count,
                           COALESCE(SUM(raw_token_estimate), 0) AS total_raw_folded
                    FROM blocks WHERE workspace_key = ? AND archived = 0
                    """,
                    (workspace_key,),
                ).fetchone()
            else:
                s_row = conn.execute(
                    """
                    SELECT 1 AS sessions_count,
                           COALESCE(cumulative_tokens, 0) AS total_cum_tokens
                    FROM sessions WHERE conversation_id = ?
                    """,
                    (fallback_cid,),
                ).fetchone()
                b_row = conn.execute(
                    """
                    SELECT COUNT(*) AS active_blocks_count,
                           COALESCE(SUM(raw_token_estimate), 0) AS total_raw_folded
                    FROM blocks WHERE conversation_id = ? AND archived = 0
                    """,
                    (fallback_cid,),
                ).fetchone()
        return {
            "workspace_sessions_count": int(s_row["sessions_count"] if s_row else 1),
            "workspace_cumulative_tokens": int(s_row["total_cum_tokens"] if s_row else 0),
            "workspace_active_blocks": int(b_row["active_blocks_count"] if b_row else 0),
            "workspace_raw_tokens_folded": int(b_row["total_raw_folded"] if b_row else 0),
        }

    def compute_unfolded_ranges(
        self,
        conversation_id: str,
        stats: TranscriptStats,
        protect_recent: int = DEFAULT_PROTECT_RECENT_STEPS,
    ) -> list[dict[str, Any]]:
        """Return contiguous unfolded [start_step..end_step] spans AND semantic episode slices."""
        if stats.total_steps == 0:
            return []

        with self._connect() as conn:
            t1_rows = conn.execute(
                "SELECT start_step, end_step FROM blocks WHERE conversation_id = ? AND tier = 1",
                (conversation_id,),
            ).fetchall()

        covered: set[int] = set()
        for r in t1_rows:
            for s in range(int(r["start_step"]), int(r["end_step"]) + 1):
                covered.add(s)

        eligible_max = max(-1, stats.max_step - max(0, protect_recent))
        all_indices = sorted(idx for idx in stats.step_weights if idx <= eligible_max)

        # First build contiguous uncovered spans
        raw_spans: list[list[int]] = []
        cur_span: list[int] = []
        for idx in all_indices:
            if idx in covered:
                if cur_span:
                    raw_spans.append(cur_span)
                    cur_span = []
            else:
                cur_span.append(idx)
        if cur_span:
            raw_spans.append(cur_span)

        # Split large uncovered spans along USER_INPUT boundaries or TARGET_EPISODE_TOKENS (~22K)
        # so the model gets clean episode-sized fold candidates rather than a 100K monolith.
        episodes: list[dict[str, Any]] = []
        user_turn_set = set(stats.user_turn_steps)

        for span in raw_spans:
            slice_steps: list[int] = []
            slice_tokens = 0
            for idx in span:
                w = stats.step_weights.get(idx, 0)
                is_turn_boundary = idx in user_turn_set and len(slice_steps) >= 4 and slice_tokens >= 6000
                is_size_boundary = slice_tokens + w > TARGET_EPISODE_TOKENS and len(slice_steps) >= 4
                if slice_steps and (is_turn_boundary or is_size_boundary):
                    episodes.append(self._describe_episode_slice(slice_steps, stats))
                    slice_steps = []
                    slice_tokens = 0
                slice_steps.append(idx)
                slice_tokens += w
            if slice_steps:
                episodes.append(self._describe_episode_slice(slice_steps, stats))

        return episodes

    @staticmethod
    def _describe_episode_slice(step_indices: list[int], stats: TranscriptStats) -> dict[str, Any]:
        s0 = step_indices[0]
        s1 = step_indices[-1]
        tok = sum(stats.step_weights.get(i, 0) for i in step_indices)
        previews: list[str] = []
        tool_counts: dict[str, int] = {}
        for i in step_indices:
            if stats.step_types.get(i) == "USER_INPUT":
                s_prev = stats.step_summaries.get(i, "")
                if s_prev:
                    previews.append(s_prev.replace("[USER_INPUT] ", "")[:90])
            for tn in stats.step_tools.get(i, []):
                tool_counts[tn] = tool_counts.get(tn, 0) + 1
        top_tools = [f"{k}x{v}" for k, v in sorted(tool_counts.items(), key=lambda kv: -kv[1])[:4]]
        return {
            "range_ref": f"{format_step_ref(s0)}..{format_step_ref(s1)}",
            "start_step": s0,
            "end_step": s1,
            "step_count": len(step_indices),
            "estimated_tokens": tok,
            "episode_preview": "; ".join(previews[:2]) if previews else (stats.step_summaries.get(s0, "")[:90]),
            "top_tools": top_tools,
        }

    # ------------------------------------------------------------------
    # Dual-Window Telemetry & Status (`acp_status`)
    # ------------------------------------------------------------------

    def get_status(self, conversation_id: str | None = None, detail: str = "compact") -> dict[str, Any]:
        sess = self.resolve_session(conversation_id)
        if not sess:
            return {
                "status": "NO_SESSION",
                "message": "No active Antigravity session registered yet.",
            }
        cid = sess["conversation_id"]
        sess = self.sync_session_telemetry(cid)
        stats = self.parse_transcript_stats(sess.get("transcript_path"))
        active_blocks = self.get_active_blocks(cid, include_workspace_milestones=False)
        unfolded = self.compute_unfolded_ranges(cid, stats)

        soft_budget = int(sess.get("context_window") or DEFAULT_ACP_SOFT_BUDGET)
        phys_window = int(sess.get("physical_window") or detect_physical_window(sess.get("model_name")))

        last_uncached = int(sess.get("last_input_tokens") or 0)
        last_cache = int(sess.get("last_cache_read_tokens") or 0)
        total_prompt_tokens = last_uncached + last_cache
        estimated_from_steps = sum(stats.step_weights.values())
        physical_tokens = total_prompt_tokens if total_prompt_tokens > 0 else estimated_from_steps

        tier_counts = {1: 0, 2: 0, 3: 0}
        total_raw_folded = 0
        total_summary_tokens = 0
        for b in active_blocks:
            t = int(b["tier"])
            tier_counts[t] = tier_counts.get(t, 0) + 1
            total_raw_folded += int(b["raw_token_estimate"] or 0)
            total_summary_tokens += int(b["summary_token_estimate"] or 0)

        unfolded_tokens = sum(int(r["estimated_tokens"]) for r in unfolded)
        protected_tail_start = max(stats.min_step, stats.max_step - DEFAULT_PROTECT_RECENT_STEPS + 1)
        tail_tokens = sum(
            w for idx, w in stats.step_weights.items() if idx >= protected_tail_start
        )

        # Dual-Window Logical Working Set Calculation:
        # Subtracts folded raw tokens and adds active block summary tokens, bounded below
        # by (unfolded + protected tail + summaries + base system prompt overhead).
        net_saved = max(0, total_raw_folded - total_summary_tokens)
        logical_from_prompt = max(0, physical_tokens - net_saved)
        logical_floor = unfolded_tokens + tail_tokens + total_summary_tokens
        logical_tokens = max(logical_floor, logical_from_prompt) if total_raw_folded > 0 else physical_tokens

        logical_pressure = round(logical_tokens / max(1, soft_budget), 4)
        physical_pressure = round(physical_tokens / max(1, phys_window), 4)
        cache_hit = round(last_cache / total_prompt_tokens, 4) if total_prompt_tokens > 0 else 0.0

        if logical_pressure >= PRESSURE_URGENT:
            level = "URGENT"
        elif logical_pressure >= PRESSURE_RECOMMEND:
            level = "RECOMMEND"
        elif logical_pressure >= PRESSURE_SOFT:
            level = "SOFT"
        else:
            level = "OK"

        ws_key = sess.get("workspace_key") or ""
        pins = self.list_pins(conversation_id=cid, workspace_key=ws_key)
        ws_ledger = self.get_workspace_ledger(ws_key, cid)

        t1_active = [b for b in active_blocks if b["tier"] == 1]
        t2_active = [b for b in active_blocks if b["tier"] == 2]
        compaction_hints: list[str] = []
        if unfolded and unfolded_tokens >= MIN_COMPRESSIBLE_TOKENS:
            r0 = unfolded[0]
            compaction_hints.append(
                f"[capture -> T1] Fold {r0['range_ref']} ({r0['step_count']} steps, ~{r0['estimated_tokens']} tok: {r0['episode_preview'][:60]})."
            )
        if len(t1_active) >= 4:
            ids = [b["block_id"] for b in t1_active[:4]]
            compaction_hints.append(f"[distill -> T2] Merge T1 blocks {ids} into a T2 Milestone block.")
        if len(t2_active) >= 4:
            ids = [b["block_id"] for b in t2_active[:4]]
            compaction_hints.append(f"[condense -> T3] Condense T2 blocks {ids} into a T3 Epoch block.")
        if physical_pressure >= PHYSICAL_COMPACT_RATIO:
            compaction_hints.append(
                f"[physical window {physical_pressure * 100:.1f}%] Call handoff_checkpoint(action='create') and run /compact or rotate session."
            )

        compression_ratio = (
            f"{(1.0 - total_summary_tokens / max(1, total_raw_folded)) * 100:.1f}%"
            if total_raw_folded > 0
            else "0.0%"
        )

        payload: dict[str, Any] = {
            "conversation_id": cid,
            "parent_conversation_id": sess.get("parent_conversation_id"),
            "model_name": sess.get("model_name"),
            "telemetry": {
                # Primary logical ACP working-set metrics (compatible with v1 keys + enriched)
                "active_input_tokens": logical_tokens,
                "logical_working_tokens": logical_tokens,
                "effective_budget_tokens": soft_budget,
                "window_label": format_window_label(soft_budget),
                "pressure_ratio": logical_pressure,
                "pressure_percent": f"{logical_pressure * 100:.1f}%",
                "pressure_level": level,
                # Physical Antigravity trajectory metrics
                "physical_prompt_tokens": physical_tokens,
                "physical_window_tokens": phys_window,
                "physical_window_label": format_window_label(phys_window),
                "physical_pressure_ratio": physical_pressure,
                "physical_pressure_percent": f"{physical_pressure * 100:.1f}%",
                "physical_compact_needed": physical_pressure >= PHYSICAL_COMPACT_RATIO,
                # Cache, speed, and billion-token cumulative counters
                "uncached_input_tokens": last_uncached,
                "cache_read_tokens": last_cache,
                "cache_hit_percent": f"{cache_hit * 100:.1f}%",
                "approx_tok_per_sec": sess.get("approx_tok_per_sec") or None,
                "cumulative_session_tokens": int(sess.get("cumulative_tokens") or 0),
                "workspace_cumulative_tokens": ws_ledger["workspace_cumulative_tokens"],
                "workspace_sessions_count": ws_ledger["workspace_sessions_count"],
                "total_steps": stats.total_steps,
                "step_range": f"{format_step_ref(stats.min_step)}..{format_step_ref(stats.max_step)}"
                if stats.total_steps
                else "empty",
            },
            "lsm_memory": {
                "active_blocks": len(active_blocks),
                "tier_counts": {
                    "T1": tier_counts.get(1, 0),
                    "T2": tier_counts.get(2, 0),
                    "T3": tier_counts.get(3, 0),
                },
                "raw_tokens_folded": total_raw_folded,
                "summary_tokens_used": total_summary_tokens,
                "net_tokens_saved": net_saved,
                "compression_ratio": compression_ratio,
                "unfolded_compressible_tokens": unfolded_tokens,
                "pins_count": len(pins),
            },
            "unfolded_compressible_ranges": unfolded,
            "hints": compaction_hints,
        }

        if detail == "full":
            payload["blocks"] = [
                {
                    "block_id": b["block_id"],
                    "tier": f"T{b['tier']}",
                    "operation": b.get("operation", "capture"),
                    "range_ref": b["range_ref"],
                    "steps": f"{b['start_step']}..{b['end_step']}",
                    "title": b["title"],
                    "summary": b["summary"],
                    "raw_tokens": b["raw_token_estimate"],
                    "summary_tokens": b["summary_token_estimate"],
                    "entities": b["entities"],
                    "decisions": b["decisions"],
                    "open_questions": b["open_questions"],
                    "preserved_boundaries": b["preserved_boundaries"],
                    "child_block_ids": b["child_block_ids"],
                }
                for b in active_blocks
            ]
            payload["pins"] = pins
            with self._connect() as conn:
                heavy = conn.execute(
                    """
                    SELECT step_index, tool_name, approx_tokens, summary
                    FROM tool_telemetry
                    WHERE conversation_id = ?
                    ORDER BY approx_tokens DESC
                    LIMIT 10
                    """,
                    (cid,),
                ).fetchall()
            payload["heavy_tool_steps"] = [dict(r) for r in heavy]
        else:
            payload["blocks_preview"] = [
                {
                    "block_id": b["block_id"],
                    "tier": f"T{b['tier']}",
                    "range_ref": b["range_ref"],
                    "steps": f"{b['start_step']}..{b['end_step']}",
                    "title": b["title"],
                    "raw_tokens": b["raw_token_estimate"],
                    "summary_tokens": b["summary_token_estimate"],
                }
                for b in active_blocks
            ]

        return payload

    # ------------------------------------------------------------------
    # LSM Pipeline: `capture` (T1), `distill` (T2), `condense` (T3)
    # ------------------------------------------------------------------

    def _next_id(self, conn: sqlite3.Connection, table: str, col: str, prefix: str) -> str:
        row = conn.execute(f"SELECT COUNT(*) AS c FROM {table}").fetchone()
        n = int(row["c"]) + 1
        while True:
            candidate = f"{prefix}{n:05d}"
            exists = conn.execute(f"SELECT 1 FROM {table} WHERE {col} = ?", (candidate,)).fetchone()
            if not exists:
                return candidate
            n += 1

    def compress_steps(
        self,
        conversation_id: str | None = None,
        start_step: int | None = None,
        end_step: int | None = None,
        range_ref: str | None = None,
        title: str = "",
        summary: str = "",
        entities: list[str] | None = None,
        decisions: list[str] | None = None,
        open_questions: list[str] | None = None,
        force: bool = False,
    ) -> dict[str, Any]:
        """Stage 1 (`capture`): Fold raw L0 steps into an immutable T1 Episode block."""
        sess = self.resolve_session(conversation_id)
        if not sess:
            raise ValueError("No active session found to compress.")
        cid = sess["conversation_id"]
        ws_key = sess.get("workspace_key") or ""

        s_start, s_end = parse_step_range_ref(range_ref, start_step, end_step)
        if s_start > s_end:
            raise ValueError(f"start_step ({s_start}) must be <= end_step ({s_end})")
        if not summary.strip():
            raise ValueError("summary cannot be empty")

        # acp-kernel recent-zone hard protection: prevent folding active live working tail
        if not force and sess.get("transcript_path"):
            all_steps = self.read_transcript_steps(sess.get("transcript_path"), prefer_full=False)
            if len(all_steps) > DEFAULT_PROTECT_RECENT_STEPS:
                live_max = max(int(s.get("step_index", 0)) for s in all_steps)
                safe_max = live_max - DEFAULT_PROTECT_RECENT_STEPS
                if s_end > safe_max:
                    raise ValueError(
                        f"Range end {format_step_ref(s_end)} intrudes into the protected recent working tail "
                        f"(last {DEFAULT_PROTECT_RECENT_STEPS} steps). Fold up to {format_step_ref(safe_max)} "
                        f"(e.g. {format_step_ref(s_start)}..{format_step_ref(safe_max)}) instead."
                    )

        raw_steps = self.read_transcript_steps(
            sess.get("transcript_path"),
            start_step=s_start,
            end_step=s_end,
            prefer_full=True,
        )
        raw_text = "\n".join(json.dumps(s, ensure_ascii=False) for s in raw_steps)
        raw_tokens = estimate_tokens(raw_text) if raw_steps else max(1, (s_end - s_start + 1) * 150)

        # Hybrid deterministic harvesting: auto-extract touched files, commands, and skill/protected tool boundaries
        harvested = self.harvest_step_metadata(raw_steps)
        ent_list: list[str] = []
        for e in (entities or []) + harvested["entities"]:
            es = str(e).strip()
            if es and es not in ent_list and len(ent_list) < 60:
                ent_list.append(es)

        dec_list = [str(d).strip() for d in (decisions or []) if str(d).strip()]
        oq_list = [str(q).strip() for q in (open_questions or []) if str(q).strip()]
        boundaries = list(harvested["boundaries"])
        for st in raw_steps:
            for tc in st.get("tool_calls") or []:
                tname = str(tc.get("name") or "")
                if tname in ("compress", "pin_context", "handoff_checkpoint"):
                    bref = f"protected_tool:{tname}@{format_step_ref(int(st.get('step_index', 0)))}"
                    if bref not in boundaries and len(boundaries) < 24:
                        boundaries.append(bref)

        canonical_ref = f"{format_step_ref(s_start)}..{format_step_ref(s_end)}"
        summary_tokens = estimate_tokens(summary)
        content_hash = hashlib.sha256(f"{cid}:{s_start}:{s_end}:{summary}".encode("utf-8")).hexdigest()[:16]
        now = utc_now_iso()
        clean_title = title.strip() or f"Episode {canonical_ref}"

        with self._connect() as conn:
            overlap = conn.execute(
                """
                SELECT block_id, start_step, end_step FROM blocks
                WHERE conversation_id = ? AND tier = 1
                  AND NOT (end_step < ? OR start_step > ?)
                """,
                (cid, s_start, s_end),
            ).fetchall()
            if overlap:
                conflicts = [f"{r['block_id']}({r['start_step']}..{r['end_step']})" for r in overlap]
                raise ValueError(
                    f"Step range {s_start}..{s_end} overlaps existing T1 block(s): {', '.join(conflicts)}"
                )

            block_id = self._next_id(conn, "blocks", "block_id", "b")
            conn.execute(
                """
                INSERT INTO blocks (
                    block_id, conversation_id, workspace_key, tier, operation,
                    start_step, end_step, range_ref, parent_block_id, child_block_ids,
                    title, summary, entities, decisions, open_questions, preserved_boundaries,
                    raw_token_estimate, summary_token_estimate, content_hash, created_at, archived
                ) VALUES (?, ?, ?, 1, 'capture', ?, ?, ?, NULL, '[]', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
                """,
                (
                    block_id,
                    cid,
                    ws_key,
                    s_start,
                    s_end,
                    canonical_ref,
                    clean_title,
                    summary.strip(),
                    json.dumps(ent_list, ensure_ascii=False),
                    json.dumps(dec_list, ensure_ascii=False),
                    json.dumps(oq_list, ensure_ascii=False),
                    json.dumps(boundaries, ensure_ascii=False),
                    raw_tokens,
                    summary_tokens,
                    content_hash,
                    now,
                ),
            )
            if self._fts_available:
                conn.execute(
                    "INSERT INTO blocks_fts (block_id, conversation_id, title, summary, entities, decisions) VALUES (?, ?, ?, ?, ?, ?)",
                    (
                        block_id,
                        cid,
                        clean_title,
                        summary.strip(),
                        " ".join(ent_list),
                        " ".join(dec_list),
                    ),
                )
            # Reset nudge tier after folding so next PreInvocation re-evaluates cleanly
            conn.execute(
                "UPDATE sessions SET last_nudge_tier = 'OK', urgent_nudge_counter = 0 WHERE conversation_id = ?",
                (cid,),
            )

        reduction = (1.0 - (summary_tokens / max(1, raw_tokens))) * 100.0
        return {
            "status": "COMPRESSED",
            "operation": "capture",
            "block_id": block_id,
            "tier": "T1",
            "conversation_id": cid,
            "range_ref": canonical_ref,
            "step_range": f"{s_start}..{s_end}",
            "steps_captured": len(raw_steps) if raw_steps else (s_end - s_start + 1),
            "auto_harvested_entities": len(harvested["entities"]),
            "preserved_boundaries": boundaries,
            "raw_tokens_estimate": raw_tokens,
            "summary_tokens_estimate": summary_tokens,
            "reduction_percent": f"{reduction:.1f}%",
        }

    def compress_blocks(
        self,
        conversation_id: str | None,
        block_ids: list[str],
        title: str,
        summary: str,
        entities: list[str] | None = None,
        decisions: list[str] | None = None,
        open_questions: list[str] | None = None,
        operation: str | None = None,
    ) -> dict[str, Any]:
        """Stage 2 (`distill`: T1->T2) & Stage 3 (`condense`: T2->T3) LSM block promotion."""
        sess = self.resolve_session(conversation_id)
        if not sess:
            raise ValueError("No active session found.")
        cid = sess["conversation_id"]
        ws_key = sess.get("workspace_key") or ""

        if len(block_ids) < 2:
            raise ValueError("Provide at least 2 block_ids to merge into a higher tier.")
        if not summary.strip():
            raise ValueError("summary cannot be empty")

        now = utc_now_iso()
        with self._connect() as conn:
            placeholders = ",".join("?" for _ in block_ids)
            # Allow merging blocks within same session or same workspace lineage
            if ws_key:
                rows = conn.execute(
                    f"""
                    SELECT * FROM blocks
                    WHERE block_id IN ({placeholders})
                      AND (conversation_id = ? OR workspace_key = ?)
                    """,
                    [*block_ids, cid, ws_key],
                ).fetchall()
            else:
                rows = conn.execute(
                    f"SELECT * FROM blocks WHERE conversation_id = ? AND block_id IN ({placeholders})",
                    [cid, *block_ids],
                ).fetchall()

            if len(rows) != len(block_ids):
                found = {r["block_id"] for r in rows}
                missing = [bid for bid in block_ids if bid not in found]
                raise ValueError(f"Unknown block_id(s): {missing}")

            for r in rows:
                if r["archived"]:
                    raise ValueError(f"Block {r['block_id']} is already archived under {r['parent_block_id']}")

            max_tier = max(int(r["tier"]) for r in rows)
            if operation == "condense":
                new_tier = 3
            elif operation == "distill":
                new_tier = max(2, min(3, max_tier + 1))
            else:
                new_tier = min(3, max_tier + 1)
            op_name = "condense" if new_tier >= 3 else "distill"

            start_step = min(int(r["start_step"]) for r in rows)
            end_step = max(int(r["end_step"]) for r in rows)
            canonical_ref = f"{format_step_ref(start_step)}..{format_step_ref(end_step)}"
            raw_tokens = sum(int(r["raw_token_estimate"] or 0) for r in rows)
            prev_summary_tokens = sum(int(r["summary_token_estimate"] or 0) for r in rows)
            summary_tokens = estimate_tokens(summary)

            merged_ent = [str(e).strip() for e in (entities or []) if str(e).strip()]
            merged_dec = [str(d).strip() for d in (decisions or []) if str(d).strip()]
            merged_oq = [str(q).strip() for q in (open_questions or []) if str(q).strip()]
            merged_bounds: list[str] = []
            for r in rows:
                for e in safe_json_loads(r["entities"], []):
                    if e not in merged_ent and len(merged_ent) < 80:
                        merged_ent.append(e)
                for d in safe_json_loads(r["decisions"], []):
                    if d not in merged_dec:
                        merged_dec.append(d)
                for bnd in safe_json_loads(r["preserved_boundaries"], []):
                    if bnd not in merged_bounds:
                        merged_bounds.append(bnd)

            new_id = self._next_id(conn, "blocks", "block_id", "b")
            clean_title = title.strip() or f"T{new_tier} {'Epoch' if new_tier == 3 else 'Milestone'} {canonical_ref}"
            content_hash = hashlib.sha256(
                f"{cid}:{new_tier}:{start_step}:{end_step}:{summary}".encode("utf-8")
            ).hexdigest()[:16]

            conn.execute(
                """
                INSERT INTO blocks (
                    block_id, conversation_id, workspace_key, tier, operation,
                    start_step, end_step, range_ref, parent_block_id, child_block_ids,
                    title, summary, entities, decisions, open_questions, preserved_boundaries,
                    raw_token_estimate, summary_token_estimate, content_hash, created_at, archived
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
                """,
                (
                    new_id,
                    cid,
                    ws_key,
                    new_tier,
                    op_name,
                    start_step,
                    end_step,
                    canonical_ref,
                    json.dumps(block_ids),
                    clean_title,
                    summary.strip(),
                    json.dumps(merged_ent, ensure_ascii=False),
                    json.dumps(merged_dec, ensure_ascii=False),
                    json.dumps(merged_oq, ensure_ascii=False),
                    json.dumps(merged_bounds, ensure_ascii=False),
                    raw_tokens,
                    summary_tokens,
                    content_hash,
                    now,
                ),
            )
            conn.execute(
                f"UPDATE blocks SET archived = 1, parent_block_id = ? WHERE block_id IN ({placeholders})",
                [new_id, *block_ids],
            )
            if self._fts_available:
                conn.execute(
                    "INSERT INTO blocks_fts (block_id, conversation_id, title, summary, entities, decisions) VALUES (?, ?, ?, ?, ?, ?)",
                    (
                        new_id,
                        cid,
                        clean_title,
                        summary.strip(),
                        " ".join(merged_ent),
                        " ".join(merged_dec),
                    ),
                )

        return {
            "status": "MERGED",
            "operation": op_name,
            "block_id": new_id,
            "tier": f"T{new_tier}",
            "child_block_ids": block_ids,
            "range_ref": canonical_ref,
            "step_range": f"{start_step}..{end_step}",
            "previous_summary_tokens": prev_summary_tokens,
            "new_summary_tokens": summary_tokens,
            "cumulative_raw_tokens_covered": raw_tokens,
        }

    # ------------------------------------------------------------------
    # Cross-Session Reversible Decompression (`decompress`)
    # ------------------------------------------------------------------

    def decompress(
        self,
        conversation_id: str | None = None,
        block_id: str | None = None,
        range_ref: str | None = None,
        start_step: int | None = None,
        end_step: int | None = None,
        depth: str = "raw",
        offset_step: int | None = None,
        include_thinking: bool = False,
        max_chars: int = 16000,
    ) -> dict[str, Any]:
        """Restore child block summaries (`depth='children'`) or verbatim transcript steps (`depth='raw'`).

        Supports cross-conversation decompression: if `block_id` was created in an earlier
        session in the same workspace, `decompress` automatically resolves that block's
        originating `transcript_full.jsonl` on disk.
        """
        sess = self.resolve_session(conversation_id)
        block_meta: dict[str, Any] | None = None
        child_blocks: list[dict[str, Any]] = []
        target_transcript_path = sess.get("transcript_path") if sess else None
        owning_cid = sess["conversation_id"] if sess else (conversation_id or "")

        if block_id:
            with self._connect() as conn:
                row = conn.execute(
                    "SELECT * FROM blocks WHERE block_id = ?",
                    (block_id.strip(),),
                ).fetchone()
                if not row:
                    raise ValueError(f"Block '{block_id}' not found in ACP store.")
                block_meta = self._hydrate_block_row(row)
                owning_cid = str(block_meta["conversation_id"])
                start_step = int(block_meta["start_step"])
                end_step = int(block_meta["end_step"])

                owner_sess = conn.execute(
                    "SELECT transcript_path FROM sessions WHERE conversation_id = ?",
                    (owning_cid,),
                ).fetchone()
                if owner_sess and owner_sess["transcript_path"]:
                    target_transcript_path = str(owner_sess["transcript_path"])
                else:
                    cand = default_app_data_dir() / "brain" / owning_cid / ".system_generated" / "logs" / "transcript.jsonl"
                    if cand.exists():
                        target_transcript_path = str(cand)

                if block_meta["child_block_ids"]:
                    ph = ",".join("?" for _ in block_meta["child_block_ids"])
                    crows = conn.execute(
                        f"""
                        SELECT block_id, conversation_id, tier, start_step, end_step, range_ref, title, summary, entities, decisions
                        FROM blocks WHERE block_id IN ({ph}) ORDER BY start_step
                        """,
                        block_meta["child_block_ids"],
                    ).fetchall()
                    for cr in crows:
                        cd = dict(cr)
                        cd["entities"] = safe_json_loads(cd.get("entities"), [])
                        cd["decisions"] = safe_json_loads(cd.get("decisions"), [])
                        child_blocks.append(cd)
        else:
            if not sess:
                raise ValueError("No active session found.")
            start_step, end_step = parse_step_range_ref(range_ref, start_step, end_step)

        assert start_step is not None and end_step is not None
        effective_start = max(start_step, int(offset_step)) if offset_step is not None else start_step

        # If depth == 'children' on a T2/T3 block, return child summaries without raw transcript flood
        if depth == "children" and block_meta and child_blocks:
            return {
                "conversation_id": owning_cid,
                "depth": "children",
                "block": {
                    "block_id": block_meta["block_id"],
                    "tier": f"T{block_meta['tier']}",
                    "title": block_meta["title"],
                    "summary": block_meta["summary"],
                    "child_blocks": child_blocks,
                },
                "step_range": f"{start_step}..{end_step}",
                "steps_returned": 0,
                "truncated": False,
                "transcript_excerpt": "\n\n".join(
                    f"=== [{c['block_id']} | T{c['tier']} | steps {c['start_step']}..{c['end_step']}] {c['title']} ===\n{c['summary']}"
                    for c in child_blocks
                ),
            }

        steps = self.read_transcript_steps(
            target_transcript_path,
            start_step=effective_start,
            end_step=end_step,
            prefer_full=True,
        )

        rendered: list[str] = []
        total_chars = 0
        truncated = False
        next_offset_step: int | None = None

        for s in steps:
            idx = int(s.get("step_index", 0))
            stype = s.get("type", "")
            src = s.get("source", "")
            lines = [f"--- {format_step_ref(idx)} / step {idx} ({stype} / {src}) ---"]
            if include_thinking and s.get("thinking"):
                lines.append(f"[thinking] {s['thinking']}")
            if s.get("content"):
                lines.append(str(s["content"]))
            if s.get("tool_calls"):
                lines.append("[tool_calls] " + json.dumps(s["tool_calls"], ensure_ascii=False))
            if s.get("error"):
                lines.append(f"[error] {s['error']}")
            chunk = "\n".join(lines)
            if total_chars + len(chunk) > max_chars:
                remaining = max(0, max_chars - total_chars)
                if remaining > 80:
                    rendered.append(chunk[:remaining] + "\n... [TRUNCATED by max_chars]")
                truncated = True
                next_offset_step = idx
                break
            rendered.append(chunk)
            total_chars += len(chunk)

        return {
            "conversation_id": owning_cid,
            "depth": "raw",
            "block": {
                "block_id": block_meta["block_id"],
                "tier": f"T{block_meta['tier']}",
                "title": block_meta["title"],
                "summary": block_meta["summary"],
                "child_blocks": child_blocks,
            }
            if block_meta
            else None,
            "range_ref": f"{format_step_ref(effective_start)}..{format_step_ref(end_step)}",
            "step_range": f"{effective_start}..{end_step}",
            "steps_returned": len(rendered),
            "truncated": truncated,
            "next_offset_step": next_offset_step,
            "transcript_excerpt": "\n\n".join(rendered),
        }

    # ------------------------------------------------------------------
    # Cross-Session Search (`search_context`)
    # ------------------------------------------------------------------

    def search_context(
        self,
        query: str,
        conversation_id: str | None = None,
        scope: str = "all",
        workspace_wide: bool = True,
        limit: int = 10,
    ) -> dict[str, Any]:
        sess = self.resolve_session(conversation_id)
        if not sess:
            raise ValueError("No active session found.")
        cid = sess["conversation_id"]
        ws_key = sess.get("workspace_key") or ""
        q = query.strip()
        if not q:
            raise ValueError("query cannot be empty")
        limit = max(1, min(50, int(limit)))

        results: dict[str, Any] = {
            "conversation_id": cid,
            "workspace_wide": workspace_wide,
            "query": q,
            "hits": [],
        }
        hits: list[dict[str, Any]] = []

        # 1. Search pins
        if scope in ("all", "pins"):
            pins = self.list_pins(conversation_id=cid, workspace_key=ws_key)
            q_lower = q.lower()
            for p in pins:
                hay = f"{p['title']} {p['content']} {p['category']}".lower()
                if q_lower in hay or all(tok in hay for tok in q_lower.split()):
                    hits.append(
                        {
                            "source": "pin",
                            "ref": p["pin_id"],
                            "conversation_id": cid,
                            "category": p["category"],
                            "title": p["title"],
                            "snippet": p["content"][:400],
                            "score": 100,
                        }
                    )

        # 2. Search LSM blocks (across workspace lineage when workspace_wide=True)
        if scope in ("all", "blocks"):
            with self._connect() as conn:
                block_rows: list[sqlite3.Row] = []
                if self._fts_available:
                    fts_q = _fts5_safe_query(q)
                    if fts_q:
                        try:
                            if workspace_wide and ws_key:
                                block_rows = conn.execute(
                                    """
                                    SELECT b.* FROM blocks_fts f
                                    JOIN blocks b ON f.block_id = b.block_id
                                    WHERE (b.conversation_id = ? OR b.workspace_key = ?)
                                      AND blocks_fts MATCH ?
                                    ORDER BY bm25(blocks_fts)
                                    LIMIT ?
                                    """,
                                    (cid, ws_key, fts_q, limit * 2),
                                ).fetchall()
                            else:
                                block_rows = conn.execute(
                                    """
                                    SELECT b.* FROM blocks_fts f
                                    JOIN blocks b ON f.block_id = b.block_id
                                    WHERE f.conversation_id = ? AND blocks_fts MATCH ?
                                    ORDER BY bm25(blocks_fts)
                                    LIMIT ?
                                    """,
                                    (cid, fts_q, limit * 2),
                                ).fetchall()
                        except sqlite3.OperationalError:
                            block_rows = []
                if not block_rows:
                    like = f"%{q}%"
                    if workspace_wide and ws_key:
                        block_rows = conn.execute(
                            """
                            SELECT * FROM blocks
                            WHERE (conversation_id = ? OR workspace_key = ?)
                              AND (title LIKE ? OR summary LIKE ? OR entities LIKE ? OR decisions LIKE ?)
                            ORDER BY archived ASC, tier DESC, created_at DESC
                            LIMIT ?
                            """,
                            (cid, ws_key, like, like, like, like, limit * 2),
                        ).fetchall()
                    else:
                        block_rows = conn.execute(
                            """
                            SELECT * FROM blocks
                            WHERE conversation_id = ?
                              AND (title LIKE ? OR summary LIKE ? OR entities LIKE ? OR decisions LIKE ?)
                            ORDER BY archived ASC, tier DESC, start_step DESC
                            LIMIT ?
                            """,
                            (cid, like, like, like, like, limit * 2),
                        ).fetchall()

                for r in block_rows:
                    same_conv = str(r["conversation_id"]) == cid
                    base_score = 85 if not r["archived"] else 65
                    if not same_conv:
                        base_score -= 5
                    hits.append(
                        {
                            "source": f"block_T{r['tier']}",
                            "ref": r["block_id"],
                            "conversation_id": r["conversation_id"],
                            "range_ref": r["range_ref"] or f"{format_step_ref(r['start_step'])}..{format_step_ref(r['end_step'])}",
                            "step_range": f"{r['start_step']}..{r['end_step']}",
                            "archived": bool(r["archived"]),
                            "title": r["title"],
                            "snippet": r["summary"][:500],
                            "score": base_score,
                        }
                    )

        # 3. Search raw transcripts (current session + recent workspace sessions if workspace_wide)
        if scope in ("all", "transcript"):
            try:
                pat = re.compile(q, re.IGNORECASE)
            except re.error:
                pat = re.compile(re.escape(q), re.IGNORECASE)

            tx_targets: list[tuple[str, str | None]] = [(cid, sess.get("transcript_path"))]
            if workspace_wide and ws_key:
                with self._connect() as conn:
                    prior_rows = conn.execute(
                        """
                        SELECT conversation_id, transcript_path FROM sessions
                        WHERE workspace_key = ? AND conversation_id != ?
                        ORDER BY updated_at DESC LIMIT 3
                        """,
                        (ws_key, cid),
                    ).fetchall()
                for pr in prior_rows:
                    tx_targets.append((str(pr["conversation_id"]), pr["transcript_path"]))

            tx_hits: list[dict[str, Any]] = []
            for t_cid, t_path in tx_targets:
                steps = self.read_transcript_steps(t_path, prefer_full=True)
                local_hits: list[dict[str, Any]] = []
                for s in steps:
                    text_parts = [
                        str(s.get("content") or ""),
                        json.dumps(s.get("tool_calls") or [], ensure_ascii=False),
                        str(s.get("error") or ""),
                    ]
                    joined = "\n".join(text_parts)
                    m = pat.search(joined)
                    if m:
                        start = max(0, m.start() - 140)
                        end = min(len(joined), m.end() + 260)
                        idx = int(s.get("step_index", 0))
                        local_hits.append(
                            {
                                "source": "transcript",
                                "ref": format_step_ref(idx),
                                "conversation_id": t_cid,
                                "step_index": idx,
                                "step_type": s.get("type"),
                                "snippet": joined[start:end].replace("\n", " "),
                                "score": 45 if t_cid == cid else 35,
                            }
                        )
                local_hits.reverse()
                tx_hits.extend(local_hits[:limit])
            hits.extend(tx_hits[:limit])

        hits.sort(key=lambda h: h.get("score", 0), reverse=True)
        results["total_hits"] = len(hits)
        results["hits"] = hits[:limit]
        return results

    # ------------------------------------------------------------------
    # Pins (Protected Invariants with Deduplicating Upsert)
    # ------------------------------------------------------------------

    def pin(
        self,
        title: str,
        content: str,
        conversation_id: str | None = None,
        scope: str = "conversation",
        category: str = "invariant",
        step_ref: int | None = None,
    ) -> dict[str, Any]:
        sess = self.resolve_session(conversation_id)
        if scope == "workspace":
            if sess and sess.get("workspace_key"):
                scope_id = sess["workspace_key"]
            else:
                scope_id = normalize_workspace_key(None, os.getcwd())
        else:
            if not sess:
                raise ValueError("No active session found for conversation-scoped pin.")
            scope_id = sess["conversation_id"]

        clean_title = title.strip()
        clean_content = content.strip()
        now = utc_now_iso()

        with self._connect() as conn:
            existing = conn.execute(
                """
                SELECT pin_id FROM pins
                WHERE active = 1 AND scope = ? AND scope_id = ? AND LOWER(title) = LOWER(?)
                LIMIT 1
                """,
                (scope, scope_id, clean_title),
            ).fetchone()
            if existing:
                pin_id = str(existing["pin_id"])
                conn.execute(
                    """
                    UPDATE pins
                    SET category = ?, content = ?, step_ref = COALESCE(?, step_ref), updated_at = ?
                    WHERE pin_id = ?
                    """,
                    (category, clean_content, step_ref, now, pin_id),
                )
                status_label = "UPDATED"
            else:
                pin_id = self._next_id(conn, "pins", "pin_id", "p")
                conn.execute(
                    """
                    INSERT INTO pins (pin_id, scope, scope_id, category, title, content, step_ref, created_at, updated_at, active)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
                    """,
                    (pin_id, scope, scope_id, category, clean_title, clean_content, step_ref, now, now),
                )
                status_label = "PINNED"

        return {
            "status": status_label,
            "pin_id": pin_id,
            "scope": scope,
            "scope_id": scope_id,
            "category": category,
            "title": clean_title,
        }

    def unpin(self, pin_id: str) -> dict[str, Any]:
        with self._connect() as conn:
            cur = conn.execute("UPDATE pins SET active = 0, updated_at = ? WHERE pin_id = ?", (utc_now_iso(), pin_id))
            if cur.rowcount == 0:
                raise ValueError(f"Pin {pin_id} not found.")
        return {"status": "UNPINNED", "pin_id": pin_id}

    def list_pins(
        self,
        conversation_id: str | None = None,
        workspace_key: str | None = None,
    ) -> list[dict[str, Any]]:
        if not workspace_key and conversation_id:
            sess = self.resolve_session(conversation_id)
            if sess:
                workspace_key = sess.get("workspace_key") or ""
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT * FROM pins
                WHERE active = 1
                   AND (
                     (scope = 'conversation' AND scope_id = ?)
                     OR (scope = 'workspace' AND scope_id = ? AND ? != '')
                   )
                ORDER BY created_at ASC
                """,
                (conversation_id or "", workspace_key or "", workspace_key or ""),
            ).fetchall()
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Tool Telemetry & Lossless Continuation Checkpoints
    # ------------------------------------------------------------------

    def record_tool_telemetry(
        self,
        conversation_id: str,
        step_index: int | None,
        tool_name: str,
        approx_tokens: int,
        summary: str = "",
    ) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO tool_telemetry (conversation_id, step_index, tool_name, approx_tokens, summary, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (conversation_id, step_index, tool_name, approx_tokens, summary[:300], utc_now_iso()),
            )

    def create_checkpoint(
        self,
        conversation_id: str | None = None,
        current_goal: str = "",
        next_steps: list[str] | None = None,
        reason: str = "manual",
        write_artifact: bool = True,
    ) -> dict[str, Any]:
        sess = self.resolve_session(conversation_id)
        if not sess:
            raise ValueError("No active session found.")
        cid = sess["conversation_id"]
        ws_key = sess.get("workspace_key") or ""
        status = self.get_status(cid, detail="full")
        pins = status.get("pins", [])
        blocks = self.get_active_blocks(cid, include_workspace_milestones=True)
        stats = self.parse_transcript_stats(sess.get("transcript_path"))
        tel = status["telemetry"]

        lines: list[str] = [
            "# Billion-Context ACP Continuation Checkpoint",
            f"- **Conversation ID**: `{cid}`",
            f"- **Parent Conversation**: `{sess.get('parent_conversation_id') or 'root'}`",
            f"- **Created At**: `{utc_now_iso()}`",
            f"- **Reason**: `{reason}`",
            f"- **Workspace Cumulative Tokens**: {tel['workspace_cumulative_tokens']:,} ({tel['workspace_sessions_count']} session(s))",
            f"- **Logical ACP Working Set**: {tel['logical_working_tokens']:,} / {tel['effective_budget_tokens']:,} ({tel['pressure_percent']})",
            f"- **Physical Trajectory Window**: {tel['physical_prompt_tokens']:,} / {tel['physical_window_tokens']:,} ({tel['physical_pressure_percent']})",
            f"- **Steps Covered**: `{tel['step_range']}` ({tel['total_steps']} steps)",
            "",
        ]
        if current_goal:
            lines.extend(["## Current Goal", current_goal.strip(), ""])
        if next_steps:
            lines.append("## Next Steps")
            for idx, ns in enumerate(next_steps, 1):
                lines.append(f"{idx}. {ns}")
            lines.append("")

        lines.append("## Pinned Invariants & Decisions")
        if pins:
            for p in pins:
                lines.append(f"- **[{p['pin_id']} | {p['scope']}:{p['category']}] {p['title']}**: {p['content']}")
        else:
            lines.append("- *(none)*")
        lines.append("")

        lines.append("## Hierarchical Memory Blocks (LSM Tree: T3 -> T2 -> T1)")
        if blocks:
            for b in blocks:
                owner_note = "" if b["conversation_id"] == cid else f" | from `{b['conversation_id'][:8]}`"
                lines.append(
                    f"### [{b['block_id']} | T{b['tier']} | {b['range_ref']}{owner_note}] {b['title']}"
                )
                lines.append(b["summary"])
                if b["decisions"]:
                    lines.append("- **Decisions**: " + "; ".join(b["decisions"]))
                if b["entities"]:
                    lines.append("- **Entities/Files**: " + ", ".join(b["entities"][:20]))
                if b["open_questions"]:
                    lines.append("- **Open Questions**: " + "; ".join(b["open_questions"]))
                lines.append("")
        else:
            lines.append("- *(no compressed blocks yet — fold completed episodes with `compress`)*\n")

        unfolded = status.get("unfolded_compressible_ranges", [])
        lines.append("## Protected Recent Tail (L0)")
        recent_start = max(stats.min_step, stats.max_step - DEFAULT_PROTECT_RECENT_STEPS)
        for s_idx in range(recent_start, stats.max_step + 1):
            if s_idx in stats.step_summaries:
                lines.append(f"- `{format_step_ref(s_idx)}`: {stats.step_summaries[s_idx]}")
        if unfolded:
            ep_refs = [f"{r['range_ref']} (~{r['estimated_tokens']} tok)" for r in unfolded[:4]]
            lines.append(f"- **Unfolded episode ranges**: {', '.join(ep_refs)}")
        lines.append("")
        lines.append(
            "> Use `search_context(query=..., workspace_wide=True)` or `decompress(block_id=...)` "
            "to recover any exact verbatim historical details across this workspace."
        )

        packet = "\n".join(lines)
        now = utc_now_iso()
        with self._connect() as conn:
            cp_id = self._next_id(conn, "checkpoints", "checkpoint_id", "cp")
            conn.execute(
                """
                INSERT INTO checkpoints (
                    checkpoint_id, conversation_id, workspace_key, reason,
                    current_goal, next_steps, packet_markdown, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    cp_id,
                    cid,
                    ws_key,
                    reason,
                    current_goal.strip(),
                    json.dumps(next_steps or [], ensure_ascii=False),
                    packet,
                    now,
                ),
            )

        artifact_path: str | None = None
        if write_artifact:
            target_dir = Path(sess["artifact_dir"]) if sess.get("artifact_dir") else self.data_dir
            target_dir.mkdir(parents=True, exist_ok=True)
            out_file = target_dir / "acp_handoff.md"
            out_file.write_text(packet, encoding="utf-8")
            artifact_path = str(out_file)

        return {
            "status": "CHECKPOINT_CREATED",
            "checkpoint_id": cp_id,
            "conversation_id": cid,
            "artifact_path": artifact_path,
            "packet_tokens_estimate": estimate_tokens(packet),
            "packet_markdown": packet,
        }

    def get_latest_checkpoint(
        self,
        conversation_id: str | None = None,
        workspace_key: str | None = None,
    ) -> dict[str, Any] | None:
        with self._connect() as conn:
            if conversation_id:
                row = conn.execute(
                    "SELECT * FROM checkpoints WHERE conversation_id = ? ORDER BY created_at DESC LIMIT 1",
                    (conversation_id,),
                ).fetchone()
                if row:
                    return dict(row)
            if workspace_key:
                row = conn.execute(
                    "SELECT * FROM checkpoints WHERE workspace_key = ? ORDER BY created_at DESC LIMIT 1",
                    (workspace_key,),
                ).fetchone()
                if row:
                    return dict(row)
            row = conn.execute(
                "SELECT * FROM checkpoints ORDER BY created_at DESC LIMIT 1"
            ).fetchone()
            return dict(row) if row else None

    def list_checkpoints(self, workspace_key: str | None = None, limit: int = 10) -> list[dict[str, Any]]:
        with self._connect() as conn:
            if workspace_key:
                rows = conn.execute(
                    """
                    SELECT checkpoint_id, conversation_id, workspace_key, reason, current_goal, created_at
                    FROM checkpoints WHERE workspace_key = ?
                    ORDER BY created_at DESC LIMIT ?
                    """,
                    (workspace_key, limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    """
                    SELECT checkpoint_id, conversation_id, workspace_key, reason, current_goal, created_at
                    FROM checkpoints ORDER BY created_at DESC LIMIT ?
                    """,
                    (limit,),
                ).fetchall()
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Cache-Preserving Nudge State Machine for `PreInvocation`
    # ------------------------------------------------------------------

    def check_and_update_nudge(
        self,
        conversation_id: str,
        level: str,
        unfolded_tokens: int = 999999,
        physical_compact_needed: bool = False,
    ) -> tuple[bool, int]:
        """Decide whether PreInvocation should inject a system message.

        Prefix-cache preservation rules:
          1. If `level == 'OK'` and not `physical_compact_needed`: return (False, 0) -> 0 bytes injected.
          2. If `unfolded_tokens < MIN_COMPRESSIBLE_TOKENS` and not `physical_compact_needed`:
             older steps are already folded! Return (False, 0) so we NEVER nag in a loop.
          3. Otherwise inject only on upward tier transitions (`OK -> SOFT -> RECOMMEND -> URGENT`),
             or once when `physical_compact_needed` first triggers, or every 5 turns in URGENT.
        """
        tier_rank = {"OK": 0, "SOFT": 1, "RECOMMEND": 2, "URGENT": 3}
        with self._connect() as conn:
            row = conn.execute(
                "SELECT last_nudge_tier, urgent_nudge_counter, physical_nudge_sent FROM sessions WHERE conversation_id = ?",
                (conversation_id,),
            ).fetchone()
            prev_tier = (row["last_nudge_tier"] if row else "OK") or "OK"
            urgent_cnt = int(row["urgent_nudge_counter"] if row else 0)
            phys_sent = int(row["physical_nudge_sent"] if row else 0)

            has_foldable_work = unfolded_tokens >= MIN_COMPRESSIBLE_TOKENS
            effective_level = level if has_foldable_work else "OK"

            should_nudge = False
            new_cnt = urgent_cnt
            new_phys = phys_sent

            if physical_compact_needed and not phys_sent:
                should_nudge = True
                new_phys = 1
            elif not physical_compact_needed:
                new_phys = 0

            if effective_level == "OK":
                new_cnt = 0
            elif tier_rank.get(effective_level, 0) > tier_rank.get(prev_tier, 0):
                should_nudge = True
                new_cnt = 0 if effective_level != "URGENT" else 1
            elif effective_level == "URGENT":
                new_cnt = urgent_cnt + 1
                if new_cnt % 5 == 0:
                    should_nudge = True

            conn.execute(
                """
                UPDATE sessions
                SET last_nudge_tier = ?, urgent_nudge_counter = ?, physical_nudge_sent = ?
                WHERE conversation_id = ?
                """,
                (effective_level, new_cnt, new_phys, conversation_id),
            )
            return should_nudge, new_cnt

    # ------------------------------------------------------------------
    # Inline / Side-Pane / Desktop Widget Estimator Snapshot
    # ------------------------------------------------------------------

    @staticmethod
    def _format_compact_tokens(n: int) -> str:
        if n >= 1_000_000_000:
            return f"{n / 1_000_000_000:.2f}B"
        if n >= 1_000_000:
            return f"{n / 1_000_000:.2f}M"
        if n >= 1_000:
            val = n / 1_000
            return f"{int(val)}K" if val.is_integer() and n >= 10_000 else f"{val:.1f}K"
        return str(n)

    def get_guard(self) -> Any:
        if not hasattr(self, "_guard_engine") or self._guard_engine is None:
            from core.guard_engine import GuardEngine

            self._guard_engine = GuardEngine(self)
        return self._guard_engine

    def get_estimator_snapshot(self, conversation_id: str | None = None) -> dict[str, Any]:
        guard = self.get_guard()
        settings = guard.get_settings()
        status = self.get_status(conversation_id=conversation_id, detail="full")
        if status.get("status") == "NO_SESSION":
            return {
                "conversation_id": None,
                "is_empty_session": True,
                "estimator": {
                    "usage_display": "新会话待开始",
                    "physical_usage_display": "—",
                    "window_label": "—",
                    "physical_window_label": "—",
                    "sample_model_display": "新会话",
                    "endpoint_model_display": "—",
                    "request_speed_display": "等待首条消息",
                    "ttft_display": "—",
                    "pressure_level": "OK",
                    "pressure_percent_num": 0.0,
                    "physical_percent_num": 0.0,
                    "cache_hit_percent": "0.0%",
                    "cumulative_display": "0",
                    "workspace_cumulative_display": "0",
                    "workspace_sessions_count": 0,
                },
                "kv_cache": {
                    "warmth": "COLD",
                    "ttl_remaining_sec": 0,
                    "ttl_display": "已冷却",
                    "estimated_cache_usd_saved": 0.0,
                    "recent_15_turns": [],
                    "bust_events": [],
                    "composition_tokens": {},
                    "loop_watch": {"oscillation_detected": False},
                },
                "guard": {
                    "savings": {"session_by_kind": {}, "session_guard_saved_tokens": 0, "global_guard_saved_tokens": 0, "global_guard_saved_bytes": 0},
                    "combined_saved_tokens": 0,
                    "combined_saved_display": "0",
                    "watchdog_health": guard.get_watchdog_health(),
                },
                "settings": settings,
                "watchdog_sessions": guard.list_watchdog_sessions(),
                "lsm": {
                    "tier_counts": {"T1": 0, "T2": 0, "T3": 0},
                    "pins_count": 0,
                    "compression_ratio": "0.0%",
                    "net_tokens_saved_display": "0",
                    "distill_ready_ids": [],
                    "condense_ready_ids": [],
                },
                "blocks": [],
                "pins": [],
                "unfolded_compressible_ranges": [],
                "hints": [],
            }

        cid = status["conversation_id"]
        sess = self.resolve_session(cid)
        raw_steps = self.read_transcript_steps(sess.get("transcript_path") if sess else None, prefer_full=False)
        tel = status["telemetry"]
        lsm = status["lsm_memory"]
        model_raw = status.get("model_name") or "auto"
        kv_info = None
        try:
            from core.guard_engine import analyze_kv_cache_and_loops

            kv_info = analyze_kv_cache_and_loops(raw_steps, model_raw)
        except Exception:
            kv_info = {
                "warmth": "COLD",
                "ttl_remaining_sec": 0,
                "ttl_display": "已冷却",
                "estimated_cache_usd_saved": 0.0,
                "recent_15_turns": [],
                "bust_events": [],
                "composition_tokens": {},
                "loop_watch": {"oscillation_detected": False},
            }

        logical_tok = int(tel.get("logical_working_tokens") or 0)
        soft_budget = int(tel.get("effective_budget_tokens") or DEFAULT_ACP_SOFT_BUDGET)
        phys_tok = int(tel.get("physical_prompt_tokens") or 0)
        phys_win = int(tel.get("physical_window_tokens") or detect_physical_window(model_raw))

        pct_num = float(tel.get("pressure_ratio") or 0.0) * 100.0
        phys_pct_num = float(tel.get("physical_pressure_ratio") or 0.0) * 100.0

        usage_disp = (
            f"{self._format_compact_tokens(logical_tok)} / {self._format_compact_tokens(soft_budget)} ({pct_num:.1f}%)"
            if (logical_tok > 0 or phys_tok > 0)
            else "暂不可用"
        )
        phys_disp = (
            f"{self._format_compact_tokens(phys_tok)} / {self._format_compact_tokens(phys_win)} ({phys_pct_num:.1f}%)"
            if phys_tok > 0
            else "暂不可用"
        )
        speed_val = tel.get("approx_tok_per_sec")
        speed_disp = f"~{speed_val:.1f} tok/s" if speed_val and speed_val > 0 else "等待有效请求"

        savings = guard.get_savings_summary(cid)
        combined_saved_tok = int(lsm.get("net_tokens_saved") or 0) + int(savings.get("session_guard_saved_tokens") or 0)
        blocks_full = status.get("blocks", [])
        t1_ids = [b["block_id"] for b in blocks_full if b.get("tier") == "T1"]
        t2_ids = [b["block_id"] for b in blocks_full if b.get("tier") == "T2"]

        return {
            "conversation_id": cid,
            "estimator": {
                "usage_display": usage_disp,
                "physical_usage_display": phys_disp,
                "active_input_tokens": logical_tok,
                "effective_budget_tokens": soft_budget,
                "window_label": format_window_label(soft_budget),
                "physical_prompt_tokens": phys_tok,
                "physical_window_tokens": phys_win,
                "physical_window_label": format_window_label(phys_win),
                "pressure_level": tel.get("pressure_level", "OK"),
                "pressure_percent_num": round(pct_num, 1),
                "physical_percent_num": round(phys_pct_num, 1),
                "sample_model_display": format_model_display(model_raw) if model_raw != "auto" else "—",
                "endpoint_model_display": model_raw if model_raw != "auto" else "—",
                "request_speed_display": speed_disp,
                "ttft_display": "—",
                "cache_hit_percent": tel.get("cache_hit_percent", "0.0%"),
                "cumulative_display": self._format_compact_tokens(int(tel.get("cumulative_session_tokens") or 0)),
                "workspace_cumulative_display": self._format_compact_tokens(
                    int(tel.get("workspace_cumulative_tokens") or 0)
                ),
                "workspace_sessions_count": int(tel.get("workspace_sessions_count") or 1),
            },
            "kv_cache": kv_info,
            "guard": {
                "savings": savings,
                "combined_saved_tokens": combined_saved_tok,
                "combined_saved_display": self._format_compact_tokens(combined_saved_tok),
                "watchdog_health": guard.get_watchdog_health(),
            },
            "settings": settings,
            "watchdog_sessions": guard.list_watchdog_sessions(),
            "lsm": {
                **lsm,
                "net_tokens_saved_display": self._format_compact_tokens(int(lsm.get("net_tokens_saved") or 0)),
                "distill_ready_ids": t1_ids[:4] if len(t1_ids) >= 4 else [],
                "condense_ready_ids": t2_ids[:4] if len(t2_ids) >= 4 else [],
            },
            "blocks": blocks_full[:15],
            "pins": status.get("pins", [])[:15],
            "unfolded_compressible_ranges": status.get("unfolded_compressible_ranges", []),
            "hints": status.get("hints", []),
        }

    def build_memory_rehydration_block(self, conversation_id: str, max_chars: int = 2400) -> str:
        """Build compact `<acp-memory-rehydration>` index to inject right after `/compact`."""
        sess = self.resolve_session(conversation_id)
        if not sess:
            return ""
        cid = sess["conversation_id"]
        ws_key = sess.get("workspace_key") or ""
        pins = self.list_pins(conversation_id=cid, workspace_key=ws_key)
        blocks = self.get_active_blocks(cid, include_workspace_milestones=True)
        if not pins and not blocks:
            return ""

        lines = [
            f'<acp-memory-rehydration conversation_id="{cid}">',
            "Physical context compaction detected. Active Billion-Context LSM Memory & Pins preserved:",
        ]
        if pins:
            lines.append("Pinned Invariants:")
            for p in pins[:8]:
                lines.append(f"  - [{p['pin_id']}|{p['category']}] {p['title']}: {p['content'][:160]}")
        if blocks:
            lines.append("Active LSM Blocks (use `search_context` or `decompress(block_id=...)` for verbatim details):")
            for b in blocks[:10]:
                ref = b.get("range_ref") or f"{format_step_ref(b['start_step'])}..{format_step_ref(b['end_step'])}"
                lines.append(f"  - [{b['block_id']}|T{b['tier']}|{ref}] {b['title']}: {b['summary'][:160]}")
        lines.append("</acp-memory-rehydration>")
        text = "\n".join(lines)
        if len(text) > max_chars:
            text = text[: max_chars - 30] + "\n</acp-memory-rehydration>"
        return text

    def check_and_record_compaction_rehydration(
        self,
        conversation_id: str,
        physical_tokens: int,
        force_compact: bool = False,
    ) -> str | None:
        """Detect `/compact` or >=35% physical prompt drop and return one-shot LSM rehydration XML."""
        with self._connect() as conn:
            row = conn.execute(
                "SELECT last_seen_physical_tokens FROM sessions WHERE conversation_id = ?",
                (conversation_id,),
            ).fetchone()
            prev_phys = int(row["last_seen_physical_tokens"] or 0) if row else 0
            dropped = prev_phys >= 60_000 and physical_tokens > 0 and physical_tokens <= int(prev_phys * 0.65)
            should_rehydrate = bool(force_compact or dropped)
            new_tracked = physical_tokens if should_rehydrate else max(prev_phys, physical_tokens)
            now = utc_now_iso()
            if should_rehydrate:
                conn.execute(
                    "UPDATE sessions SET last_seen_physical_tokens = ?, last_rehydrated_at = ? WHERE conversation_id = ?",
                    (new_tracked, now, conversation_id),
                )
            elif new_tracked != prev_phys:
                conn.execute(
                    "UPDATE sessions SET last_seen_physical_tokens = ? WHERE conversation_id = ?",
                    (new_tracked, conversation_id),
                )
        if should_rehydrate:
            block = self.build_memory_rehydration_block(conversation_id)
            return block or None
        return None
