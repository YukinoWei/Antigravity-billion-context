"""Fused KV-Cache, Quota Guard, Stall Watchdog, Session Rescue & Fast-Batch Engine (v3.0).

Clean-room Python 3.12 stdlib implementation fusing the core capabilities of
`zou172866/Antigravity-agy-dart` with `billion-context` ACP:
  1. Model-aware KV-Cache Warmth, Empirical TTL Countdown, 15-Turn Hit Trends,
     6-Category Cache-Bust Attribution, and Optional Auto-Keepalive (`agentapi`).
  2. 4-Tier File Read Quota Guard (45KB code / 128KB patch / 16KB noisy logs, 2-strike
     pass-through, compact symbol outliner, and unchanged file duplicate-read dedup).
  3. Secret Redaction, Sensitive-File Blocking (.env / private keys), and SSRF-safe URL fetch.
  4. Transparent CLI Output Trimming & Smart JSON Crusher (<= 8.8 KB UTF-8 safe cap).
  5. Stall/Crash Watchdog Leases, Loop Watch (edit-fail oscillation), & 1-Click Rescue Brief.
  6. Fast Batch Tools (`batch_search`, `read_slices`, `run_checks`) & FTS5 Vault
     (`ctx_index`, `ctx_execute`, `ctx_purge`).
"""

from __future__ import annotations

import concurrent.futures
import difflib
import fnmatch
import gzip
import hashlib
import ipaddress
import json
import os
import re
import shutil
import socket
import sqlite3
import subprocess
import sys
import time
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

MAX_INLINE_UTF8_BYTES = 8800  # Antigravity spills >10KB MCP/CLI outputs to temp files

DEFAULT_SETTINGS: dict[str, Any] = {
    "read_preset": "host-45k",          # host-45k | balanced-16k | fast-32k | strict-8k | off
    "cli_noise_filter": True,           # Trim noisy test/git/build outputs to <=8.8KB & archive full log
    "dedup_reads": True,                # Warn/dedup repeated full reads of unchanged files
    "diff_read": False,                 # Return unified diff vs saved snapshot when a read file changes (off by default)
    "protect_secrets": True,            # Block .env/private keys & redact API tokens
    "zero_prefix_alerts": True,         # Emit UI-only PreInvocation alerts (systemMessage="") to protect KV-cache
    "model_compress_nudge": True,       # Nudge model on RECOMMEND/URGENT unfolded ACP ranges
    "keepalive_mode": "off",            # off | auto | 4m | 9m | 15m
    "keepalive_max_pings": 1,           # Max automatic keepalive pings per idle window (1..10)
    "auto_launch_widget": True,         # Auto-launch docked chat-bar HUD on SessionStart
}

READ_PRESET_LIMITS: dict[str, dict[str, int]] = {
    "host-45k": {"code": 46080, "patch": 131072, "noisy": 16384},
    "fast-32k": {"code": 32768, "patch": 98304, "noisy": 12288},
    "balanced-16k": {"code": 16384, "patch": 65536, "noisy": 8192},
    "strict-8k": {"code": 8192, "patch": 32768, "noisy": 4096},
    "off": {"code": 100_000_000, "patch": 100_000_000, "noisy": 100_000_000},
}

MODEL_CACHE_PROFILES: list[dict[str, Any]] = [
    {
        "id": "gemini-4-512k",
        "pattern": re.compile(r"(?:gemini[-_/\s]?4|neon|carbon|argon|hydrogen)", re.I),
        "window_tokens": 512_000,
        "ttl_sec": 300,
        "discount": 0.90,
        "input_price_1m": 2.00,
        "write_mult": 1.0,
    },
    {
        "id": "gemini-flash",
        "pattern": re.compile(r"gemini.*flash", re.I),
        "window_tokens": 512_000,
        "ttl_sec": 300,
        "discount": 0.90,
        "input_price_1m": 0.30,
        "write_mult": 1.0,
    },
    {
        "id": "claude-200k",
        "pattern": re.compile(r"claude", re.I),
        "window_tokens": 200_000,
        "ttl_sec": 300,
        "discount": 0.90,
        "input_price_1m": 3.00,
        "write_mult": 1.25,
    },
    {
        "id": "gpt-5",
        "pattern": re.compile(r"gpt[-_]?5|codex", re.I),
        "window_tokens": 272_000,
        "ttl_sec": 300,
        "discount": 0.90,
        "input_price_1m": 1.25,
        "write_mult": 1.0,
    },
    {
        "id": "deepseek-128k",
        "pattern": re.compile(r"deepseek|dsh", re.I),
        "window_tokens": 128_000,
        "ttl_sec": 300,
        "discount": 0.90,
        "input_price_1m": 0.28,
        "write_mult": 1.0,
    },
]

SECRET_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"\bsk-[A-Za-z0-9_\-]{20,}\b"), "sk-[REDACTED]"),
    (re.compile(r"\bAIza[0-9A-Za-z_\-]{30,}\b"), "AIza[REDACTED]"),
    (re.compile(r"\bgh[pousr]_[A-Za-z0-9]{24,}\b"), "gh_[REDACTED]"),
    (re.compile(r"\bAKIA[0-9A-Z]{16}\b"), "AKIA[REDACTED]"),
    (re.compile(r"(?i)(Bearer\s+)[A-Za-z0-9\-._~+/]{24,}=*"), r"\1[REDACTED]"),
    (re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |PRIVATE )?KEY-----[\s\S]*?-----END [^\n]+-----"), "[PRIVATE_KEY_REDACTED]"),
]

SENSITIVE_FILENAME_RE = re.compile(
    r"(?:^|/)(?:\.env(?:\.[A-Za-z0-9_.-]+)?|id_rsa|id_ed25519|.*\.pem|.*\.key|credentials\.json|\.npmrc|\.pypirc)$",
    re.I,
)
SAFE_ENV_TEMPLATE_RE = re.compile(r"\.env\.(?:example|sample|template|dist|schema)$", re.I)


def truncate_utf8_safe(text: str, max_bytes: int = MAX_INLINE_UTF8_BYTES, suffix: str = "\n... [8.8KB UTF-8 Guard Truncated]") -> str:
    """Truncate string cleanly to <= max_bytes UTF-8 without splitting multi-byte CJK/Emoji."""
    raw = text.encode("utf-8")
    if len(raw) <= max_bytes:
        return text
    sfx_bytes = suffix.encode("utf-8")
    budget = max(64, max_bytes - len(sfx_bytes))
    clipped = raw[:budget].decode("utf-8", errors="ignore")
    return clipped + suffix


def redact_secrets(text: str) -> str:
    if not text:
        return text
    out = text
    for pat, repl in SECRET_PATTERNS:
        out = pat.sub(repl, out)
    return out


def is_sensitive_file(file_path: str) -> bool:
    norm = file_path.replace("\\", "/").strip()
    if SAFE_ENV_TEMPLATE_RE.search(norm):
        return False
    return bool(SENSITIVE_FILENAME_RE.search(norm))


def resolve_model_cache_profile(model_name: str | None) -> dict[str, Any]:
    m = model_name or ""
    for prof in MODEL_CACHE_PROFILES:
        if prof["pattern"].search(m):
            return prof
    return {
        "id": "default-512k",
        "window_tokens": 512_000,
        "ttl_sec": 300,
        "discount": 0.90,
        "input_price_1m": 2.00,
        "write_mult": 1.0,
    }


def _parse_iso_epoch(raw: str | None) -> float | None:
    if not raw or not isinstance(raw, str):
        return None
    try:
        s = raw.strip()
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        return datetime.fromisoformat(s).timestamp()
    except ValueError:
        return None


# ------------------------------------------------------------------
# Compact Code & Patch Outliner (Multi-language AST/Regex)
# ------------------------------------------------------------------

OUTLINE_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"^\s*(?:async\s+)?def\s+([A-Za-z_]\w*)\s*\(([^)]*)\)"),
    re.compile(r"^\s*class\s+([A-Za-z_]\w*)(?:\([^)]*\))?:"),
    re.compile(r"^\s*(?:export\s+)?(?:default\s+)?(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\("),
    re.compile(r"^\s*(?:export\s+)?(?:abstract\s+)?(?:class|interface|type|enum)\s+([A-Za-z_$][\w$]*)"),
    re.compile(r"^\s*(?:pub\s+)?(?:async\s+)?fn\s+([A-Za-z_]\w*)\s*[<(]"),
    re.compile(r"^\s*(?:pub\s+)?(?:struct|enum|trait|impl)\s+([A-Za-z_][\w<>]*)"),
    re.compile(r"^\s*func\s+(?:\([^)]+\)\s*)?([A-Za-z_]\w*)\s*\("),
    re.compile(r"^\s*#{1,4}\s+.+$"),
    re.compile(r"^(?:diff --git|---\s+a/|\+\+\+\s+b/|@@\s+-\d+)"),
]


def extract_code_outline(file_path: str | Path, max_lines: int = 65) -> dict[str, Any]:
    p = Path(file_path)
    if not p.exists() or not p.is_file():
        return {"path": str(file_path), "exists": False, "total_lines": 0, "outline": []}
    raw_bytes = p.stat().st_size
    text = p.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()
    hits: list[str] = []
    for idx, line in enumerate(lines, 1):
        stripped = line.strip()
        if not stripped or len(stripped) > 180:
            continue
        for pat in OUTLINE_PATTERNS:
            if pat.search(line):
                hits.append(f"L{idx}: {stripped[:120]}")
                break
        if len(hits) >= max_lines:
            break
    return {
        "path": str(p).replace("\\", "/"),
        "exists": True,
        "size_bytes": raw_bytes,
        "total_lines": len(lines),
        "symbols_count": len(hits),
        "outline": hits,
    }


# ------------------------------------------------------------------
# Smart CLI Noise Trimmer & Reversible JSON Crusher
# ------------------------------------------------------------------

ANSI_ESCAPE_RE = re.compile(r"\x1B\[[0-?]*[ -/]*[@-~]")
PROGRESS_NOISE_RE = re.compile(
    r"(?:\b\d{1,3}(?:\.\d+)?%\s*[|█▓▒░=#\-]{2,}|"
    r"^\s*(?:Downloading|Installing|Fetched|Resolving|Unpacking|Compiling)\b.*(?:\.\.\.|ms|kB|MB)\s*$)",
    re.I,
)
ERROR_ANCHOR_RE = re.compile(
    r"(?:\b(?:FAIL|FAILED|ERROR|Exception|Traceback|AssertionError|SyntaxError|TypeError|ValueError|panic:|fatal:)\b"
    r"|^\s*File \".*\", line \d+)",
    re.I,
)

SAFE_FILTERABLE_CMD_RE = re.compile(
    r"^\s*(?:pytest|python\s+-m\s+(?:unittest|pytest)|npm\s+(?:test|run\s+test|run\s+build)|"
    r"pnpm\s+test|yarn\s+test|cargo\s+(?:test|check|build)|go\s+test|"
    r"git\s+(?:diff|log|status|show)|tsc\b|ruff\b|flake8\b|eslint\b)",
    re.I,
)
UNSAFE_SHELL_META_RE = re.compile(r"[|><`$;!%\n\r]|\$\(|\bsudo\b")


def is_safe_filterable_command(cmd: str) -> bool:
    """Only wrap single-command foreground checks free of pipes/redirects/shell metacharacters."""
    if not cmd or len(cmd) > 420:
        return False
    if UNSAFE_SHELL_META_RE.search(cmd):
        return False
    if "&&" in cmd:
        return False
    return bool(SAFE_FILTERABLE_CMD_RE.match(cmd))


def smart_crush_json(raw_text: str, max_bytes: int = MAX_INLINE_UTF8_BYTES) -> tuple[str, bool]:
    """Reversibly summarize huge JSON arrays/objects: schema + counts + samples + error items."""
    stripped = raw_text.strip()
    if len(stripped.encode("utf-8")) <= max_bytes or not stripped or stripped[0] not in "[{":
        return raw_text, False
    try:
        data = json.loads(stripped)
    except Exception:
        return raw_text, False

    summary: dict[str, Any]
    if isinstance(data, list):
        err_items = [
            it for it in data
            if isinstance(it, dict) and any(k in it and it[k] for k in ("error", "err", "failed", "exception"))
        ][:5]
        keys = sorted({k for it in data[:50] if isinstance(it, dict) for k in it.keys()})[:25]
        summary = {
            "_crushed_json": "array",
            "total_items": len(data),
            "item_keys": keys,
            "head_sample": data[:2],
            "tail_sample": data[-1:] if len(data) > 2 else [],
            "error_items": err_items,
        }
    elif isinstance(data, dict):
        top_keys = list(data.keys())
        preview: dict[str, Any] = {}
        for k in top_keys[:15]:
            v = data[k]
            if isinstance(v, list):
                preview[k] = f"<Array len={len(v)} sample={json.dumps(v[:1], ensure_ascii=False)[:140]}>"
            elif isinstance(v, dict):
                preview[k] = f"<Object keys={list(v.keys())[:10]}>"
            else:
                preview[k] = str(v)[:180]
        summary = {
            "_crushed_json": "object",
            "top_key_count": len(top_keys),
            "preview": preview,
        }
    else:
        return raw_text, False

    rendered = json.dumps(summary, indent=2, ensure_ascii=False)
    return truncate_utf8_safe(rendered, max_bytes=max_bytes), True


def compress_cli_output(raw_text: str, exit_code: int = 0, max_bytes: int = MAX_INLINE_UTF8_BYTES) -> tuple[str, int]:
    """Strip ANSI/progress noise, preserve error anchors & stack traces, and cap at <= 8.8 KB.

    Returns `(filtered_text, saved_bytes)`.
    """
    cleaned = redact_secrets(ANSI_ESCAPE_RE.sub("", raw_text))
    orig_bytes = len(cleaned.encode("utf-8"))
    if orig_bytes <= max_bytes:
        return cleaned, 0

    crushed, was_json = smart_crush_json(cleaned, max_bytes=max_bytes)
    if was_json:
        saved = max(0, orig_bytes - len(crushed.encode("utf-8")))
        return crushed, saved

    lines = [ln for ln in cleaned.splitlines() if not PROGRESS_NOISE_RE.search(ln)]
    if len(lines) <= 80:
        out = truncate_utf8_safe("\n".join(lines), max_bytes=max_bytes)
        return out, max(0, orig_bytes - len(out.encode("utf-8")))

    # Keep head (20 lines), all error-anchor windows (+/- 3 lines), and tail (30 lines)
    keep_indices: set[int] = set(range(min(20, len(lines))))
    keep_indices.update(range(max(0, len(lines) - 30), len(lines)))
    for i, ln in enumerate(lines):
        if ERROR_ANCHOR_RE.search(ln):
            for j in range(max(0, i - 2), min(len(lines), i + 5)):
                keep_indices.add(j)
            if len(keep_indices) > 220:
                break

    ordered = sorted(keep_indices)
    assembled: list[str] = []
    prev = -1
    for idx in ordered:
        if prev != -1 and idx > prev + 1:
            assembled.append(f"  ... [{idx - prev - 1} passing/verbose lines omitted by CLI Guard] ...")
        assembled.append(lines[idx])
        prev = idx

    joined = "\n".join(assembled)
    capped = truncate_utf8_safe(joined, max_bytes=max_bytes)
    saved = max(0, orig_bytes - len(capped.encode("utf-8")))
    return capped, saved


# ------------------------------------------------------------------
# SSRF-Guarded URL Fetcher for `ctx_index`
# ------------------------------------------------------------------

def validate_public_url(url: str) -> str:
    parsed = urllib.parse.urlparse(url.strip())
    if parsed.scheme not in ("http", "https"):
        raise ValueError("Only http:// and https:// URLs are permitted.")
    host = parsed.hostname
    if not host:
        raise ValueError("Missing hostname in URL.")
    if host.lower() in ("localhost", "metadata.google.internal"):
        raise ValueError(f"Blocked loopback/metadata host: {host}")
    infos = socket.getaddrinfo(host, parsed.port or (443 if parsed.scheme == "https" else 80))
    for info in infos:
        ip_str = info[4][0]
        ip_obj = ipaddress.ip_address(ip_str)
        if (
            ip_obj.is_private
            or ip_obj.is_loopback
            or ip_obj.is_link_local
            or ip_obj.is_multicast
            or ip_obj.is_reserved
        ):
            raise ValueError(f"Blocked non-public IP address ({ip_str}) for SSRF protection.")
    return url.strip()


# ------------------------------------------------------------------
# KV-Cache Analyzer & Loop Watch
# ------------------------------------------------------------------

def analyze_kv_cache_and_loops(
    steps: list[dict[str, Any]],
    model_name: str | None,
    now_ts: float | None = None,
) -> dict[str, Any]:
    """Compute real KV-Cache warmth, empirical TTL countdown, 15-turn trend, bust causes, & loop watch."""
    now = now_ts if now_ts is not None else time.time()
    prof = resolve_model_cache_profile(model_name)
    base_ttl_sec = int(prof["ttl_sec"])

    turns: list[dict[str, Any]] = []
    last_model_ts: float | None = None
    observed_warm_gaps: list[float] = []
    bust_reasons: list[dict[str, Any]] = []

    comp_buckets = {
        "file_reads": 0,
        "terminal": 0,
        "edits_and_tools": 0,
        "user_and_system": 0,
        "model_output": 0,
    }

    prev_prompt_tok = 0
    prev_model = ""
    prev_ts: float | None = None
    saw_compact = False

    # Loop watch: detect repeated failing commands or repeated edits on same file after errors
    recent_failures: list[str] = []
    edit_touch_counts: dict[str, int] = {}

    for s in steps:
        stype = str(s.get("type") or "")
        content = str(s.get("content") or "")
        est = max(4, int(len(content) / 3.6))

        if stype == "USER_INPUT" and "/compact" in content:
            saw_compact = True

        tcs = s.get("tool_calls") or []
        if isinstance(tcs, list):
            for tc in tcs:
                if not isinstance(tc, dict):
                    continue
                tn = str(tc.get("name") or "")
                args = tc.get("args") or {}
                if tn in ("read_file", "view_file"):
                    comp_buckets["file_reads"] += 250
                elif tn == "run_command":
                    comp_buckets["terminal"] += 250
                elif tn in ("edit_file", "write_file") and isinstance(args, dict):
                    p = str(args.get("Path") or "")
                    if p:
                        edit_touch_counts[p] = edit_touch_counts.get(p, 0) + 1
                    comp_buckets["edits_and_tools"] += 180
                else:
                    comp_buckets["edits_and_tools"] += 120

        if stype == "GENERIC":
            if "Showing lines " in content:
                comp_buckets["file_reads"] += est
            elif "Command exited with code " in content:
                comp_buckets["terminal"] += est
                if "Command exited with code 0" not in content[:200]:
                    recent_failures.append(f"step_{s.get('step_index')}")
            else:
                comp_buckets["edits_and_tools"] += est
        elif stype in ("USER_INPUT", "SYSTEM_MESSAGE"):
            comp_buckets["user_and_system"] += est

        in_tok = int(s.get("input_tokens") or 0)
        cache_tok = int(s.get("cache_read_tokens") or 0)
        out_tok = int(s.get("output_tokens") or 0)
        total_in = in_tok + cache_tok
        if total_in <= 0:
            continue

        comp_buckets["model_output"] += max(out_tok, est)
        ts = _parse_iso_epoch(s.get("created_at"))
        cur_model = str(s.get("model") or model_name or "")
        hit_ratio = round(cache_tok / max(1, total_in), 4)

        if ts is not None and prev_ts is not None:
            gap = ts - prev_ts
            if hit_ratio >= 0.70 and 10 <= gap <= 3600:
                observed_warm_gaps.append(gap)

        # Bust attribution if previous prompt had >= 8K tokens and hit ratio plunged < 35%
        if prev_prompt_tok >= 8000 and hit_ratio < 0.35:
            gap_s = (ts - prev_ts) if (ts and prev_ts) else 0
            if saw_compact:
                cause = "slash_compact"
                label = "/compact 压缩重置前缀"
                saw_compact = False
            elif prev_model and cur_model and prev_model != cur_model:
                cause = "model_switch"
                label = f"模型切换 ({prev_model} → {cur_model})"
            elif gap_s >= base_ttl_sec:
                cause = "ttl_expired"
                label = f"空闲超过缓存 TTL ({int(gap_s)}s)"
            else:
                cause = "prefix_mutation"
                label = "工具/系统前缀变动导致重预填"
            bust_reasons.append(
                {
                    "step_index": s.get("step_index"),
                    "cause": cause,
                    "label": label,
                    "hit_percent": f"{hit_ratio * 100:.1f}%",
                }
            )

        turns.append(
            {
                "step_index": s.get("step_index"),
                "input_tokens": in_tok,
                "cache_read_tokens": cache_tok,
                "total_prompt_tokens": total_in,
                "hit_ratio": hit_ratio,
                "hit_percent": round(hit_ratio * 100, 1),
            }
        )
        prev_prompt_tok = total_in
        prev_model = cur_model
        if ts is not None:
            prev_ts = ts
            last_model_ts = ts

    # Empirical TTL calibration (e.g. if server proved 15m TTL in observed warm gaps)
    effective_ttl_sec = base_ttl_sec
    if observed_warm_gaps:
        max_warm = max(observed_warm_gaps)
        if max_warm > 330:
            effective_ttl_sec = 900  # 15m empirical tier

    if last_model_ts is not None and prev_prompt_tok >= 2000:
        elapsed = max(0.0, now - last_model_ts)
        rem_sec = max(0, int(round(effective_ttl_sec - elapsed)))
        if rem_sec <= 0:
            warmth = "COLD"
        elif rem_sec <= 75:
            warmth = "COOLING"
        elif turns and turns[-1]["hit_ratio"] >= 0.75:
            warmth = "HOT"
        else:
            warmth = "WARM"
    else:
        rem_sec = 0
        warmth = "COLD"

    mm, ss = divmod(rem_sec, 60)
    ttl_display = f"{mm:02d}:{ss:02d}" if rem_sec > 0 else "已冷却"

    total_cached_tokens = sum(t["cache_read_tokens"] for t in turns)
    est_usd_saved = round(
        (total_cached_tokens / 1_000_000.0) * float(prof["input_price_1m"]) * float(prof["discount"]),
        4,
    )

    hot_edit_files = [p for p, c in edit_touch_counts.items() if c >= 4]
    loop_detected = len(recent_failures) >= 3 and len(hot_edit_files) >= 1

    return {
        "profile_id": prof["id"],
        "effective_ttl_sec": effective_ttl_sec,
        "ttl_remaining_sec": rem_sec,
        "ttl_display": ttl_display,
        "warmth": warmth,
        "total_cached_read_tokens": total_cached_tokens,
        "estimated_cache_usd_saved": est_usd_saved,
        "recent_15_turns": turns[-15:],
        "bust_events": bust_reasons[-5:],
        "composition_tokens": comp_buckets,
        "loop_watch": {
            "oscillation_detected": loop_detected,
            "recent_command_failures": len(recent_failures),
            "repeated_edit_files": hot_edit_files[:3],
        },
    }


# ------------------------------------------------------------------
# Persistent Guard, Vault & Watchdog Manager (Attached to ACPStore DB)
# ------------------------------------------------------------------

class GuardEngine:
    """Extends ACPStore's SQLite database with agy-dart quota guards, FTS5 vault, & watchdog."""

    def __init__(self, store: Any) -> None:
        self.store = store
        self._init_tables()

    def _init_tables(self) -> None:
        with self.store._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS plugin_settings (
                    key TEXT PRIMARY KEY,
                    value_json TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS file_reads (
                    conversation_id TEXT NOT NULL,
                    file_path TEXT NOT NULL,
                    mtime_ns INTEGER NOT NULL,
                    size_bytes INTEGER NOT NULL,
                    strike_count INTEGER DEFAULT 1,
                    last_read_at REAL NOT NULL,
                    PRIMARY KEY (conversation_id, file_path)
                );

                CREATE TABLE IF NOT EXISTS guard_savings (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    conversation_id TEXT NOT NULL,
                    kind TEXT NOT NULL,
                    saved_bytes INTEGER NOT NULL,
                    saved_tokens INTEGER NOT NULL,
                    detail TEXT,
                    created_at TEXT NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_guard_savings_conv
                    ON guard_savings(conversation_id, kind);

                CREATE TABLE IF NOT EXISTS watchdog_leases (
                    conversation_id TEXT PRIMARY KEY,
                    workspace_key TEXT DEFAULT '',
                    phase TEXT NOT NULL,
                    detail TEXT DEFAULT '',
                    modified_files TEXT DEFAULT '[]',
                    last_test_status TEXT DEFAULT '',
                    keepalive_mode TEXT DEFAULT 'inherit',
                    keepalive_count INTEGER DEFAULT 0,
                    last_keepalive_ts REAL DEFAULT 0,
                    updated_wall_ts REAL NOT NULL
                );

                CREATE TABLE IF NOT EXISTS vault_sources (
                    source_id TEXT PRIMARY KEY,
                    conversation_id TEXT DEFAULT '',
                    workspace_key TEXT DEFAULT '',
                    label TEXT NOT NULL,
                    origin TEXT NOT NULL,
                    content_hash TEXT NOT NULL,
                    total_bytes INTEGER DEFAULT 0,
                    chunk_count INTEGER DEFAULT 0,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS vault_chunks (
                    chunk_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_id TEXT NOT NULL,
                    heading TEXT DEFAULT '',
                    body TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS file_snapshots (
                    conversation_id TEXT NOT NULL,
                    file_path TEXT NOT NULL,
                    mtime_ns INTEGER NOT NULL,
                    content_gzip BLOB NOT NULL,
                    updated_at REAL NOT NULL,
                    PRIMARY KEY (conversation_id, file_path)
                );

                CREATE TABLE IF NOT EXISTS watchdog_heartbeats (
                    worker_id TEXT PRIMARY KEY,
                    last_beat_ts REAL NOT NULL,
                    agentapi_available INTEGER DEFAULT 0,
                    stalled_count INTEGER DEFAULT 0,
                    detail TEXT DEFAULT ''
                );
                """
            )
            try:
                conn.execute(
                    """
                    CREATE VIRTUAL TABLE IF NOT EXISTS vault_fts USING fts5(
                        source_id UNINDEXED,
                        label,
                        heading,
                        body
                    )
                    """
                )
            except sqlite3.OperationalError:
                pass

    # ------------------------------------------------------------------
    # Settings Management
    # ------------------------------------------------------------------

    def get_settings(self) -> dict[str, Any]:
        merged = dict(DEFAULT_SETTINGS)
        with self.store._connect() as conn:
            rows = conn.execute("SELECT key, value_json FROM plugin_settings").fetchall()
        for r in rows:
            try:
                merged[str(r["key"])] = json.loads(r["value_json"])
            except Exception:
                pass
        # Env overrides
        if os.environ.get("BILLION_CONTEXT_READ_PRESET"):
            merged["read_preset"] = os.environ["BILLION_CONTEXT_READ_PRESET"]
        if os.environ.get("BILLION_CONTEXT_NO_WIDGET") == "1":
            merged["auto_launch_widget"] = False
        return merged

    def update_settings(self, updates: dict[str, Any]) -> dict[str, Any]:
        now = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        allowed = set(DEFAULT_SETTINGS.keys())
        with self.store._connect() as conn:
            for k, v in updates.items():
                if k not in allowed:
                    continue
                conn.execute(
                    """
                    INSERT INTO plugin_settings (key, value_json, updated_at)
                    VALUES (?, ?, ?)
                    ON CONFLICT(key) DO UPDATE SET value_json = excluded.value_json, updated_at = excluded.updated_at
                    """,
                    (k, json.dumps(v, ensure_ascii=False), now),
                )
        return self.get_settings()

    # ------------------------------------------------------------------
    # Savings Ledger
    # ------------------------------------------------------------------

    def record_saving(self, conversation_id: str, kind: str, saved_bytes: int, detail: str = "") -> None:
        if saved_bytes <= 0:
            return
        saved_tok = max(1, int(round(saved_bytes / 3.8)))
        now = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        with self.store._connect() as conn:
            conn.execute(
                """
                INSERT INTO guard_savings (conversation_id, kind, saved_bytes, saved_tokens, detail, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (conversation_id or "global", kind, int(saved_bytes), saved_tok, detail[:200], now),
            )

    def get_savings_summary(self, conversation_id: str | None = None) -> dict[str, Any]:
        with self.store._connect() as conn:
            if conversation_id:
                rows = conn.execute(
                    """
                    SELECT kind, COALESCE(SUM(saved_bytes), 0) AS b, COALESCE(SUM(saved_tokens), 0) AS t, COUNT(*) AS c
                    FROM guard_savings WHERE conversation_id = ? GROUP BY kind
                    """,
                    (conversation_id,),
                ).fetchall()
            else:
                rows = conn.execute(
                    """
                    SELECT kind, COALESCE(SUM(saved_bytes), 0) AS b, COALESCE(SUM(saved_tokens), 0) AS t, COUNT(*) AS c
                    FROM guard_savings GROUP BY kind
                    """
                ).fetchall()
            all_row = conn.execute(
                "SELECT COALESCE(SUM(saved_tokens), 0) AS total_tok, COALESCE(SUM(saved_bytes), 0) AS total_b FROM guard_savings"
            ).fetchone()
        by_kind = {
            str(r["kind"]): {
                "saved_bytes": int(r["b"]),
                "saved_tokens": int(r["t"]),
                "events": int(r["c"]),
            }
            for r in rows
        }
        return {
            "session_by_kind": by_kind,
            "session_guard_saved_tokens": sum(v["saved_tokens"] for v in by_kind.values()),
            "global_guard_saved_tokens": int(all_row["total_tok"] if all_row else 0),
            "global_guard_saved_bytes": int(all_row["total_b"] if all_row else 0),
        }

    # ------------------------------------------------------------------
    # `PreToolUse`: 4-Tier Read Guard, Secret Block, Dedup, & CLI Filter
    # ------------------------------------------------------------------

    def evaluate_pre_read(
        self,
        conversation_id: str,
        tool_args: dict[str, Any],
    ) -> dict[str, Any]:
        """Evaluate `read_file` / `view_file` against sensitive guard, 4-tier quota, and dedup."""
        path_str = str(tool_args.get("Path") or tool_args.get("TargetFile") or "").strip()
        if not path_str:
            return {"decision": "allow"}

        norm = path_str.replace("\\", "/")
        # 0-SQLite fast path for Skills, Rules, and system logs
        if norm.endswith(("SKILL.md", "AGENTS.md", "GEMINI.md")) or "/.system_generated/" in norm:
            return {"decision": "allow"}

        cfg = self.get_settings()
        if cfg.get("protect_secrets", True) and is_sensitive_file(norm):
            return {
                "decision": "deny",
                "reason": (
                    f"[Billion-Context Security Guard] Blocked direct read of sensitive file `{Path(norm).name}`. "
                    "Inspect safe `.env.example` templates or disable `protect_secrets` in the Billion-Context dashboard if intentional."
                ),
            }

        preset = str(cfg.get("read_preset") or "host-45k")
        if preset == "off":
            return {"decision": "allow"}

        p = Path(path_str)
        if not p.exists() or not p.is_file():
            return {"decision": "allow"}

        stat = p.stat()
        size_b = stat.st_size
        mtime_ns = stat.st_mtime_ns
        has_range = tool_args.get("StartLine") is not None or tool_args.get("EndLine") is not None or tool_args.get("ByteOffset") is not None

        # Ranged slices under 45 KB always pass immediately
        if has_range:
            s_line = int(tool_args.get("StartLine") or 1)
            e_line = int(tool_args.get("EndLine") or (s_line + 800))
            if (e_line - s_line) <= 800:
                return {"decision": "allow"}

        limits = READ_PRESET_LIMITS.get(preset, READ_PRESET_LIMITS["host-45k"])
        ext = p.suffix.lower()
        if ext in (".patch", ".diff"):
            limit_b = limits["patch"]
        elif ext in (".log", ".lock", ".map") or p.name.endswith((".min.js", ".min.css")):
            limit_b = limits["noisy"]
        else:
            limit_b = limits["code"]

        now_ts = time.time()
        pending_saving: tuple[str, int, str] | None = None
        decision_out: dict[str, Any] = {"decision": "allow"}

        with self.store._connect() as conn:
            prev = conn.execute(
                "SELECT mtime_ns, size_bytes, strike_count, last_read_at FROM file_reads WHERE conversation_id = ? AND file_path = ?",
                (conversation_id, norm),
            ).fetchone()

            # Oversized unranged blind read -> 1st strike returns compact symbol outline! 2nd strike passes through!
            if not has_range and size_b > limit_b:
                if prev and int(prev["mtime_ns"]) == mtime_ns and int(prev["strike_count"]) >= 1:
                    conn.execute(
                        "UPDATE file_reads SET strike_count = strike_count + 1, last_read_at = ? WHERE conversation_id = ? AND file_path = ?",
                        (now_ts, conversation_id, norm),
                    )
                    return {"decision": "allow"}

                conn.execute(
                    """
                    INSERT INTO file_reads (conversation_id, file_path, mtime_ns, size_bytes, strike_count, last_read_at)
                    VALUES (?, ?, ?, ?, 1, ?)
                    ON CONFLICT(conversation_id, file_path) DO UPDATE SET
                        mtime_ns = excluded.mtime_ns, size_bytes = excluded.size_bytes, strike_count = 1, last_read_at = excluded.last_read_at
                    """,
                    (conversation_id, norm, mtime_ns, size_b, now_ts),
                )
                outline_info = extract_code_outline(p, max_lines=45)
                outline_preview = "\n".join(outline_info["outline"][:35]) or "(no top-level symbols detected)"
                saved_b = max(0, size_b - len(outline_preview.encode("utf-8")))
                pending_saving = ("read_outline_guard", saved_b, norm)
                decision_out = {
                    "decision": "deny",
                    "reason": (
                        f"[Billion-Context Read Quota Guard ({preset})] `{p.name}` is {size_b:,} bytes "
                        f"({outline_info['total_lines']} lines, above {limit_b:,}B limit). "
                        f"Read targeted `StartLine`..`EndLine` slices using this outline (or call `read_slices`), "
                        f"or re-call `read_file` once more if full read is strictly required:\n{outline_preview}"
                    ),
                }
            elif (
                cfg.get("dedup_reads", True)
                and not has_range
                and size_b >= 6144
                and prev
                and int(prev["mtime_ns"]) == mtime_ns
                and (now_ts - float(prev["last_read_at"])) < 600
                and int(prev["strike_count"]) == 1
            ):
                conn.execute(
                    "UPDATE file_reads SET strike_count = 2, last_read_at = ? WHERE conversation_id = ? AND file_path = ?",
                    (now_ts, conversation_id, norm),
                )
                pending_saving = ("duplicate_read_dedup", size_b, norm)
                decision_out = {
                    "decision": "deny",
                    "reason": (
                        f"[Billion-Context Duplicate-Read Guard] `{p.name}` ({size_b:,}B) has NOT changed on disk "
                        "since your earlier full read in this session. Reuse the content already in context "
                        "(or pass `StartLine`/`EndLine`, or retry once to force re-read)."
                    ),
                }
            elif (
                cfg.get("diff_read", False)
                and not has_range
                and size_b <= 131072
                and (not prev or int(prev["mtime_ns"]) != mtime_ns)
            ):
                snap_row = conn.execute(
                    "SELECT mtime_ns, content_gzip FROM file_snapshots WHERE conversation_id = ? AND file_path = ?",
                    (conversation_id, norm),
                ).fetchone()
                diff_handled = False
                if snap_row and int(snap_row["mtime_ns"]) != mtime_ns:
                    try:
                        old_text = gzip.decompress(bytes(snap_row["content_gzip"])).decode("utf-8", errors="replace")
                        new_text = p.read_text(encoding="utf-8", errors="replace")
                        diff_lines = list(
                            difflib.unified_diff(
                                old_text.splitlines(),
                                new_text.splitlines(),
                                fromfile=f"a/{p.name}",
                                tofile=f"b/{p.name}",
                                lineterm="",
                                n=2,
                            )
                        )
                        if diff_lines:
                            diff_body = "\n".join(diff_lines[:140])
                            if len(diff_body.encode("utf-8")) < int(size_b * 0.65):
                                # Update baseline & mark strike_count=1 so an immediate 2nd read passes full file
                                conn.execute(
                                    """
                                    INSERT INTO file_snapshots (conversation_id, file_path, mtime_ns, content_gzip, updated_at)
                                    VALUES (?, ?, ?, ?, ?)
                                    ON CONFLICT(conversation_id, file_path) DO UPDATE SET
                                        mtime_ns = excluded.mtime_ns, content_gzip = excluded.content_gzip, updated_at = excluded.updated_at
                                    """,
                                    (conversation_id, norm, mtime_ns, gzip.compress(new_text.encode("utf-8")), now_ts),
                                )
                                conn.execute(
                                    """
                                    INSERT INTO file_reads (conversation_id, file_path, mtime_ns, size_bytes, strike_count, last_read_at)
                                    VALUES (?, ?, ?, ?, 2, ?)
                                    ON CONFLICT(conversation_id, file_path) DO UPDATE SET
                                        mtime_ns = excluded.mtime_ns, size_bytes = excluded.size_bytes, strike_count = 2, last_read_at = excluded.last_read_at
                                    """,
                                    (conversation_id, norm, mtime_ns, size_b, now_ts),
                                )
                                saved_b = max(0, size_b - len(diff_body.encode("utf-8")))
                                pending_saving = ("diff_read_guard", saved_b, norm)
                                decision_out = {
                                    "decision": "deny",
                                    "reason": (
                                        f"[Billion-Context Diff-Read Guard] `{p.name}` changed since your earlier read. "
                                        "Returning only changed lines (re-call `read_file` once more for full file):\n"
                                        + truncate_utf8_safe(diff_body, max_bytes=6000)
                                    ),
                                }
                                diff_handled = True
                    except Exception:
                        diff_handled = False
                if not diff_handled:
                    conn.execute(
                        """
                        INSERT INTO file_reads (conversation_id, file_path, mtime_ns, size_bytes, strike_count, last_read_at)
                        VALUES (?, ?, ?, ?, 1, ?)
                        ON CONFLICT(conversation_id, file_path) DO UPDATE SET
                            mtime_ns = excluded.mtime_ns, size_bytes = excluded.size_bytes, strike_count = 1, last_read_at = excluded.last_read_at
                        """,
                        (conversation_id, norm, mtime_ns, size_b, now_ts),
                    )
                    if size_b <= 131072:
                        try:
                            raw_bytes = p.read_bytes()
                            conn.execute(
                                """
                                INSERT INTO file_snapshots (conversation_id, file_path, mtime_ns, content_gzip, updated_at)
                                VALUES (?, ?, ?, ?, ?)
                                ON CONFLICT(conversation_id, file_path) DO UPDATE SET
                                    mtime_ns = excluded.mtime_ns, content_gzip = excluded.content_gzip, updated_at = excluded.updated_at
                                """,
                                (conversation_id, norm, mtime_ns, gzip.compress(raw_bytes), now_ts),
                            )
                        except Exception:
                            pass
            else:
                conn.execute(
                    """
                    INSERT INTO file_reads (conversation_id, file_path, mtime_ns, size_bytes, strike_count, last_read_at)
                    VALUES (?, ?, ?, ?, 1, ?)
                    ON CONFLICT(conversation_id, file_path) DO UPDATE SET
                        mtime_ns = excluded.mtime_ns, size_bytes = excluded.size_bytes, strike_count = 1, last_read_at = excluded.last_read_at
                    """,
                    (conversation_id, norm, mtime_ns, size_b, now_ts),
                )
                if size_b <= 131072:
                    try:
                        raw_bytes = p.read_bytes()
                        conn.execute(
                            """
                            INSERT INTO file_snapshots (conversation_id, file_path, mtime_ns, content_gzip, updated_at)
                            VALUES (?, ?, ?, ?, ?)
                            ON CONFLICT(conversation_id, file_path) DO UPDATE SET
                                mtime_ns = excluded.mtime_ns, content_gzip = excluded.content_gzip, updated_at = excluded.updated_at
                            """,
                            (conversation_id, norm, mtime_ns, gzip.compress(raw_bytes), now_ts),
                        )
                    except Exception:
                        pass

        if pending_saving is not None:
            self.record_saving(conversation_id, *pending_saving)
        return decision_out

    def invalidate_file_read(self, conversation_id: str, file_path: str | None) -> None:
        if not file_path:
            return
        norm = str(file_path).replace("\\", "/")
        with self.store._connect() as conn:
            conn.execute(
                "DELETE FROM file_reads WHERE conversation_id = ? AND file_path = ?",
                (conversation_id, norm),
            )

    # ------------------------------------------------------------------
    # Watchdog Leases, Stall Detection, Auto-Keepalive & 1-Click Rescue
    # ------------------------------------------------------------------

    def update_lease(
        self,
        conversation_id: str,
        phase: str,
        detail: str = "",
        workspace_key: str = "",
        modified_file: str | None = None,
        last_test_status: str | None = None,
        reset_keepalive_count: bool = False,
    ) -> None:
        if not conversation_id:
            return
        now_ts = time.time()
        clean_detail = redact_secrets(detail)[:180]
        with self.store._connect() as conn:
            row = conn.execute(
                "SELECT modified_files, last_test_status, keepalive_mode, keepalive_count, workspace_key FROM watchdog_leases WHERE conversation_id = ?",
                (conversation_id,),
            ).fetchone()
            mod_files: list[str] = []
            prev_test = ""
            ka_mode = "inherit"
            ka_cnt = 0
            ws = workspace_key
            if row:
                try:
                    mod_files = json.loads(row["modified_files"] or "[]")
                except Exception:
                    mod_files = []
                prev_test = str(row["last_test_status"] or "")
                ka_mode = str(row["keepalive_mode"] or "inherit")
                ka_cnt = 0 if reset_keepalive_count else int(row["keepalive_count"] or 0)
                ws = workspace_key or str(row["workspace_key"] or "")

            if modified_file:
                mf = modified_file.replace("\\", "/")
                if mf not in mod_files:
                    mod_files.append(mf)
                    mod_files = mod_files[-25:]

            conn.execute(
                """
                INSERT INTO watchdog_leases (
                    conversation_id, workspace_key, phase, detail, modified_files,
                    last_test_status, keepalive_mode, keepalive_count, updated_wall_ts
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(conversation_id) DO UPDATE SET
                    workspace_key = CASE WHEN excluded.workspace_key != '' THEN excluded.workspace_key ELSE watchdog_leases.workspace_key END,
                    phase = excluded.phase,
                    detail = excluded.detail,
                    modified_files = excluded.modified_files,
                    last_test_status = CASE WHEN ? IS NOT NULL THEN ? ELSE watchdog_leases.last_test_status END,
                    keepalive_count = excluded.keepalive_count,
                    updated_wall_ts = excluded.updated_wall_ts
                """,
                (
                    conversation_id,
                    ws,
                    phase,
                    clean_detail,
                    json.dumps(mod_files, ensure_ascii=False),
                    last_test_status if last_test_status is not None else prev_test,
                    ka_mode,
                    ka_cnt,
                    now_ts,
                    last_test_status,
                    last_test_status or "",
                ),
            )

    def set_session_keepalive_mode(self, conversation_id: str, mode: str) -> dict[str, Any]:
        valid = {"inherit", "off", "auto", "4m", "9m", "15m"}
        m = mode if mode in valid else "off"
        self.update_lease(conversation_id, phase="IDLE")
        with self.store._connect() as conn:
            conn.execute(
                "UPDATE watchdog_leases SET keepalive_mode = ?, keepalive_count = 0 WHERE conversation_id = ?",
                (m, conversation_id),
            )
        return {"conversation_id": conversation_id, "keepalive_mode": m}

    def list_watchdog_sessions(self, now_ts: float | None = None) -> list[dict[str, Any]]:
        now = now_ts if now_ts is not None else time.time()
        with self.store._connect() as conn:
            rows = conn.execute(
                """
                SELECT w.*, s.model_name, s.last_input_tokens, s.last_cache_read_tokens, s.context_window, s.parent_conversation_id
                FROM watchdog_leases w
                LEFT JOIN sessions s ON w.conversation_id = s.conversation_id
                ORDER BY w.updated_wall_ts DESC LIMIT 12
                """
            ).fetchall()

        items: list[dict[str, Any]] = []
        for r in rows:
            age_s = max(0, int(now - float(r["updated_wall_ts"] or now)))
            phase = str(r["phase"] or "IDLE")
            # Stall detection: LLM_INFLIGHT > 180s or TOOL_RUNNING > 300s (and < 2h so laptop sleep isn't flagged)
            stalled = False
            if phase == "LLM_INFLIGHT" and 180 <= age_s <= 7200:
                stalled = True
            elif phase == "TOOL_RUNNING" and 300 <= age_s <= 7200:
                stalled = True

            tot_tok = int(r["last_input_tokens"] or 0) + int(r["last_cache_read_tokens"] or 0)
            win_tok = int(r["context_window"] or 512000)
            pct = round((tot_tok / max(1, win_tok)) * 100, 1)
            try:
                mods = json.loads(r["modified_files"] or "[]")
            except Exception:
                mods = []

            items.append(
                {
                    "conversation_id": r["conversation_id"],
                    "workspace_key": r["workspace_key"],
                    "phase": "STALLED" if stalled else phase,
                    "raw_phase": phase,
                    "stalled": stalled,
                    "age_sec": age_s,
                    "detail": r["detail"],
                    "modified_files": mods,
                    "last_test_status": r["last_test_status"] or "未记录",
                    "keepalive_mode": r["keepalive_mode"] or "inherit",
                    "keepalive_count": int(r["keepalive_count"] or 0),
                    "tokens_used": tot_tok,
                    "window_tokens": win_tok,
                    "usage_percent": pct,
                    "model_name": r["model_name"] or "auto",
                }
            )
        return items

    def tick_auto_keepalive(self, conversation_id: str | None = None, send_fn: Any = None) -> dict[str, Any]:
        """Evaluate idle sessions and fire a lightweight `OK` keepalive ping shortly before cache expiry."""
        cfg = self.get_settings()
        global_mode = str(cfg.get("keepalive_mode") or "off")
        max_pings = max(1, min(10, int(cfg.get("keepalive_max_pings") or 1)))
        now = time.time()

        sessions = self.list_watchdog_sessions(now_ts=now)
        pinged: list[str] = []
        for ws_sess in sessions:
            cid = ws_sess["conversation_id"]
            if conversation_id and cid != conversation_id:
                continue
            if ws_sess["raw_phase"] != "IDLE":
                continue
            eff_mode = ws_sess["keepalive_mode"] if ws_sess["keepalive_mode"] != "inherit" else global_mode
            if eff_mode == "off":
                continue
            if ws_sess["keepalive_count"] >= max_pings:
                continue

            # Determine trigger interval from transcript KV state
            sess_row = self.store.resolve_session(cid)
            if not sess_row or (sess_row.get("parent_conversation_id") and "subagent" in str(ws_sess.get("detail", ""))):
                continue
            steps = self.store.read_transcript_steps(sess_row.get("transcript_path"), prefer_full=False)
            kv = analyze_kv_cache_and_loops(steps, sess_row.get("model_name"), now_ts=now)
            eff_tokens = max(
                [int(ws_sess["tokens_used"])]
                + [int(t["total_prompt_tokens"]) for t in kv.get("recent_15_turns", [])]
            )
            if eff_tokens < 4000 or kv["warmth"] == "COLD":
                continue

            interval_map = {"4m": 240, "9m": 540, "15m": 840}
            if eff_mode == "auto":
                should_fire = 15 <= kv["ttl_remaining_sec"] <= 65
            else:
                target_iv = interval_map.get(eff_mode, 240)
                should_fire = ws_sess["age_sec"] >= target_iv and kv["ttl_remaining_sec"] > 0

            if not should_fire:
                continue

            ok = False
            if callable(send_fn):
                ok = bool(send_fn(cid, "Reply with OK only."))
            else:
                ok = self._send_agentapi_keepalive(cid)

            if ok:
                with self.store._connect() as conn:
                    conn.execute(
                        "UPDATE watchdog_leases SET keepalive_count = keepalive_count + 1, last_keepalive_ts = ? WHERE conversation_id = ?",
                        (now, cid),
                    )
                pinged.append(cid)
        return {"evaluated": len(sessions), "pinged": pinged}

    @staticmethod
    def resolve_agentapi_executable() -> list[str] | None:
        """Resolve `agentapi` CLI across PATH, ~/.gemini/antigravity/bin/agentapi.bat, and language_server.exe."""
        from core.acp_store import default_app_data_dir

        for name in ("agentapi", "agentapi.bat", "agentapi.exe"):
            found = shutil.which(name)
            if found:
                if found.lower().endswith((".bat", ".cmd")) and sys.platform == "win32":
                    return ["cmd.exe", "/c", found]
                return [found]

        app_bin = default_app_data_dir() / "bin"
        for cand_name in ("agentapi.bat", "agentapi"):
            cand = app_bin / cand_name
            if cand.exists():
                if cand.suffix.lower() in (".bat", ".cmd") and sys.platform == "win32":
                    return ["cmd.exe", "/c", str(cand)]
                return [str(cand)]

        if sys.platform == "win32":
            local_app = Path(os.environ.get("LOCALAPPDATA", ""))
            ls_exe = local_app / "Programs" / "antigravity" / "resources" / "bin" / "language_server.exe"
            if ls_exe.exists():
                return [str(ls_exe), "agentapi"]
        return None

    @classmethod
    def _send_agentapi_keepalive(cls, conversation_id: str) -> bool:
        cmd_prefix = cls.resolve_agentapi_executable()
        if not cmd_prefix:
            return False
        try:
            creationflags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
            res = subprocess.run(
                [*cmd_prefix, "send-message", conversation_id, "Reply with OK only."],
                capture_output=True,
                timeout=6,
                check=False,
                creationflags=creationflags,
            )
            return res.returncode == 0
        except Exception:
            return False

    def record_watchdog_heartbeat(self, worker_id: str, stalled_count: int = 0, detail: str = "") -> None:
        has_api = 1 if self.resolve_agentapi_executable() else 0
        with self.store._connect() as conn:
            conn.execute(
                """
                INSERT INTO watchdog_heartbeats (worker_id, last_beat_ts, agentapi_available, stalled_count, detail)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(worker_id) DO UPDATE SET
                    last_beat_ts = excluded.last_beat_ts,
                    agentapi_available = excluded.agentapi_available,
                    stalled_count = excluded.stalled_count,
                    detail = excluded.detail
                """,
                (worker_id, time.time(), has_api, stalled_count, detail[:160]),
            )

    def get_watchdog_health(self) -> dict[str, Any]:
        api_cmd = self.resolve_agentapi_executable()
        now = time.time()
        sidecar_active = False
        last_beat_age: int | None = None
        with self.store._connect() as conn:
            row = conn.execute(
                "SELECT * FROM watchdog_heartbeats ORDER BY last_beat_ts DESC LIMIT 1"
            ).fetchone()
        if row:
            age = int(max(0.0, now - float(row["last_beat_ts"])))
            last_beat_age = age
            if age <= 60:
                sidecar_active = True
        return {
            "agentapi_available": api_cmd is not None,
            "agentapi_cmd": " ".join(api_cmd) if api_cmd else None,
            "watchdog_active": sidecar_active,
            "last_beat_age_sec": last_beat_age,
            "worker_id": str(row["worker_id"]) if row else None,
        }

    def audit_prefix_and_skills(self, workspace_dir: str | None = None) -> dict[str, Any]:
        """Audit Turn-0 MCP tools budget, canonical SHA-256 fingerprint, & installed Skills frontmatter tax."""
        from core.acp_store import estimate_tokens
        from server.mcp_server import TOOLS_SPEC

        canonical_json = json.dumps(TOOLS_SPEC, sort_keys=True, ensure_ascii=False)
        tools_sha = hashlib.sha256(canonical_json.encode("utf-8")).hexdigest()[:16]
        mcp_tokens = estimate_tokens(canonical_json)

        skill_roots: list[Path] = [
            Path.home() / ".gemini" / "config" / "skills",
        ]
        plugins_dir = Path.home() / ".gemini" / "config" / "plugins"
        if plugins_dir.exists():
            for pdir in plugins_dir.iterdir():
                if pdir.is_dir() and (pdir / "skills").exists():
                    skill_roots.append(pdir / "skills")
        if workspace_dir:
            for cand in (".agents/skills", ".agent/skills"):
                sp = Path(workspace_dir) / cand
                if sp.exists():
                    skill_roots.append(sp)

        skills_report: list[dict[str, Any]] = []
        seen_paths: set[str] = set()
        total_frontmatter_tok = 0
        for root in skill_roots:
            if not root.exists():
                continue
            for sk_file in root.glob("*/SKILL.md"):
                resolved = str(sk_file.resolve())
                if resolved in seen_paths:
                    continue
                seen_paths.add(resolved)
                try:
                    raw = sk_file.read_text(encoding="utf-8", errors="replace")
                except Exception:
                    continue
                fm_match = re.match(r"^---\s*\n([\s\S]*?)\n---", raw)
                fm_text = fm_match.group(1) if fm_match else ""
                fm_tok = estimate_tokens(fm_text) if fm_text else 0
                total_frontmatter_tok += fm_tok
                total_lines = len(raw.splitlines())
                skills_report.append(
                    {
                        "name": sk_file.parent.name,
                        "frontmatter_tokens": fm_tok,
                        "total_lines": total_lines,
                        "bloated_frontmatter": fm_tok > 120,
                        "path": str(sk_file).replace("\\", "/"),
                    }
                )

        skills_report.sort(key=lambda s: -s["frontmatter_tokens"])
        return {
            "mcp_server": "billion-context_acp",
            "tool_count": len(TOOLS_SPEC),
            "mcp_turn0_tokens": mcp_tokens,
            "mcp_sha256": tools_sha,
            "skills_scanned": len(skills_report),
            "skills_frontmatter_tokens": total_frontmatter_tok,
            "total_turn0_overhead_tokens": mcp_tokens + total_frontmatter_tok,
            "skills": skills_report[:20],
        }

    def build_rescue_brief(self, conversation_id: str | None = None) -> dict[str, Any]:
        """Generate a 1-click redacted Crash/Stall Rescue Brief to paste into a fresh chat."""
        sess = self.store.resolve_session(conversation_id)
        if not sess:
            raise ValueError("No active session found to rescue.")
        cid = sess["conversation_id"]
        ws_key = sess.get("workspace_key") or ""
        status = self.store.get_status(cid, detail="full")
        steps = self.store.read_transcript_steps(sess.get("transcript_path"), prefer_full=False)

        with self.store._connect() as conn:
            lease = conn.execute(
                "SELECT * FROM watchdog_leases WHERE conversation_id = ?",
                (cid,),
            ).fetchone()

        mod_files: list[str] = []
        last_test = "未记录"
        phase_str = "IDLE"
        last_detail = ""
        if lease:
            try:
                mod_files = json.loads(lease["modified_files"] or "[]")
            except Exception:
                mod_files = []
            last_test = str(lease["last_test_status"] or "未记录")
            phase_str = str(lease["phase"] or "IDLE")
            last_detail = str(lease["detail"] or "")

        # Also harvest git status / diff --stat safely if workspace exists on disk
        git_summary = ""
        cwd_path = sess.get("cwd") or (json.loads(sess.get("workspace_paths") or "[]") or [""])[0]
        if cwd_path and Path(cwd_path).exists():
            try:
                br = subprocess.run(
                    ["git", "-c", "core.hooksPath=_disabled_", "status", "-sb"],
                    cwd=cwd_path,
                    capture_output=True,
                    text=True,
                    timeout=3,
                    check=False,
                )
                if br.returncode == 0 and br.stdout.strip():
                    git_summary = br.stdout.strip()[:600]
            except Exception:
                pass

        last_user_req = ""
        for s in reversed(steps):
            if s.get("type") == "USER_INPUT":
                last_user_req = str(s.get("content") or "")[:300]
                break

        pins = status.get("pins", [])
        blocks = status.get("blocks", [])

        lines = [
            "# 🛟 Billion-Context 会话崩溃/卡死抢救简报 (Session Rescue Brief)",
            f"- **原会话 ID**: `{cid}`",
            f"- **运行状态**: `{phase_str}` {('— ' + last_detail) if last_detail else ''}",
            f"- **上下文水位**: `{status['telemetry']['logical_working_tokens']:,} / {status['telemetry']['effective_budget_tokens']:,}` ({status['telemetry']['pressure_percent']})",
            f"- **最近测试/构建状态**: `{last_test}`",
            "",
        ]
        if last_user_req:
            lines.extend(["## 最近用户指令", redact_secrets(last_user_req).strip(), ""])
        if mod_files:
            lines.append("## 本会话已修改文件")
            for mf in mod_files[-15:]:
                lines.append(f"- `{mf}`")
            lines.append("")
        if git_summary:
            lines.extend(["## Git 工作区状态", "```text", redact_secrets(git_summary), "```", ""])
        if pins:
            lines.append("## 固定的关键架构不变量 (Pins)")
            for p in pins[:10]:
                lines.append(f"- **[{p['category']}] {p['title']}**: {p['content']}")
            lines.append("")
        if blocks:
            lines.append("## 已折叠历史里程碑 (ACP LSM Blocks)")
            for b in blocks[:6]:
                lines.append(f"- **[{b['block_id']} | {b['tier']} | {b['range_ref']}] {b['title']}**: {b['summary'][:240]}")
            lines.append("")
        lines.append(
            f"> 粘贴此简报到新对话即可无缝继续；如需调取原会话逐字细节，可调用 `search_context(workspace_wide=True)` 或 `decompress(conversation_id=\"{cid}\", ...)`。"
        )
        brief_md = truncate_utf8_safe("\n".join(lines), max_bytes=MAX_INLINE_UTF8_BYTES)
        return {
            "conversation_id": cid,
            "workspace_key": ws_key,
            "phase": phase_str,
            "modified_files": mod_files,
            "last_test_status": last_test,
            "rescue_markdown": brief_md,
        }

    # ------------------------------------------------------------------
    # Fast Batch Suite (`batch_search`, `read_slices`, `run_checks`)
    # ------------------------------------------------------------------

    def batch_search(
        self,
        queries: list[dict[str, Any]],
        cwd: str | None = None,
        conversation_id: str | None = None,
    ) -> dict[str, Any]:
        """Run multiple literal/regex/glob searches across workspace in a single turn (<=8.8KB)."""
        root = Path(cwd or os.getcwd()).resolve()
        ignore_dirs = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build", ".pytest_cache"}
        all_files: list[Path] = []
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in ignore_dirs and not d.startswith(".gemini")]
            for fn in filenames:
                fp = Path(dirpath) / fn
                all_files.append(fp)
                if len(all_files) >= 4000:
                    break
            if len(all_files) >= 4000:
                break

        results: list[dict[str, Any]] = []
        raw_scanned_bytes = 0
        for q in queries[:12]:
            qtype = str(q.get("type") or "text").lower()
            pattern = str(q.get("pattern") or "")
            file_glob = str(q.get("glob") or "*")
            max_hits = max(1, min(50, int(q.get("max_results") or 20)))

            if qtype == "glob":
                matched = [
                    str(fp.relative_to(root)).replace("\\", "/")
                    for fp in all_files
                    if fnmatch.fnmatch(fp.name, pattern) or fnmatch.fnmatch(str(fp.relative_to(root)).replace("\\", "/"), pattern)
                ][:max_hits]
                results.append({"pattern": pattern, "type": "glob", "matches": matched})
                continue

            try:
                rx = re.compile(pattern if qtype == "regex" else re.escape(pattern), re.I if q.get("case_insensitive", True) else 0)
            except re.error as exc:
                results.append({"pattern": pattern, "error": str(exc)})
                continue

            hits: list[str] = []
            for fp in all_files:
                if file_glob != "*" and not fnmatch.fnmatch(fp.name, file_glob):
                    continue
                try:
                    st = fp.stat()
                    if st.st_size > 512_000:
                        continue
                    raw_scanned_bytes += min(st.st_size, 8192)
                    txt = fp.read_text(encoding="utf-8", errors="ignore")
                except Exception:
                    continue
                for lno, line in enumerate(txt.splitlines(), 1):
                    if rx.search(line):
                        rel = str(fp.relative_to(root)).replace("\\", "/")
                        hits.append(f"{rel}:{lno}: {line.strip()[:140]}")
                        if len(hits) >= max_hits:
                            break
                if len(hits) >= max_hits:
                    break
            results.append({"pattern": pattern, "type": qtype, "hit_count": len(hits), "matches": hits})

        out_json = json.dumps({"root": str(root).replace("\\", "/"), "results": results}, indent=2, ensure_ascii=False)
        capped = truncate_utf8_safe(out_json, max_bytes=MAX_INLINE_UTF8_BYTES)
        if conversation_id and raw_scanned_bytes > len(capped.encode("utf-8")):
            self.record_saving(conversation_id, "batch_search", min(raw_scanned_bytes, 65536), f"{len(queries)} queries")
        return {"formatted": capped, "query_count": len(queries)}

    def read_slices(
        self,
        outlines: list[str] | None = None,
        slices: list[dict[str, Any]] | None = None,
        cwd: str | None = None,
        conversation_id: str | None = None,
    ) -> str:
        """Batch-extract compact file outlines and/or 1-based line-range slices in one turn (<=8.8KB)."""
        base = Path(cwd or os.getcwd()).resolve()
        out_parts: list[str] = []
        raw_total = 0

        for opath in (outlines or [])[:20]:
            fp = Path(opath) if Path(opath).is_absolute() else (base / opath)
            info = extract_code_outline(fp, max_lines=45)
            raw_total += int(info.get("size_bytes") or 0)
            hdr = f"=== OUTLINE {info['path']} ({info.get('total_lines', 0)} lines) ==="
            out_parts.append(hdr + "\n" + ("\n".join(info["outline"]) or "(empty/no symbols)"))

        for sl in (slices or [])[:15]:
            spath = str(sl.get("path") or "")
            fp = Path(spath) if Path(spath).is_absolute() else (base / spath)
            if not fp.exists() or not fp.is_file():
                out_parts.append(f"=== SLICE {spath} (NOT FOUND) ===")
                continue
            if is_sensitive_file(str(fp)) and self.get_settings().get("protect_secrets", True):
                out_parts.append(f"=== SLICE {fp.name} (BLOCKED BY SECRET GUARD) ===")
                continue
            raw_total += fp.stat().st_size
            lines = fp.read_text(encoding="utf-8", errors="replace").splitlines()
            for rng in (sl.get("ranges") or [[1, 120]])[:6]:
                s_idx = max(1, int(rng[0]))
                e_idx = min(len(lines), int(rng[1]))
                body = "\n".join(f"{i}: {lines[i - 1]}" for i in range(s_idx, e_idx + 1))
                out_parts.append(f"=== SLICE {fp.name}:{s_idx}-{e_idx} ===\n{body}")

        joined = redact_secrets("\n\n".join(out_parts))
        capped = truncate_utf8_safe(joined, max_bytes=MAX_INLINE_UTF8_BYTES)
        ret_bytes = len(capped.encode("utf-8"))
        if conversation_id and raw_total > ret_bytes:
            self.record_saving(conversation_id, "read_slices", raw_total - ret_bytes, "batched outlines/slices")
        return capped

    def run_checks(
        self,
        commands: list[dict[str, Any]],
        cwd: str | None = None,
        conversation_id: str | None = None,
    ) -> str:
        """Run up to 6 short verification commands concurrently, shifting unused quota to failing traces."""
        work_dir = cwd or os.getcwd()
        items = commands[:6]

        def _exec_one(spec: dict[str, Any]) -> dict[str, Any]:
            name = str(spec.get("name") or spec.get("command") or "check")
            cmd = str(spec.get("command") or "")
            timeout_s = max(2, min(60, int(spec.get("timeoutSec") or 30)))
            c_dir = str(spec.get("cwd") or work_dir)
            t0 = time.time()
            try:
                proc = subprocess.run(
                    cmd,
                    shell=True,
                    cwd=c_dir,
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    timeout=timeout_s,
                    check=False,
                )
                combined = (proc.stdout or "") + ("\n" + proc.stderr if proc.stderr else "")
                return {
                    "name": name,
                    "exit_code": proc.returncode,
                    "duration_sec": round(time.time() - t0, 2),
                    "raw": combined.strip(),
                }
            except subprocess.TimeoutExpired:
                return {"name": name, "exit_code": 124, "duration_sec": timeout_s, "raw": f"[TIMEOUT after {timeout_s}s]"}

        with concurrent.futures.ThreadPoolExecutor(max_workers=min(4, max(1, len(items)))) as pool:
            outcomes = list(pool.map(_exec_one, items))

        failing = [o for o in outcomes if o["exit_code"] != 0]
        fail_budget = max(1200, int(7200 / max(1, len(failing)))) if failing else 800
        sections: list[str] = []
        total_saved = 0

        for o in outcomes:
            status_tag = "PASS" if o["exit_code"] == 0 else f"FAIL (exit {o['exit_code']})"
            budget = 420 if o["exit_code"] == 0 else fail_budget
            trimmed, saved = compress_cli_output(o["raw"], exit_code=o["exit_code"], max_bytes=budget)
            total_saved += saved
            sections.append(f"[{status_tag}] {o['name']} ({o['duration_sec']}s)\n{trimmed}")

        if conversation_id:
            all_pass = len(failing) == 0
            self.update_lease(
                conversation_id,
                phase="LLM_INFLIGHT",
                last_test_status="PASS" if all_pass else f"FAIL ({len(failing)}/{len(outcomes)})",
            )
            if total_saved > 0:
                self.record_saving(conversation_id, "run_checks", total_saved, f"{len(outcomes)} checks")

        return truncate_utf8_safe("\n\n".join(sections), max_bytes=MAX_INLINE_UTF8_BYTES)

    # ------------------------------------------------------------------
    # Heading-Aware FTS5 Vault (`ctx_index`, `ctx_search`, `ctx_execute`, `ctx_purge`)
    # ------------------------------------------------------------------

    def ctx_index(
        self,
        path: str | None = None,
        url: str | None = None,
        text: str | None = None,
        label: str = "doc",
        conversation_id: str | None = None,
        workspace_key: str = "",
    ) -> dict[str, Any]:
        """Chunk long Markdown/docs/logs or SSRF-safe URLs by section into local FTS5 vault."""
        if url:
            safe_u = validate_public_url(url)
            req = urllib.request.Request(safe_u, headers={"User-Agent": "BillionContext-Vault/3.0"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                raw_body = resp.read(2_000_000).decode("utf-8", errors="replace")
            origin = safe_u
        elif path:
            p = Path(path)
            if is_sensitive_file(str(p)) and self.get_settings().get("protect_secrets", True):
                raise ValueError(f"Refusing to index sensitive file: {p.name}")
            raw_body = p.read_text(encoding="utf-8", errors="replace")
            origin = str(p).replace("\\", "/")
        elif text:
            raw_body = text
            origin = f"inline:{label}"
        else:
            raise ValueError("Provide one of path, url, or text to ctx_index.")

        sanitized = redact_secrets(raw_body)
        chash = hashlib.sha256(sanitized.encode("utf-8")).hexdigest()[:16]
        source_id = f"src_{chash[:10]}"

        # Split by Markdown headings or ~1800-char paragraphs
        chunks: list[tuple[str, str]] = []
        cur_head = label
        cur_lines: list[str] = []
        cur_len = 0
        for ln in sanitized.splitlines():
            if re.match(r"^#{1,4}\s+\S", ln) and cur_lines:
                chunks.append((cur_head, "\n".join(cur_lines)))
                cur_head = ln.lstrip("#").strip()[:120]
                cur_lines = [ln]
                cur_len = len(ln)
            else:
                cur_lines.append(ln)
                cur_len += len(ln) + 1
                if cur_len >= 1800:
                    chunks.append((cur_head, "\n".join(cur_lines)))
                    cur_lines = []
                    cur_len = 0
        if cur_lines:
            chunks.append((cur_head, "\n".join(cur_lines)))

        now = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        with self.store._connect() as conn:
            existing = conn.execute("SELECT source_id, chunk_count FROM vault_sources WHERE source_id = ?", (source_id,)).fetchone()
            if existing:
                return {
                    "status": "DEDUP_REUSED",
                    "source_id": source_id,
                    "label": label,
                    "chunks": int(existing["chunk_count"]),
                    "total_bytes": len(sanitized.encode("utf-8")),
                }
            conn.execute(
                """
                INSERT INTO vault_sources (source_id, conversation_id, workspace_key, label, origin, content_hash, total_bytes, chunk_count, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (source_id, conversation_id or "", workspace_key, label, origin, chash, len(sanitized.encode("utf-8")), len(chunks), now),
            )
            for h, body in chunks:
                conn.execute(
                    "INSERT INTO vault_chunks (source_id, heading, body) VALUES (?, ?, ?)",
                    (source_id, h, body),
                )
                try:
                    conn.execute(
                        "INSERT INTO vault_fts (source_id, label, heading, body) VALUES (?, ?, ?, ?)",
                        (source_id, label, h, body),
                    )
                except sqlite3.OperationalError:
                    pass

        if conversation_id and len(sanitized.encode("utf-8")) > 4096:
            self.record_saving(conversation_id, "ctx_index", len(sanitized.encode("utf-8")) - 512, origin)

        return {
            "status": "INDEXED",
            "source_id": source_id,
            "label": label,
            "chunks": len(chunks),
            "total_bytes": len(sanitized.encode("utf-8")),
        }

    def ctx_vault_search(self, query: str, source_id: str | None = None, limit: int = 8) -> list[dict[str, Any]]:
        tokens = re.findall(r"[\w\u4e00-\u9fff\-./:]+", query)
        fts_q = " OR ".join('"' + t.replace('"', '""') + '"' for t in tokens[:10])
        rows: list[sqlite3.Row] = []
        with self.store._connect() as conn:
            if fts_q:
                try:
                    if source_id:
                        rows = conn.execute(
                            "SELECT source_id, label, heading, body FROM vault_fts WHERE source_id = ? AND vault_fts MATCH ? ORDER BY bm25(vault_fts) LIMIT ?",
                            (source_id, fts_q, limit),
                        ).fetchall()
                    else:
                        rows = conn.execute(
                            "SELECT source_id, label, heading, body FROM vault_fts WHERE vault_fts MATCH ? ORDER BY bm25(vault_fts) LIMIT ?",
                            (fts_q, limit),
                        ).fetchall()
                except sqlite3.OperationalError:
                    rows = []
            if not rows:
                like = f"%{query}%"
                rows = conn.execute(
                    "SELECT c.source_id, s.label, c.heading, c.body FROM vault_chunks c JOIN vault_sources s ON c.source_id = s.source_id WHERE c.body LIKE ? OR c.heading LIKE ? LIMIT ?",
                    (like, like, limit),
                ).fetchall()
        return [
            {
                "source_id": r["source_id"],
                "label": r["label"],
                "heading": r["heading"],
                "snippet": str(r["body"])[:650],
            }
            for r in rows
        ]

    def ctx_execute(
        self,
        code: str,
        language: str = "python",
        cwd: str | None = None,
        timeout_sec: int = 30,
        intent: str = "",
        conversation_id: str | None = None,
    ) -> dict[str, Any]:
        """Run a short local Python/PowerShell analysis script on huge logs/CSVs, returning <=8.8KB."""
        lang = language.lower()
        t_sec = max(1, min(120, int(timeout_sec)))
        if lang in ("python", "py"):
            cmd = [sys.executable, "-c", code]
        elif lang in ("powershell", "ps1", "pwsh"):
            cmd = ["powershell", "-NoProfile", "-Command", code]
        else:
            raise ValueError(f"Unsupported language '{language}'. Use 'python' or 'powershell'.")

        proc = subprocess.run(
            cmd,
            cwd=cwd or os.getcwd(),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=t_sec,
            check=False,
        )
        combined = (proc.stdout or "") + ("\n" + proc.stderr if proc.stderr else "")
        trimmed, saved = compress_cli_output(combined.strip(), exit_code=proc.returncode, max_bytes=MAX_INLINE_UTF8_BYTES)
        if conversation_id and saved > 0:
            self.record_saving(conversation_id, "ctx_execute", saved, intent or "sandbox script")
        return {
            "exit_code": proc.returncode,
            "output": trimmed,
            "saved_bytes": saved,
        }

    def ctx_purge(self, scope: str = "stale", conversation_id: str | None = None) -> dict[str, Any]:
        with self.store._connect() as conn:
            if scope == "all":
                c1 = conn.execute("DELETE FROM vault_sources").rowcount
                conn.execute("DELETE FROM vault_chunks")
                try:
                    conn.execute("DELETE FROM vault_fts")
                except sqlite3.OperationalError:
                    pass
                conn.execute("DELETE FROM file_reads")
            elif scope == "session" and conversation_id:
                sids = [
                    r["source_id"]
                    for r in conn.execute("SELECT source_id FROM vault_sources WHERE conversation_id = ?", (conversation_id,)).fetchall()
                ]
                c1 = len(sids)
                for sid in sids:
                    conn.execute("DELETE FROM vault_sources WHERE source_id = ?", (sid,))
                    conn.execute("DELETE FROM vault_chunks WHERE source_id = ?", (sid,))
                    try:
                        conn.execute("DELETE FROM vault_fts WHERE source_id = ?", (sid,))
                    except sqlite3.OperationalError:
                        pass
                conn.execute("DELETE FROM file_reads WHERE conversation_id = ?", (conversation_id,))
            else:
                cutoff = time.time() - 86400 * 7
                c1 = conn.execute("DELETE FROM file_reads WHERE last_read_at < ?", (cutoff,)).rowcount
                conn.execute("DELETE FROM watchdog_leases WHERE updated_wall_ts < ?", (cutoff,))
        return {"status": "PURGED", "scope": scope, "removed_records": c1}
