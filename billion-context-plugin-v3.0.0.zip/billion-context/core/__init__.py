"""Core Active Context Pruning (ACP) engine for Antigravity billion-context plugin."""
